# SQLite数据库支持
import sqlite3
class SQLiteDB:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
    def execute(self, sql, params=None):
        with self.conn:
            return self.conn.execute(sql, params or [])
