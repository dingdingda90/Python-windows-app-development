# 数据库工厂，支持多数据库
from .sqlite_db import SQLiteDB
from .mysql_db import MySQLDB
from .access_db import AccessDB

def get_database(config):
    db_type = config.get('type', 'sqlite')
    if db_type == 'sqlite':
        return SQLiteDB(config['sqlite_path'])
    elif db_type == 'mysql':
        return MySQLDB(config['mysql'])
    elif db_type == 'access':
        return AccessDB(config['access']['file'])
    else:
        raise ValueError(f"Unknown database type: {db_type}")
