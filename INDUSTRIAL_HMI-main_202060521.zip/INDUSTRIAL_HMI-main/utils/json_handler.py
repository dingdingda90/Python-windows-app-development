import json

def read_json(file_path):
    """
    Reads a JSON file and returns the data.

    :param file_path: Path to the JSON file.
    :return: Parsed JSON data.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: File not found - {file_path}")
    except json.JSONDecodeError as e:
        print(f"Error: Failed to decode JSON - {e}")


def write_json(data, file_path):
    """
    Writes data to a JSON file.

    :param data: Data to write to the JSON file.
    :param file_path: Path to the JSON file.
    """
    try:
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"Error: Failed to write JSON - {e}")

# Example usage
if __name__ == "__main__":
    # Reading JSON
    file_path = "config/Recipe/1K32_17_V1.2.json"
    data = read_json(file_path)
    if data:
        print("Read JSON successfully:", data)

    # Writing JSON
    output_path = "config/Recipe/output.json"
    write_json(data, output_path)
    print(f"JSON written to {output_path}")