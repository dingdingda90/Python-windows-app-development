# 仪器仪表驱动
from .base_driver import BaseDriver
class InstrumentDriver(BaseDriver):
    def measure(self):
        print("Measuring...")
        return 123.45
