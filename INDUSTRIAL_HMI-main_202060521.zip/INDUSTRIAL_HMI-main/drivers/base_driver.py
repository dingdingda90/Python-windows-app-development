# 驱动基类
class BaseDriver:
    def connect(self):
        pass
    def disconnect(self):
        pass
    def send(self, data):
        pass
    def receive(self):
        pass
