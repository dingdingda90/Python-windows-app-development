# IO卡驱动
from .base_driver import BaseDriver
class IOCardDriver(BaseDriver):
    def set_output(self, channel, value):
        print(f"Set IO channel {channel} to {value}")
