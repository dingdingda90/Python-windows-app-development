# MES通讯驱动
from .base_driver import BaseDriver
class MESDriver(BaseDriver):
    def send_data(self, data):
        print(f"Send MES data: {data}")
