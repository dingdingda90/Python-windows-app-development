# 打印机驱动
from .base_driver import BaseDriver
class PrinterDriver(BaseDriver):
    def print_text(self, text):
        print(f"Printing: {text}")
