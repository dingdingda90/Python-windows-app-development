from PySide6.QtWidgets import QTabWidget, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QAbstractItemView

class SequenceTabsWidget(QTabWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_seq = SequenceTableWidget()
        self.addTab(self.main_seq, "Main Sequence")
        self.subseqs = []

    def add_subsequence(self, name=None):
        name = name or f"Subsequence {len(self.subseqs)+1}"
        tab = SequenceTableWidget()
        self.addTab(tab, name)
        self.subseqs.append(tab)
        return tab

    def is_subsequence_tab(self, idx):
        return idx > 0

class SequenceTableWidget(QTableWidget):
    def __init__(self, parent=None):
        super().__init__(0, 5, parent)
        self.setHorizontalHeaderLabels(["No.", "Action", "Param", "Delay(s)", "Remark"])
        self.verticalHeader().setVisible(False)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.SelectedClicked)
