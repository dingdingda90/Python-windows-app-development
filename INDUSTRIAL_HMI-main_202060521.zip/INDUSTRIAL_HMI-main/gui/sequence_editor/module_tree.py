import yaml
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItem

class ModuleTreeWidget(QTreeWidget):
    def __init__(self, config_path, parent=None):
        super().__init__(parent)
        self.setHeaderLabel("Available Modules")
        self.load_modules(config_path)

    def load_modules(self, config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            modules = yaml.safe_load(f)
        self.clear()
        self._add_items(self, modules)

    def _add_items(self, parent, data):
        if isinstance(data, dict):
            for key, value in data.items():
                item = QTreeWidgetItem([key])
                parent.addTopLevelItem(item) if parent is self else parent.addChild(item)
                self._add_items(item, value)
        elif isinstance(data, list):
            for v in data:
                item = QTreeWidgetItem([str(v)])
                parent.addChild(item)
