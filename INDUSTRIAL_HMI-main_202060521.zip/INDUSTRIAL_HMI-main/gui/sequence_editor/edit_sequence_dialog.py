# c:\Users\xin.zhang\Desktop\INDUSTRIAL_HMI-main\gui\sequence_editor\edit_sequence_dialog.py

import os
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
    QCheckBox, QPushButton, QFrame, QTextEdit
)
from PySide6.QtCore import Qt


class EditSequenceDialog(QDialog):
    def __init__(self, name="", description="", enabled=False, parent=None):
        super().__init__(parent)
        self.setWindowTitle("编辑序列")
        self.resize(600, 300)
        
        # 主布局
        main_layout = QVBoxLayout(self)
        
        # 创建输入区域框架
        input_frame = QFrame()
        input_frame.setStyleSheet("""
            QFrame {
                background: white;
            }
        """)
        input_layout = QVBoxLayout(input_frame)
        
        # 名称输入
        name_layout = QHBoxLayout()
        name_label = QLabel("名称:")
        name_label.setStyleSheet("font-size: 16px; font-weight: bold;")  # 更大的字体
        self.name_edit = QLineEdit(name)
        self.name_edit.setStyleSheet("font-size: 15px; padding: 6px;")
        name_layout.addWidget(name_label)
        name_layout.addWidget(self.name_edit)
        input_layout.addLayout(name_layout)
        
        # 描述输入
        desc_layout = QHBoxLayout()
        desc_label = QLabel("描述:")
        desc_label.setStyleSheet("font-size: 16px; font-weight: bold;")  # 更大的字体
        self.desc_edit = QTextEdit(description)
        self.desc_edit.setStyleSheet("font-size: 15px; padding: 6px;")
        self.desc_edit.setMinimumHeight(80)  # 加大描述输入框高度
        # 设置文本从左上角开始
        self.desc_edit.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        desc_layout.addWidget(desc_label)
        desc_layout.addWidget(self.desc_edit, 1)  # 设置拉伸因子
        input_layout.addLayout(desc_layout)
        
        # 启用状态 - 使用复选框
        enable_layout = QHBoxLayout()
        self.enable_checkbox = QCheckBox("启用")
        self.enable_checkbox.setStyleSheet("font-size: 16px; font-weight: bold;")  # 更大的字体
        self.enable_checkbox.setChecked(enabled)
        enable_layout.addWidget(self.enable_checkbox)
        enable_layout.addStretch()  # 添加弹性空间
        input_layout.addLayout(enable_layout)
        
        main_layout.addWidget(input_frame)
        
        # 按钮区域
        button_layout = QHBoxLayout()
        button_layout.addStretch()  # 左侧弹性空间
        
        ok_button = QPushButton("确定")
        ok_button.setStyleSheet("""
            QPushButton {
                background: #4CAF50;
                color: white;
                border: none;
                padding: 8px 16px;
                font-size: 14px;
                border-radius: 4px;
                min-width: 80px;
            }
            QPushButton:hover {
                background: #45a049;
            }
        """)
        ok_button.clicked.connect(self.accept)
        
        cancel_button = QPushButton("取消")
        cancel_button.setStyleSheet("""
            QPushButton {
                background: #f44336;
                color: white;
                border: none;
                padding: 8px 16px;
                font-size: 14px;
                border-radius: 4px;
                min-width: 80px;
            }
            QPushButton:hover {
                background: #da190b;
            }
        """)
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(ok_button)
        button_layout.addWidget(cancel_button)
        button_layout.addStretch()  # 右侧弹性空间
        
        main_layout.addLayout(button_layout)
        
        # 设置间距
        main_layout.setSpacing(10)
        input_layout.setSpacing(8)
    
    def get_values(self):
        """获取对话框中的值"""
        return (
            self.name_edit.text(),
            self.desc_edit.toPlainText(),  # QTextEdit使用toPlainText()获取文本
            self.enable_checkbox.isChecked()
        )


if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    dialog = EditSequenceDialog("测试流程1", "这是一个测试描述", True)
    if dialog.exec():
        name, desc, enabled = dialog.get_values()
        print(f"名称: {name}, 描述: {desc}, 启用: {enabled}")