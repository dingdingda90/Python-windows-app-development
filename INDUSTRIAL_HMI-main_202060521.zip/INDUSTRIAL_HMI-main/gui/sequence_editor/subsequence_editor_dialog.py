
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QWidget, QTreeWidget, QTreeWidgetItem, QTextEdit, QSizePolicy, QFrame,
    QFileDialog, QMessageBox, QLineEdit
)
from PySide6.QtCore import Qt, QTimer, QDateTime
from core.style import BG, HEADER, SIDEBAR, BTN_SEL, GREEN, RED, GREY, GLOBAL_STYLE
import json
import os
from gui.sequence_editor.module_tree import ModuleTreeWidget

class SubSequenceEditorDialog(QDialog):
    def __init__(self, parent=None, module_config_path=None, recipe_file_path=None):
        super().__init__(parent)
        self.setWindowTitle("测试子序列编辑界面")
        self.setStyleSheet(GLOBAL_STYLE)
        self.resize(1200, 700)
        
        # 存储配方文件路径
        self.recipe_file_path = recipe_file_path
        
        main_layout = QVBoxLayout(self)
        # 顶部 Header
        header = QFrame()
        header.setFixedHeight(60)
        header.setStyleSheet(f"background:{HEADER}; border: none;")

        # 最核心：用 QGridLayout 让 标题 和 时间 重叠布局！
        header_layout = QGridLayout(header)
        header_layout.setContentsMargins(10, 2, 10, 2)
        header_layout.setSpacing(0)

        # ======================
        # 标题：真正 100% 正中心（不受时间影响）
        # ======================
        self.title_label = QLabel("测试子序列编辑界面")
        self.title_label.setObjectName("ScreenTitle")
        self.title_label.setStyleSheet("font-size:28px; font-weight:bold; color:white; border:none;")
        self.title_label.setAlignment(Qt.AlignCenter)

        # 放在 0行0列，占满整个网格 → 绝对居中
        header_layout.addWidget(self.title_label, 0, 0, Qt.AlignCenter)

        # ======================
        # 时间：纯右下角，不占位置、不影响居中
        # ======================\        
        self.time_label = QLabel()
        self.time_label.setObjectName("TimeLabel")
        self.time_label.setStyleSheet("font-size:14px; color:white;")

        # 同样放在 0行0列，但是靠右下对齐 → 叠在标题上面！
        header_layout.addWidget(self.time_label, 0, 0, Qt.AlignRight | Qt.AlignBottom)

        main_layout.addWidget(header)
        self._start_timer()

        # 主体区（左-中-右）
        body_layout = QHBoxLayout()
        # 左侧树状功能模块
        left_layout = QVBoxLayout()
        module_tree_path = module_config_path or os.path.join(os.path.dirname(__file__), "..", "..", "config", "modules.yaml")
        self.module_tree = ModuleTreeWidget(module_tree_path)
        self.module_tree.setMinimumWidth(100)
        self.module_tree.setMaximumWidth(150)
        left_layout.addWidget(self.module_tree)
        left_widget = QWidget(); left_widget.setLayout(left_layout)
        left_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(left_widget)

        # 中间详细步骤表格
        self.table = QTableWidget(0, 17)
        self.table.setHorizontalHeaderLabels([
            "步骤名称", "功能名称", "功能参数", "下限", "上限", "单位", "格式", "比较模式", "变量名", "记录名称", "延时", "超时", "循环次数", "描述", "显示?", "记录?", "错误代码"
        ])
        table_style = (
            "QTableWidget::item { selection-background-color: #0D47A1; selection-color: black; border-right: 0.1px solid #d0d0d0; border-bottom: 0.1px solid #d0d0d0; } " +
            "QTableWidget::item:selected { background-color: #0D47A1; color: black; } " +
            "QTableWidget::item:focus { background-color: #0D47A1; color: black; } " +
            "QTableWidget { gridline-color: #d0d0d0; font-size: 14px; outline: none; border: 2px solid #a0a0a0; border-radius: 6px; } " +
            "QHeaderView::section { font-size: 14px; font-weight: bold; background-color: #f0f0f0; border: 1px solid #d0d0d0; border-top-left-radius: 6px; border-top-right-radius: 6px; padding: 4px; } " +
            "QTableCornerButton::section { background-color: #f0f0f0; border: 1px solid #d0d0d0; border-top-left-radius: 6px; }"
        )
        self.table.setStyleSheet(table_style)
        
        # 设置默认行高
        self.table.verticalHeader().setDefaultSectionSize(25)  # 设置每行高度为25像素
        
        # 禁止水平滚动
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 设置只能单行选中
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        # 设置表格为只读模式，不允许编辑
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        # 禁止选中表头
        self.table.horizontalHeader().setSectionsClickable(False)
        self.table.verticalHeader().setVisible(False)
        
        body_layout.addWidget(self.table, 1)

        #region 右侧序列操作按钮区
        right_btns = QVBoxLayout()
        right_btns.setSpacing(10)
        
        btn_style = (
            "QPushButton {"
            " background:white; color:black; font-size:16px; font-weight:bold;"
            " border:1px solid #CFD8DC; border-radius:4px; min-height:48px;"
            " }"
            "QPushButton:hover { background:#F5F7FA; }"
            "QPushButton:pressed { background:#0D47A1; color:white; }"
        )
        
        self.right_buttons = {}
        for text in ["Add", "Up", "Down", "Copy", "Paste", "Delete", "Save", "Load", "Exit"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(90)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            right_btns.addWidget(btn)
            # 将按钮存储到字典中
            if text == "Add":
                self.btn_add = btn
            elif text == "Up":
                self.btn_up = btn
            elif text == "Down":
                self.btn_down = btn
            elif text == "Copy":
                self.btn_copy = btn
            elif text == "Paste":
                self.btn_paste = btn
            elif text == "Delete":
                self.btn_delete = btn
            elif text == "Save":
                self.btn_save = btn
            elif text == "Load":
                self.btn_load = btn
            elif text == "Exit":
                self.btn_exit = btn
            self.right_buttons[text] = btn
        
        right_btns.addStretch(1)
        right_widget = QWidget(); right_widget.setLayout(right_btns)
        right_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(right_widget)
        #endregion

        # 连接信号与功能
        self.btn_add.clicked.connect(self.add_step)
        self.btn_delete.clicked.connect(self.delete_step)
        self.btn_up.clicked.connect(self.move_step_up)
        self.btn_down.clicked.connect(self.move_step_down)
        self.btn_copy.clicked.connect(self.copy_step)
        self.btn_paste.clicked.connect(self.paste_step)
        self.btn_save.clicked.connect(self.save_recipe)
        self.btn_load.clicked.connect(self.load_recipe)
        self.btn_exit.clicked.connect(self.close)

        self._copied_row = None  # 用于复制粘贴

        # 正确：将主体区添加到主布局
        main_layout.addLayout(body_layout, 1)

        # 底部脚本路径和状态显示
        bottom_layout = QHBoxLayout()
        self.path_label = QLabel("脚本路径: ")
        self.path_label.setStyleSheet("font-size:14px; color:#333;")
        bottom_layout.addWidget(self.path_label)
        bottom_layout.addStretch(1)
        self.status_label = QLabel("子序列启用状态")
        self.status_label.setStyleSheet(f"font-size:14px; color:white; background:{GREEN}; border-radius:6px; padding:2px 10px;")
        bottom_layout.addWidget(self.status_label)
        main_layout.addLayout(bottom_layout)
        
        # 如果提供了配方文件路径，则加载它
        if self.recipe_file_path:
            self.load_recipe_from_path(self.recipe_file_path)

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        for c in range(self.table.columnCount()):
            self.table.setItem(row, c, QTableWidgetItem(""))
        self.table.setItem(row, 0, QTableWidgetItem(str(row+1)))
        self.status_label.setText(f"Step {row+1} added.")
        
    def load_recipe_from_path(self, filepath):
        """从指定路径加载配方文件"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 填充基本信息字段
            general_info = data.get('GeneralInfo', {})
            self.input_fields["测试名称"].setText(general_info.get('TestName', ''))
            self.input_fields["描述"].setPlainText(general_info.get('TestContent', ''))
            
            # 显示加载状态
            self.path_label.setText(f"脚本路径: {filepath}")
            self.status_label.setText("配方加载成功")
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"无法加载配方文件: {str(e)}")

    def delete_step(self):
        rows = set(idx.row() for idx in self.table.selectedIndexes())
        for r in sorted(rows, reverse=True):
            self.table.removeRow(r)
        self.status_label.setText(f"Deleted {len(rows)} step(s).")

    def move_step_up(self):
        row = self.table.currentRow()
        if row > 0:
            for c in range(self.table.columnCount()):
                above = self.table.item(row-1, c).text() if self.table.item(row-1, c) else ""
                curr = self.table.item(row, c).text() if self.table.item(row, c) else ""
                self.table.setItem(row-1, c, QTableWidgetItem(curr))
                self.table.setItem(row, c, QTableWidgetItem(above))
            self.table.selectRow(row-1)
            self.status_label.setText("Step moved up.")

    def move_step_down(self):
        row = self.table.currentRow()
        if row < self.table.rowCount()-1 and row >= 0:
            for c in range(self.table.columnCount()):
                below = self.table.item(row+1, c).text() if self.table.item(row+1, c) else ""
                curr = self.table.item(row, c).text() if self.table.item(row, c) else ""
                self.table.setItem(row+1, c, QTableWidgetItem(curr))
                self.table.setItem(row, c, QTableWidgetItem(below))
            self.table.selectRow(row+1)
            self.status_label.setText("Step moved down.")

    def copy_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self._copied_row = [self.table.item(row, c).text() if self.table.item(row, c) else "" for c in range(self.table.columnCount())]
            self.status_label.setText("Step copied.")

    def paste_step(self):
        row = self.table.currentRow()
        if self._copied_row is not None and row >= 0:
            self.table.insertRow(row+1)
            for c, v in enumerate(self._copied_row):
                self.table.setItem(row+1, c, QTableWidgetItem(v))
            self.status_label.setText("Step pasted.")

    def _start_timer(self):
        timer = QTimer(self)
        timer.timeout.connect(self._update_time)
        timer.start(1000)
        self._update_time()

    def _update_time(self):
        now = QDateTime.currentDateTime()
        self.time_label.setText(now.toString("yyyy-MM-dd  HH:mm:ss"))

    def save_recipe(self):
        """保存配方文件到指定路径"""
        # 获取保存文件路径
        if not self.recipe_file_path:
            self.recipe_file_path, _ = QFileDialog.getSaveFileName(
                self, "保存配方文件", "", "JSON Files (*.json);;All Files (*)"
            )
            
        if self.recipe_file_path:
            try:
                # 构建要保存的数据
                data = {
                    "GeneralInfo": {
                        "TestName": self.input_fields["测试名称"].text(),
                        "Version": self.input_fields["版本号"].text(),
                        "TestContent": self.input_fields["描述"].toPlainText(),
                        "Author": self.input_fields["修改者"].text(),
                        "ID": self.input_fields["产品型号"].text(),
                        "CreatedTime": QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
                    },
                    "Steps": []
                }
                
                # 添加表格中的所有步骤
                for row in range(self.table.rowCount()):
                    step_data = {}
                    for col in range(self.table.columnCount()):
                        header = self.table.horizontalHeaderItem(col).text()
                        item = self.table.item(row, col)
                        step_data[header] = item.text() if item else ""
                    data["Steps"].append(step_data)
                
                # 写入文件
                with open(self.recipe_file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                self.path_label.setText(f"脚本路径: {self.recipe_file_path}")
                self.status_label.setText("配方保存成功")
                
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法保存配方文件: {str(e)}")
        
    def load_recipe(self):
        """打开并加载配方文件"""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "打开配方文件", "", "JSON Files (*.json);;All Files (*)"
        )
        
        if filepath:
            self.load_recipe_from_path(filepath)
            self.recipe_file_path = filepath

    def _start_timer(self):
        timer = QTimer(self)
        timer.timeout.connect(self._update_time)
        timer.start(1000)
        self._update_time()

    def _update_time(self):
        now = QDateTime.currentDateTime()
        self.time_label.setText(now.toString("yyyy-MM-dd  HH:mm:ss"))

    def save_recipe(self):
        """保存配方文件到指定路径"""
        # 获取保存文件路径
        if not self.recipe_file_path:
            self.recipe_file_path, _ = QFileDialog.getSaveFileName(
                self, "保存配方文件", "", "JSON Files (*.json);;All Files (*)"
            )
            
        if self.recipe_file_path:
            try:
                # 构建要保存的数据
                data = {
                    "GeneralInfo": {
                        "TestName": self.input_fields["测试名称"].text(),
                        "TestContent": self.input_fields["描述"].toPlainText(),
                        "CreatedTime": QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
                    },
                    "Steps": []
                }
                
                # 添加表格中的所有步骤
                for row in range(self.table.rowCount()):
                    step_data = {}
                    for col in range(self.table.columnCount()):
                        header = self.table.horizontalHeaderItem(col).text()
                        item = self.table.item(row, col)
                        step_data[header] = item.text() if item else ""
                    data["Steps"].append(step_data)
                
                # 写入文件
                with open(self.recipe_file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                self.path_label.setText(f"脚本路径: {self.recipe_file_path}")
                self.status_label.setText("配方保存成功")
                
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法保存配方文件: {str(e)}")
        
    def load_recipe(self):
        """打开并加载配方文件"""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "打开配方文件", "", "JSON Files (*.json);;All Files (*)"
        )
        
        if filepath:
            self.load_recipe_from_path(filepath)
            self.recipe_file_path = filepath

    # 可根据需要补充表格操作等方法
# 正确的主程序入口应在类定义外部
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = SubSequenceEditorDialog()
    win.show()
    sys.exit(app.exec())