# 测试流程界面
class TestPanel:
    def __init__(self):
        pass
    def show(self):
        print("Test panel shown")
