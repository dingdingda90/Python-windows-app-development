# 仪器配置界面
class InstrumentConfigWindow:
    def __init__(self):
        pass
    def show(self):
        print("Instrument config window shown")
