
# ===== sys.path 处理，确保能导入 core 包 =====
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from PySide6.QtWidgets import QMainWindow, QStackedWidget, QWidget, QVBoxLayout, QPushButton, QHBoxLayout, QFrame, QSizePolicy, QLabel
from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QParallelAnimationGroup, QTimer, QDateTime
from core.style import GLOBAL_STYLE, HEADER, SIDEBAR, BTN_SEL, GREEN, RED, GREY
from gui.pages.home import HomePage
from gui.pages.auto import AutoPage
from gui.pages.manual import ManualPage
from gui.pages.datalog import DatalogPage
from gui.pages.charts import ChartsPage
from gui.pages.alarms import AlarmsPage
from gui.pages.report import ReportPage

from gui.pages.sequence_editor import SequenceEditorPage
from gui.pages.settings import SettingsPage

from gui.sequence_editor.sequence_editor_dialog import SequenceEditorDialog
from gui.scada_db.db_table_widget import ScadaDBManagerWidget

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Leak Test")
        self.setStyleSheet(GLOBAL_STYLE)
        self.resize(1200, 800)

        # 主布局
        root = QVBoxLayout()
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        # ===== THEME =====
        
        # 顶部Header
        header = QFrame(); header.setFixedHeight(60); header.setStyleSheet(f"background:{HEADER}; border: none;")
        h_layout = QHBoxLayout(header); h_layout.setContentsMargins(10, 0, 20, 0)
        self.menu_btn = QPushButton("☰"); self.menu_btn.setFixedSize(40, 40); self.menu_btn.setCursor(Qt.PointingHandCursor)
        self.menu_btn.setStyleSheet("background:transparent; color:white; font-size:24px; font-weight:bold; border:none;")
        self.menu_btn.clicked.connect(self.toggle_sidebar)
        h_layout.addWidget(self.menu_btn)

    ### 顶部Header布局  
        # Home标题
        self.screen_title = QLabel("HOME"); self.screen_title.setStyleSheet("font-size:28px; font-weight:bold; color:white; border:none; margin-left:32px;")
        h_layout.addWidget(self.screen_title); h_layout.addStretch()
        root.addWidget(header)

        # MES状态方框
        self.mes_status = QLabel()
        self.mes_status.setFixedSize(110, 32)
        self.mes_status.setAlignment(Qt.AlignCenter)
        h_layout.addWidget(self.mes_status)

        # PLC状态方框
        self.plc_status = QLabel()
        self.plc_status.setFixedSize(110, 32)
        self.plc_status.setAlignment(Qt.AlignCenter)
        h_layout.addWidget(self.plc_status)

        # 时间显示
        self.time_label = QLabel()
        self.time_label.setStyleSheet("color:white; font-size:18px; font-weight:bold; border:none;")
        h_layout.addWidget(self.time_label)

        # 定时更新时间和状态刷新
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.timeout.connect(self.update_status_boxes)
        self.timer.start(1000)
        self.update_time()
        self.update_status_boxes()

        # 主体区域
        body = QHBoxLayout(); body.setSpacing(0)
        root.addLayout(body)

        # 侧边栏
        self.sidebar = QFrame()
        self.sidebar.setFixedWidth(200)
        self.sidebar.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.sidebar.setStyleSheet(f"background:{SIDEBAR}; border-right: 2px solid #B0BEC5;")
        self.sl = QVBoxLayout(self.sidebar); self.sl.setContentsMargins(5, 10, 5, 10); self.sl.setSpacing(5)
        body.addWidget(self.sidebar)

        # 侧边栏导航按钮
        btn_names = ["HOME", "AUTO", "MANUAL", "DATALOG", "CHARTS", "ALARMS", "REPORT", "EDITOR", "SCADA_DB", "SETTINGS"]
        self.btns = []
        for idx, name in enumerate(btn_names):
            btn = QPushButton(name)
            btn.setMinimumHeight(45)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet("QPushButton { background:white; font-size:16px; font-weight:bold; border:1px solid #CFD8DC; border-radius:4px; } QPushButton:pressed { background:#0D47A1; color:white; }")
            if name == "EDITOR":
                btn.clicked.connect(self.open_sequence_editor_dialog)
            else:
                btn.clicked.connect(lambda checked, i=idx: self.switch_page(i))
            self.sl.addWidget(btn)
            self.btns.append(btn)
        self.sl.addStretch()

        # 页面堆栈
        self.stack = QStackedWidget()
        self.pages = [
            HomePage(), AutoPage(), ManualPage(), DatalogPage(), ChartsPage(), AlarmsPage(), ReportPage(), SequenceEditorPage(),
            ScadaDBManagerWidget(db_path="scada.db"),
            SettingsPage()
        ]
        for page in self.pages:
            self.stack.addWidget(page)
        body.addWidget(self.stack)

        # 设置主容器
        container = QWidget()
        container.setLayout(root)
        self.setCentralWidget(container)

        self.sidebar_expanded = True
        self.switch_page(0)
    def update_status_boxes(self):
        # 这里可替换为实际状态检测逻辑
        mes_enabled = False   # 启用/禁用
        mes_connected = True # 连接/断开
        plc_enabled = True
        plc_connected = False
        self.mes_status.setText("MES")
        self.plc_status.setText("PLC")
        # MES
        if not mes_enabled:
            self.mes_status.setStyleSheet("background:GREY; color:#E0E0E0; border-radius:6px; font-size:15px;")
        elif mes_connected:
            self.mes_status.setStyleSheet("background:GREEN; color:#E0E0E0; border-radius:6px; font-size:15px;")
        else:
            self.mes_status.setStyleSheet("background:RED; color:#E0E0E0; border-radius:6px; font-size:15px;")

        # PLC
        if not plc_enabled:
            self.plc_status.setStyleSheet("background:GREY; color:#E0E0E0; border-radius:6px; font-size:15px;")
        elif plc_connected:
            self.plc_status.setStyleSheet("background:GREEN; color:#E0E0E0; border-radius:6px; font-size:15px;")
        else:
            self.plc_status.setStyleSheet("background:RED; color:#E0E0E0; border-radius:6px; font-size:15px;")

    def update_time(self):
        now = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        self.time_label.setText(now)

    def switch_page(self, idx):
        self.stack.setCurrentIndex(idx)
        self.screen_title.setText(self.btns[idx].text())
        for i, btn in enumerate(self.btns):
            btn.setStyleSheet(("QPushButton { background:#0D47A1; color:white; font-size:16px; font-weight:bold; border:1px solid #CFD8DC; border-radius:4px; }" if i == idx else "QPushButton { background:white; font-size:16px; font-weight:bold; border:1px solid #CFD8DC; border-radius:4px; } QPushButton:pressed { background:#0D47A1; color:white; }"))

    def toggle_sidebar(self):
        width = self.sidebar.width(); new_width = 0 if width > 0 else 200
        self.anim_group = QParallelAnimationGroup()
        anim_max = QPropertyAnimation(self.sidebar, b"maximumWidth")
        anim_max.setDuration(300); anim_max.setStartValue(width); anim_max.setEndValue(new_width); anim_max.setEasingCurve(QEasingCurve.InOutQuart)
        anim_min = QPropertyAnimation(self.sidebar, b"minimumWidth")
        anim_min.setDuration(300); anim_min.setStartValue(width); anim_min.setEndValue(new_width); anim_min.setEasingCurve(QEasingCurve.InOutQuart)
        self.anim_group.addAnimation(anim_max); self.anim_group.addAnimation(anim_min)
        self.anim_group.start()

    def open_sequence_editor_dialog(self):
        dlg = SequenceEditorDialog(self)
        dlg.exec()


# ====== 直接运行主窗口入口 ======
if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
