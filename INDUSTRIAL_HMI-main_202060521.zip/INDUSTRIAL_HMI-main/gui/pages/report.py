import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame, QHBoxLayout, QPushButton, QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView
from PySide6.QtCore import Qt
from core.style import BG

class ReportPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        nav = QFrame(); nav.setObjectName("MainPanel"); nav.setFixedHeight(60); nh = QHBoxLayout(nav)
        self.report_date_lbl = QLabel("07-05-2026"); self.report_date_lbl.setStyleSheet("font-size: 24px; font-weight: bold; color: #0D47A1;")
        prev_b = QPushButton("< PREV"); next_b = QPushButton("NEXT >"); today_b = QPushButton("TODAY")
        # prev_b.clicked.connect(lambda: self.update_rep(-1)); next_b.clicked.connect(lambda: self.update_rep(1)); today_b.clicked.connect(lambda: self.update_rep(0))  # 数据交互接口: 日期切换
        nh.addWidget(prev_b); nh.addStretch(); nh.addWidget(self.report_date_lbl); nh.addStretch(); nh.addWidget(today_b); nh.addWidget(next_b); layout.addWidget(nav)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); container = QWidget(); ch = QHBoxLayout(container)
        shifts = [("SHIFT 1 (07:30-15:30)", ["07:30-08:30", "08:30-09:30", "09:30-10:30", "10:30-11:30", "11:30-12:30", "12:30-13:30", "13:30-14:30", "14:30-15:30"]),
                  ("SHIFT 2 (15:30-23:30)", ["15:30-16:30", "16:30-17:30", "17:30-18:30", "18:30-19:30", "19:30-20:30", "20:30-21:30", "21:30-22:30", "22:30-23:30"]),
                  ("SHIFT 3 (23:30-07:30)", ["23:30-00:30", "00:30-01:30", "01:30-02:30", "02:30-03:30","03:30-04:30", "04:30-05:30", "05:30-06:30", "06:30-07:30"])]
        for title, times in shifts:
            v = QVBoxLayout(); v.addWidget(QLabel(title, styleSheet="font-weight:bold; color:#0D47A1;")); t = QTableWidget(len(times), 3); t.setHorizontalHeaderLabels(["Time", "OK", "NG"]); t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
            for i, time_range in enumerate(times): t.setItem(i, 0, QTableWidgetItem(time_range))
            v.addWidget(t); ch.addLayout(v)
        scroll.setWidget(container); layout.addWidget(scroll)
        # 数据交互接口: 可在此处添加报表数据刷新、日期切换等

if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = ReportPage()
    win.show()
    sys.exit(app.exec())
