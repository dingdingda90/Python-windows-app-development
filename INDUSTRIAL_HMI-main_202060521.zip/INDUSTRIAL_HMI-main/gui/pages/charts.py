import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame
from PySide6.QtCore import Qt
from core.style import BG

class ChartsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        l = QVBoxLayout(self)
        l.setContentsMargins(20,20,20,20)
        from PySide6.QtCharts import QChart, QLineSeries, QBarSet, QBarSeries, QChartView, QBarCategoryAxis, QValueAxis
        from PySide6.QtGui import QPen, QColor, QPainter
        self.chart_spc = QChart(); self.chart_spc.setTitle("SPC Trend (Last 20 Cycles)")
        self.series_spc = QLineSeries(); self.series_spc.setName("Leak Rate")
        self.limit_series = QLineSeries(); self.limit_series.setName("Limit")
        pen = QPen(QColor(0,0,255)); pen.setWidth(3); self.series_spc.setPen(pen)
        lpen = QPen(QColor(255,0,0)); lpen.setWidth(2); lpen.setStyle(Qt.DashLine); self.limit_series.setPen(lpen)
        self.chart_spc.addSeries(self.series_spc); self.chart_spc.addSeries(self.limit_series)
        self.chart_spc.createDefaultAxes()
        axes = self.chart_spc.axes(Qt.Vertical)
        if axes: self.axis_y_spc = axes[0]; self.axis_y_spc.setRange(0, 1.5)
        cv1 = QChartView(self.chart_spc); cv1.setRenderHint(QPainter.Antialiasing)
        f1 = QFrame(); f1.setObjectName("MainPanel"); v1 = QVBoxLayout(f1); v1.addWidget(cv1); l.addWidget(f1)
        self.chart_bar = QChart(); self.chart_bar.setTitle("Avg Leak Rate per Cavity")
        self.bar_set = QBarSet("Avg Leak"); self.bar_set.setColor(QColor("#0D47A1"))
        self.bar_series = QBarSeries(); self.bar_series.append(self.bar_set)
        self.chart_bar.addSeries(self.bar_series)
        axis_x = QBarCategoryAxis(); axis_x.append([f"C{i}" for i in range(1,8)])
        self.chart_bar.addAxis(axis_x, Qt.AlignBottom); self.bar_series.attachAxis(axis_x)
        axis_y = QValueAxis(); axis_y.setRange(0, 1.0)
        self.chart_bar.addAxis(axis_y, Qt.AlignLeft); self.bar_series.attachAxis(axis_y)
        cv2 = QChartView(self.chart_bar); cv2.setRenderHint(QPainter.Antialiasing)
        f2 = QFrame(); f2.setObjectName("MainPanel"); v2 = QVBoxLayout(f2); v2.addWidget(cv2); l.addWidget(f2)
        # self.refresh_charts()  # 数据交互接口: 刷新图表

    # def refresh_charts(self):
    #     """此处可接入图表刷新逻辑"""
    #     pass

if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = ChartsPage()
    win.show()
    sys.exit(app.exec())
