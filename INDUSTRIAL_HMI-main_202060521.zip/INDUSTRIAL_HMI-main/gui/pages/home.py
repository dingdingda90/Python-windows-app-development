import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
import json
import time

from PySide6.QtWidgets import QHeaderView, QPushButton, QTableWidget, QTableWidgetItem, QWidget, QVBoxLayout, QLabel, QApplication, QProgressBar, QHBoxLayout, QCheckBox
from PySide6.QtCore import Qt, QTimer
from core.style import BG
from gui.pages.auto import AutoPage


from PySide6.QtCore import Qt, QTimer
from core.style import BG
from gui.pages.auto import AutoPage


        # 可继续添加图片、logo等# ==================== 自动找 JSON ====================
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RECIPE_DIR = os.path.join(BASE_DIR, 'config', 'Recipe')

# 指定具体的文件名
FILE_NAME = '1K32_17_V1.2.json'  # 您想要使用的文件名
JSON_PATH = os.path.join(RECIPE_DIR, FILE_NAME)

# 验证文件是否存在
if not os.path.exists(JSON_PATH):
    print(f"错误：文件 {JSON_PATH} 不存在")
    JSON_PATH = None
# ==================== JSON → 序列化成对象 ====================
def load_json_as_object(path):
    class Obj: pass
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    root = Obj()

    # 基本信息
    root.GeneralInfo = Obj()
    for k, v in data["GeneralInfo"].items():
        setattr(root.GeneralInfo, k, v)

    # 序列
    root.Sequence = Obj()
    root.Sequence.MainSequence = []

    for seq_data in data["Sequence"]["MainSequence"]:
        seq = Obj()
        for k, v in seq_data.items():
            if k != "Steps":
                setattr(seq, k, v)

        seq.Steps = []
        for st in seq_data["Steps"]:
            step = Obj()
            for k, v in st.items():
                setattr(step, k, v)
            seq.Steps.append(step)
        root.Sequence.MainSequence.append(seq)

    return root

# ==================== 主窗口 ====================
class HomePage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        self.cfg = load_json_as_object(JSON_PATH)
        self.setWindowTitle(f"测试执行器 | {self.cfg.GeneralInfo.ID} {self.cfg.GeneralInfo.Version}")
        self.setGeometry(150, 150, 1100, 650)
        self.step_index = 0

        # UI
        layout = QVBoxLayout(self)

        # 表格
        self.table = QTableWidget()
        self.table.setColumnCount(10)
        self.table.setHorizontalHeaderLabels([
            "序列", "步骤", "类型", "测试项", "下限", "上限", "单位", "测试值", "测试结果", "执行状态"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        # 进度条和自动滚动复选框布局
        bottom_layout = QHBoxLayout()
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(15)  # 设置进度条固定高度
        bottom_layout.addWidget(self.progress_bar, 5)  # 给进度条分配更多空间
        
        # 自动滚动复选框
        self.auto_scroll_checkbox = QCheckBox("自动滚动")
        self.auto_scroll_checkbox.setChecked(True)  # 默认勾选
        self.auto_scroll_checkbox.setMaximumWidth(80)  # 设置复选框最大宽度
        bottom_layout.addWidget(self.auto_scroll_checkbox, 1)  # 给复选框分配较少空间
        
        layout.addLayout(bottom_layout)

        # 按钮
        self.start_btn = QPushButton("▶ 开始执行")
        self.start_btn.clicked.connect(self.start_run)
        layout.addWidget(self.start_btn)

        # 加载所有步骤
        self.load_steps()

    def load_steps(self):
        row = 0
        for seq in self.cfg.Sequence.MainSequence:
            for step in seq.Steps:
                self.table.insertRow(row)
                self.table.setItem(row, 0, QTableWidgetItem(seq.SubSequenceName))
                self.table.setItem(row, 1, QTableWidgetItem(str(row+1)))
                self.table.setItem(row, 2, QTableWidgetItem(step.StepType))
                self.table.setItem(row, 3, QTableWidgetItem(step.Function))
                self.table.setItem(row, 4, QTableWidgetItem(str(step.Mini or "")))
                self.table.setItem(row, 5, QTableWidgetItem(str(step.Max or "")))
                self.table.setItem(row, 6, QTableWidgetItem(str(step.Unit or "")))
                self.table.setItem(row, 7, QTableWidgetItem(str(step.TestValue or "")))
                self.table.setItem(row, 8, QTableWidgetItem(""))
                self.table.setItem(row, 9, QTableWidgetItem("等待执行"))
                row += 1

    def start_run(self):
        self.start_btn.setEnabled(False)
        self.step_index = 0  # 重置步骤索引
        self.table.setRowCount(0)  # 清空表格
        self.load_steps()  # 重新加载步骤
        self.run_next_step()

    def run_next_step(self):
        if self.step_index >= self.table.rowCount():
            self.table.item(self.step_index-1, 9).setText("✅ 全部完成")
            self.progress_bar.setValue(100)  # 完成时进度条满
            self.start_btn.setEnabled(True)
            return
 
        row = self.step_index
        step_type = self.table.item(row, 2).text()
 
        # 执行中
        self.table.item(row, 9).setText("执行中...")
        QApplication.processEvents()
        
        # 更新进度条
        progress = int((self.step_index / self.table.rowCount()) * 100)
        self.progress_bar.setValue(progress)
        
        # 自动滚动到当前行（如果启用了自动滚动）
        if self.auto_scroll_checkbox.isChecked():
            self.table.scrollToItem(self.table.item(row, 0))
 
        # 模拟执行
        time.sleep(0.1)
 
        # 模拟结果
        mini = self.table.item(row, 4).text()
        max_val = self.table.item(row, 5).text()
        result = "PASS" if mini and max_val else "DONE"
 
        self.table.item(row, 8).setText(result)
        self.table.item(row, 9).setText("✅ 已完成")
 
        self.step_index += 1
        QTimer.singleShot(100, self.run_next_step)

# ==================== 启动 ====================
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = HomePage()
    win.show()
    sys.exit(app.exec())