import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QHBoxLayout
from PySide6.QtCore import Qt
from core.style import BG

class SequenceEditorPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        layout = QVBoxLayout(self)
        title = QLabel("Test Sequence Editor")
        title.setStyleSheet("font-size:28px; font-weight:bold; color:black;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Sequence table
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Step", "Action Type", "Parameter", "Comment"])
        layout.addWidget(self.table)

        # Action buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Step")
        del_btn = QPushButton("Delete Step")
        save_btn = QPushButton("Save Sequence")
        load_btn = QPushButton("Load Sequence")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(del_btn)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(load_btn)
        layout.addLayout(btn_layout)

        # Event bindings
        add_btn.clicked.connect(self.add_step)
        del_btn.clicked.connect(self.del_step)

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(str(row+1)))
        self.table.setItem(row, 1, QTableWidgetItem("Action"))
        self.table.setItem(row, 2, QTableWidgetItem("Parameter"))
        self.table.setItem(row, 3, QTableWidgetItem("Comment"))

    def del_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self.table.removeRow(row)

# 正确的主程序入口应在类定义外部
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = SequenceEditorPage()
    win.show()
    sys.exit(app.exec())