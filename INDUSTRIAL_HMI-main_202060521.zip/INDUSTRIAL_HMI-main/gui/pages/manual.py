import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt
from core.style import BG

class ManualPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        l = QVBoxLayout(self)
        l.setContentsMargins(20,20,20,20)
        sections = [("Shuttle Control", ["Shuttle FWD", "Shuttle REV"]), ("Top Clamp", ["Clamp FWD", "Clamp REV"]),
                    ("ATEQ Tester", ["ATEQ Start", "ATEQ Stop"]), ("Utility", ["Air Blow", "Reset Alarm"])]
        for title, btns in sections:
            f = QFrame(); f.setObjectName("MainPanel"); sl = QVBoxLayout(f); sl.addWidget(QLabel(title, objectName="SectionHeading"))
            hb = QHBoxLayout(); [hb.addWidget(QPushButton(b, objectName="ControlBox")) for b in btns]; sl.addLayout(hb); l.addWidget(f)
        # 数据交互接口: 可在此处添加按钮事件处理等

if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = ManualPage()
    win.show()
    sys.exit(app.exec())
