import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QHeaderView
from PySide6.QtCore import Qt
from core.style import BG

class AlarmsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        l = QVBoxLayout(self)
        l.setContentsMargins(20,20,20,20)
        l.addWidget(QLabel("ALARM HISTORY", objectName="SectionHeading"))
        self.alarm_table = QTableWidget(5, 4)  # DEMO: 5行空数据
        self.alarm_table.setHorizontalHeaderLabels(["Date", "Time", "Message", "Type"])
        self.alarm_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        # self.refresh_alarms()  # 数据交互接口: 刷新报警表
        l.addWidget(self.alarm_table)

    # def refresh_alarms(self):
    #     """此处可接入报警表刷新逻辑"""
    #     pass

if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = AlarmsPage()
    win.show()
    sys.exit(app.exec())
