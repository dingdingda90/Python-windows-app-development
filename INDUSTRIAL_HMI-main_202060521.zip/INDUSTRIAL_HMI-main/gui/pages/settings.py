from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PySide6.QtCore import Qt
from core.style import BG

class SettingsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        layout = QVBoxLayout(self)
        title = QLabel("SETTINGS PAGE")
        title.setStyleSheet("font-size:28px; font-weight:bold; color:black;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        # 可继续添加设置页面的详细布局
