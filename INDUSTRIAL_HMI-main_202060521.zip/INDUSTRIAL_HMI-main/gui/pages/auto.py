import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QFrame, QGridLayout, QPushButton, QSizePolicy
from PySide6.QtCore import Qt
from core.style import BG
from core.producer_consumer import AutoFlowController

class AutoPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        root = QVBoxLayout(self)
        root.setContentsMargins(15, 15, 15, 15)
        root.setSpacing(10)

        # DEMO: 扫描器旁路警告横幅
        self.bypass_banner = QLabel("⚠ WARNING: SCANNER BYPASS ACTIVE ⚠")
        self.bypass_banner.setAlignment(Qt.AlignCenter)
        self.bypass_banner.setStyleSheet("background: #FFEB3B; color: black; font-weight: bold; font-size: 18px; padding: 8px; border: 2px solid #FBC02D; border-radius: 4px;")
        self.bypass_banner.setVisible(False)  # 数据交互接口: 控制旁路显示
        root.addWidget(self.bypass_banner)

        # 顶部条件与泄漏值
        top = QHBoxLayout()
        root.addLayout(top)

        # HOME CONDITIONS 区块
        cond = QFrame(); cond.setObjectName("MainPanel"); cond.setFixedWidth(400)
        cl = QVBoxLayout(cond)
        cl.addWidget(QLabel("HOME CONDITIONS", objectName="SectionHeading"))
        self.lamp_labels = []
        for s in ["Auto Mode", "Hydraulic", "Emergency", "Inlet Air Pressure", "Shuttle Rev Sensor", "Top Rev Sensor", "Component Sensor"]:
            row = QHBoxLayout()
            row.addWidget(QLabel(s, styleSheet="font-size: 16px;"))
            row.addStretch()
            lamp = self.lamp(False)
            self.lamp_labels.append(lamp)
            row.addWidget(lamp)  # 数据交互接口: 控制灯状态
            cl.addLayout(row)
        cl.addStretch()
        top.addWidget(cond)

        # LEAK TEST VALUES 区块
        cav = QFrame(); cav.setObjectName("MainPanel")
        cav_layout = QGridLayout(cav)
        cav_layout.addWidget(QLabel("LEAK TEST VALUES", objectName="SectionHeading"), 0, 0, 1, 2)
        self.leak_labels = []
        for i in range(7):
            v = QLabel("0.000")
            v.setStyleSheet("background: #000; color: #00FF00; font-family: 'Courier New'; font-size: 22px; padding: 5px; font-weight: bold; border-radius: 4px;")
            self.leak_labels.append(v)
            cav_layout.addWidget(QLabel(f"Cav {i+1}", styleSheet="font-size: 18px; font-weight: bold;"), i+1, 0)
            cav_layout.addWidget(v, i+1, 1)
        top.addWidget(cav, 1)

        # 中部统计区
        mid = QHBoxLayout()
        root.addLayout(mid)
        def cb(t, obj_name=None):
            f = QFrame(); f.setObjectName("MainPanel"); v = QVBoxLayout(f)
            v.addWidget(QLabel(t, styleSheet="font-weight: bold; font-size: 16px;"))
            lbl = QLabel("0", styleSheet="font-size: 36px; font-weight: bold; color: #0D47A1;")
            v.addWidget(lbl)
            if obj_name: setattr(self, obj_name, lbl)
            return f
        mid.addWidget(cb("JOB OK", "cnt_ok_lbl"))
        mid.addWidget(cb("JOB NG", "cnt_ng_lbl"))
        mid.addWidget(cb("YIELD %", "yield_val_lbl"))

        # 扫码区块
        scan_f = QFrame(); scan_f.setObjectName("MainPanel"); scan_f.setStyleSheet("background: #FFF9C4;")
        sv = QVBoxLayout(scan_f)
        sv.addWidget(QLabel("SCAN DATA", styleSheet="font-weight: bold;"))
        self.scan_label = QLabel("WAITING...", styleSheet="font-size: 28px; font-weight: bold;")
        sv.addWidget(self.scan_label)
        mid.addWidget(scan_f, 1)

        # 底部系统状态
        self.r_msg = QLabel("SYSTEM READY")
        self.r_msg.setAlignment(Qt.AlignCenter)
        self.r_msg.setFixedHeight(50)
        self.r_msg.setStyleSheet("background: #263238; color: white; font-size: 24px; font-weight: bold; border-radius: 4px;")
        root.addWidget(self.r_msg)

        # ===== 自动流程控制器集成 =====
        self.controller = AutoFlowController()
        self.controller.signals.scan_received.connect(self.on_scan_received)
        self.controller.signals.test_started.connect(self.on_test_started)
        self.controller.signals.test_result.connect(self.on_test_result)
        self.controller.signals.status_update.connect(self.on_status_update)
        self.controller.start()

    def lamp(self, on=False):
        l = QLabel(); l.setFixedSize(30, 30)
        color = "#4CAF50" if on else "#BDBDBD"
        l.setStyleSheet(f"background:{color}; border-radius:15px; border: 2px solid #757575;")
        return l

    # ===== 信号槽处理 =====
    def on_scan_received(self, sn):
        self.scan_label.setText(sn)
        self.r_msg.setText("扫码完成，准备测试...")
        # 可在此处点亮某些灯
        self.lamp_labels[0].setStyleSheet("background:#4CAF50; border-radius:15px; border: 2px solid #757575;")

    def on_test_started(self, sn):
        self.r_msg.setText(f"测试中: {sn}")
        # 可在此处模拟刷新泄漏值
        import random
        for lbl in self.leak_labels:
            v = random.uniform(0.1, 1.2)
            lbl.setText(f"{v:.3f}")

    def on_test_result(self, sn, ok):
        self.r_msg.setText(f"测试完成: {sn} 结果: {'OK' if ok else 'NG'}")
        if ok:
            self.cnt_ok_lbl.setText(str(int(self.cnt_ok_lbl.text())+1))
        else:
            self.cnt_ng_lbl.setText(str(int(self.cnt_ng_lbl.text())+1))
        total = int(self.cnt_ok_lbl.text()) + int(self.cnt_ng_lbl.text())
        if total > 0:
            yield_pct = int(self.cnt_ok_lbl.text()) / total * 100
            self.yield_val_lbl.setText(f"{yield_pct:.1f}%")
        # 恢复灯状态
        self.lamp_labels[0].setStyleSheet("background:#BDBDBD; border-radius:15px; border: 2px solid #757575;")

    def on_status_update(self, msg):
        self.r_msg.setText(msg)

    # 数据交互接口: 可在此处添加数据刷新、旁路控制等方法

if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = AutoPage()
    win.show()
    sys.exit(app.exec())
