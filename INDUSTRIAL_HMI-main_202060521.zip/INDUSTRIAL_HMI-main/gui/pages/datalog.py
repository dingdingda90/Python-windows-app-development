import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView
from PySide6.QtCore import Qt
from core.style import BG

class DatalogPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        l = QVBoxLayout(self)
        l.setContentsMargins(20,20,20,20)
        l.addWidget(QLabel("DATALOG", objectName="SectionHeading"))
        search_layout = QHBoxLayout(); search_lbl = QLabel("Search Serial:"); search_lbl.setStyleSheet("font-weight:bold; font-size:16px;")
        self.search_bar = QLineEdit(); self.search_bar.setPlaceholderText("Filter..."); self.search_bar.setStyleSheet("font-size: 16px; padding: 6px; border: 1px solid #B0BEC5; border-radius: 4px;")
        # self.search_bar.textChanged.connect(self.filter_datalog)  # 数据交互接口: 过滤功能
        search_layout.addWidget(search_lbl); search_layout.addWidget(self.search_bar); l.addLayout(search_layout)

        self.datalog_table = QTableWidget(5, 11)  # DEMO: 5行空数据
        cols = ["Date", "Time", "Serial", "Result", "C1 Leak", "C2 Leak", "C3 Leak", "C4 Leak", "C5 Leak", "C6 Leak", "C7 Leak"]
        self.datalog_table.setHorizontalHeaderLabels(cols)
        self.datalog_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.datalog_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive); self.datalog_table.horizontalHeader().setDefaultSectionSize(100)
        # self.refresh_datalog()  # 数据交互接口: 刷新数据表
        l.addWidget(self.datalog_table)

    # def refresh_datalog(self):
    #     """此处可接入数据表刷新逻辑"""
    #     pass

    # def filter_datalog(self, text):
    #     """此处可接入数据表过滤逻辑"""
    #     pass

if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = DatalogPage()
    win.show()
    sys.exit(app.exec())
