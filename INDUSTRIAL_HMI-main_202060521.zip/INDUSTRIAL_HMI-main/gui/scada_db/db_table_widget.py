
import sqlite3
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QHBoxLayout, QMessageBox, QLineEdit, QLabel, QComboBox
)
from PySide6.QtCore import Qt

class ScadaDBManagerWidget(QWidget):
    def __init__(self, db_path, parent=None):
        super().__init__(parent)
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.setWindowTitle("SCADA DB Manager")
        layout = QVBoxLayout(self)

        # 表选择下拉框
        tablebar = QHBoxLayout()
        tablebar.addWidget(QLabel("Table:"))
        self.table_combo = QComboBox()
        tablebar.addWidget(self.table_combo)
        layout.addLayout(tablebar)

        # 工具栏
        toolbar = QHBoxLayout()
        self.add_btn = QPushButton("Add")
        self.del_btn = QPushButton("Delete")
        self.save_btn = QPushButton("Save")
        toolbar.addWidget(self.add_btn)
        toolbar.addWidget(self.del_btn)
        toolbar.addWidget(self.save_btn)
        layout.addLayout(toolbar)

        # 表格
        self.table = QTableWidget()
        layout.addWidget(self.table)

        # 查询栏
        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("Search:"))
        self.search_edit = QLineEdit()
        search_layout.addWidget(self.search_edit)
        self.search_btn = QPushButton("Go")
        search_layout.addWidget(self.search_btn)
        layout.addLayout(search_layout)

        # 信号
        self.add_btn.clicked.connect(self.add_row)
        self.del_btn.clicked.connect(self.delete_row)
        self.save_btn.clicked.connect(self.save_changes)
        self.search_btn.clicked.connect(self.search)
        self.table_combo.currentTextChanged.connect(self.load_table)

        self.refresh_table_list()

    def refresh_table_list(self):
        cur = self.conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cur.fetchall()]
        self.table_combo.clear()
        self.table_combo.addItems(tables)
        if tables:
            self.load_table(tables[0])

    def load_table(self, table_name=None):
        if table_name is None:
            table_name = self.table_combo.currentText()
        if not table_name:
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            return
        self.current_table = table_name
        cur = self.conn.cursor()
        cur.execute(f"SELECT * FROM {table_name}")
        rows = cur.fetchall()
        headers = [d[0] for d in cur.description]
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, val in enumerate(row):
                self.table.setItem(r, c, QTableWidgetItem(str(val)))

    def add_row(self):
        row = self.table.rowCount()
        self.table.insertRow(row)

    def delete_row(self):
        rows = set(idx.row() for idx in self.table.selectedIndexes())
        for r in sorted(rows, reverse=True):
            self.table.removeRow(r)

    def save_changes(self):
        cur = self.conn.cursor()
        cur.execute(f"DELETE FROM {self.current_table}")
        for r in range(self.table.rowCount()):
            values = [self.table.item(r, c).text() if self.table.item(r, c) else '' for c in range(self.table.columnCount())]
            placeholders = ','.join(['?'] * len(values))
            cur.execute(f"INSERT INTO {self.current_table} VALUES ({placeholders})", values)
        self.conn.commit()
        QMessageBox.information(self, "Saved", "Changes saved to database.")

    def search(self):
        text = self.search_edit.text().strip()
        if not text:
            self.load_table()
            return
        cur = self.conn.cursor()
        headers = [self.table.horizontalHeaderItem(i).text() for i in range(self.table.columnCount())]
        query = f"SELECT * FROM {self.current_table} WHERE " + " OR ".join([f"{h} LIKE ?" for h in headers])
        params = [f"%{text}%"] * len(headers)
        cur.execute(query, params)
        rows = cur.fetchall()
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, val in enumerate(row):
                self.table.setItem(r, c, QTableWidgetItem(str(val)))
