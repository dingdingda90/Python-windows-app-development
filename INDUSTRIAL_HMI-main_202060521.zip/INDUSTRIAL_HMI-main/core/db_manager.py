import sqlite3
import logging

class DBManager:
    def __init__(self, db_file="scada.db"):
        self.db_file = db_file
        self.conn = None
        self.cursor = None
        self.connect()
        self.init_tables()

    def connect(self):
        try:
            self.conn = sqlite3.connect(self.db_file)
            self.cursor = self.conn.cursor()
        except Exception as e:
            logging.error(f"DB Connect Error: {e}")

    def init_tables(self):
        try:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS cycles_v2 (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT, time TEXT, serial TEXT, result TEXT,
                c1 REAL, c2 REAL, c3 REAL, c4 REAL, c5 REAL, c6 REAL, c7 REAL)''')
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS alarms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT, time TEXT, message TEXT, type TEXT)''')
            self.conn.commit()
        except Exception as e:
            logging.error(f"DB Init Error: {e}")

    def close(self):
        if self.conn:
            self.conn.close()
