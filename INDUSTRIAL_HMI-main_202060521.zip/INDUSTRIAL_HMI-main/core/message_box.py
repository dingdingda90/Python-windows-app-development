# 消息提示与交互
class MessageBox:
    @staticmethod
    def show(message):
        print(f"[MESSAGE] {message}")
