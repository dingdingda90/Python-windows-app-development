# 变量与数据管理
class VariableManager:
    def __init__(self):
        self.variables = {}
    def set(self, name, value):
        self.variables[name] = value
    def get(self, name, default=None):
        return self.variables.get(name, default)
