# 状态机与流程控制
class StateMachine:
    def __init__(self):
        self.state = None
    def set_state(self, state):
        self.state = state
    def run(self):
        while self.state:
            self.state = self.state.execute()
