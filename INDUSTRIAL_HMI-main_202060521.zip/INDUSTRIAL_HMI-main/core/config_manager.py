import os
import json

class ConfigManager:
    def __init__(self, config_file="config.json"):
        self.config_file = config_file
        self.defaults = {"leak_limit": 0.8, "bypass": False, "plc_ip": "192.168.0.1", "plc_port": 502}
        self.config = self.load_config()

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except Exception:
                return self.defaults.copy()
        else:
            self.save_config(self.defaults)
            return self.defaults.copy()

    def save_config(self, config=None):
        if config is not None:
            self.config = config
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f)
        except Exception:
            pass
