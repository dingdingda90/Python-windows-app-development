# 测试序列执行器
class TestExecutor:
    def __init__(self, sequence, variable_manager):
        self.sequence = sequence
        self.variable_manager = variable_manager
    def execute(self):
        for step in self.sequence:
            # 执行每一步
            step.execute(self.variable_manager)
