# 测试序列图形化编辑器（骨架）
class SequenceEditor:
    def __init__(self):
        pass
    def load_sequence(self, path):
        pass
    def save_sequence(self, path):
        pass
    def edit(self):
        pass
