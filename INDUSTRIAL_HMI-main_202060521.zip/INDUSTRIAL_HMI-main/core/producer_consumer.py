
import threading
import queue
import time
from PySide6.QtCore import QObject, Signal

class AutoFlowSignals(QObject):
    """
    信号定义类，所有流程相关信号都在这里定义
    """
    scan_received = Signal(str)         # 扫码完成，参数为扫码内容
    test_started = Signal(str)          # 测试开始，参数为扫码内容
    test_result = Signal(str, bool)     # 测试结果，参数为扫码内容和结果(True=OK, False=NG)
    status_update = Signal(str)         # 状态文本更新

class AutoStateMachine:
    """
    自动流程状态机，管理流程状态
    """
    IDLE = 'IDLE'
    WAIT_SCAN = 'WAIT_SCAN'
    TESTING = 'TESTING'
    FINISHED = 'FINISHED'

    def __init__(self):
        self.state = self.IDLE
        self.current_sn = None

    def reset(self):
        self.state = self.WAIT_SCAN
        self.current_sn = None

    def on_scan(self, sn):
        if self.state == self.WAIT_SCAN:
            self.current_sn = sn
            self.state = self.TESTING
            return True
        return False

    def on_test_done(self):
        if self.state == self.TESTING:
            self.state = self.FINISHED
            return True
        return False

    def ready_for_next(self):
        return self.state == self.FINISHED

class ProducerThread(threading.Thread):
    """
    生产者线程，模拟扫码枪扫码
    """
    def __init__(self, queue, signals):
        super().__init__(daemon=True)
        self.queue = queue
        self.signals = signals
        self.running = True

    def run(self):
        while self.running:
            # 模拟等待扫码
            time.sleep(3)  # 3秒后自动扫码
            sn = f"SN{int(time.time())%10000}"
            self.queue.put(sn)
            self.signals.scan_received.emit(sn)
            # 等待主流程消费后再继续
            time.sleep(2)

    def stop(self):
        self.running = False

class ConsumerThread(threading.Thread):
    """
    消费者线程，驱动自动流程
    """
    def __init__(self, queue, signals, state_machine):
        super().__init__(daemon=True)
        self.queue = queue
        self.signals = signals
        self.state_machine = state_machine
        self.running = True

    def run(self):
        self.state_machine.reset()
        self.signals.status_update.emit("等待扫码...")
        while self.running:
            sn = self.queue.get()  # 阻塞等待扫码
            if not self.running:
                break
            if self.state_machine.on_scan(sn):
                self.signals.status_update.emit(f"扫码完成: {sn}")
                self.signals.test_started.emit(sn)
                # 模拟测试过程
                time.sleep(2)
                # 随机结果
                import random
                result = random.random() > 0.2
                self.signals.test_result.emit(sn, result)
                self.signals.status_update.emit(f"测试完成: {sn} 结果: {'OK' if result else 'NG'}")
                self.state_machine.on_test_done()
                # 等待界面处理后再进入下一轮
                time.sleep(2)
                self.state_machine.reset()
                self.signals.status_update.emit("等待扫码...")

    def stop(self):
        self.running = False
        # 解除阻塞
        self.queue.put(None)

class AutoFlowController:
    """
    自动流程控制器，负责启动/停止流程，连接信号槽
    """
    def __init__(self):
        self.signals = AutoFlowSignals()
        self.queue = queue.Queue()
        self.state_machine = AutoStateMachine()
        self.producer = ProducerThread(self.queue, self.signals)
        self.consumer = ConsumerThread(self.queue, self.signals, self.state_machine)

    def start(self):
        self.producer.start()
        self.consumer.start()

    def stop(self):
        self.producer.stop()
        self.consumer.stop()

# 用法示例（在UI层连接信号）：
# from core.producer_consumer import AutoFlowController
# controller = AutoFlowController()
# controller.signals.scan_received.connect(lambda sn: print('扫码:', sn))
# controller.signals.test_started.connect(lambda sn: print('测试开始:', sn))
# controller.signals.test_result.connect(lambda sn, ok: print('测试结果:', sn, ok))
# controller.signals.status_update.connect(lambda msg: print('状态:', msg))
# controller.start()
