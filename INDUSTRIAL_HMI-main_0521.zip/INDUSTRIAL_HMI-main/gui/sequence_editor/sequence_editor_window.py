# 测试序列编辑界面
class SequenceEditorWindow:
    def __init__(self):
        pass
    def show(self):
        print("Sequence editor window shown")
