import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QLineEdit, QTextEdit, QWidget, QSizePolicy, QFrame, QHeaderView, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt, QTimer, QDateTime
from core.style import BG, HEADER, SIDEBAR, BTN_SEL, GREEN, RED, GREY, GLOBAL_STYLE


class SequenceEditorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("测试主序列编辑界面")
        self.setStyleSheet(GLOBAL_STYLE)
        self.resize(1000, 700)

        main_layout = QVBoxLayout(self)
        # 顶部 Header
        header = QFrame()
        header.setFixedHeight(60)
        header.setStyleSheet(f"background:{HEADER}; border: none;")

        # 最核心：用 QGridLayout 让 标题 和 时间 重叠布局！
        header_layout = QGridLayout(header)
        header_layout.setContentsMargins(10, 2, 10, 2)
        header_layout.setSpacing(0)

        # ======================
        # 标题：真正 100% 正中心（不受时间影响）
        # ======================
        self.title_label = QLabel("测试主序列编辑界面")
        self.title_label.setObjectName("ScreenTitle")
        self.title_label.setStyleSheet("font-size:28px; font-weight:bold; color:white; border:none;")
        self.title_label.setAlignment(Qt.AlignCenter)

        # 放在 0行0列，占满整个网格 → 绝对居中
        header_layout.addWidget(self.title_label, 0, 0, Qt.AlignCenter)

        # ======================
        # 时间：纯右下角，不占位置、不影响居中
        # ======================
        self.time_label = QLabel()
        self.time_label.setObjectName("TimeLabel")
        self.time_label.setStyleSheet("font-size:14px; color:white;")

        # 同样放在 0行0列，但是靠右下对齐 → 叠在标题上面！
        header_layout.addWidget(self.time_label, 0, 0, Qt.AlignRight | Qt.AlignBottom)

        main_layout.addWidget(header)
        self._start_timer()

        #region 脚本信息输入区
        input_frame = QFrame()
        input_layout = QGridLayout(input_frame)
        input_frame.setStyleSheet("background:white; border:1px solid #B0BEC5; border-radius:4px;")
        input_frame.setObjectName("MainPanel")
        labels = ["测试名称", "版本号", "描述", "修改者", "产品型号"]
        self.inputs = {}
        for i, label in enumerate(labels):
            l = QLabel(label)
            l.setStyleSheet("font-size:16px; font-weight:bold; border: none;")
            l.setObjectName("InputLabel")
            input_layout.addWidget(l, i//3, (i%3)*2)
            if label == "描述":
                w = QTextEdit()
                w.setFixedHeight(40)
            else:
                w = QLineEdit()
            w.setStyleSheet("font-size:14px; padding: 5px;background: transparent;")
            w.setReadOnly(True)  # 设置只读，去除光标
            self.inputs[label] = w
            input_layout.addWidget(w, i//3, (i%3)*2+1)
        main_layout.addWidget(input_frame)
        #endregion

        #region 主体区（左-中-右）
        body_layout = QHBoxLayout()

        btn_style = (
            "QPushButton {"
            " background:white; color:black; font-size:16px; font-weight:bold;"
            " border:1px solid #CFD8DC; border-radius:4px; min-height:48px;"
            " }"
            "QPushButton:hover { background:#F5F7FA; }"
            "QPushButton:pressed { background:#0D47A1; color:white; }"
        )

        #region 左侧脚本操作按钮区    
        left_btns = QVBoxLayout()
        left_btns.setSpacing(10)

        self.left_buttons = {}
        for text in ["Select", "New", "SaveAs", "Delete", "Save", "Exit"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(110)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            left_btns.addWidget(btn)
            self.left_buttons[text] = btn
        left_btns.addStretch(1)
        left_widget = QWidget(); left_widget.setLayout(left_btns)
        left_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(left_widget)
        #endregion

        #region 中间主序列表格
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["测试流程名称", "描述", "是否启用"])
        table_style = """
            QTableWidget::item:selected {
                background-color: blue;
                color: white;
            }
            QTableWidget {
                font-size:15px;
            }
        """
        self.table.setStyleSheet(table_style)

        # 设置列宽占满整个宽度
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Fixed)
        self.table.setColumnWidth(2, 80)
        # 设置默认行高
        self.table.verticalHeader().setDefaultSectionSize(20)  # 设置每行高度为20像素

        # 禁止水平滚动
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 设置只能单行选中
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        body_layout.addWidget(self.table, 1)
        #endregion

        #region 右侧序列操作按钮区
        right_btns = QVBoxLayout()
        right_btns.setSpacing(10)
        self.right_buttons = {}
        for text in ["Add", "Up", "Down", "Copy", "Paste", "Delete"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(110)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            right_btns.addWidget(btn)
            self.right_buttons[text] = btn
        right_btns.addStretch(1)
        right_widget = QWidget(); right_widget.setLayout(right_btns)
        right_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(right_widget)
        main_layout.addLayout(body_layout, 1)
        #endregion

        #region 底部脚本路径显示
        self.path_label = QLabel("脚本路径: ")
        self.path_label.setStyleSheet("font-size:14px; color:#333;")
        main_layout.addWidget(self.path_label)
        #endregion

        #region 事件绑定
        # 绑定左侧按钮事件
        self.left_buttons["Exit"].clicked.connect(self.close)
        self.left_buttons["Select"].clicked.connect(self._select_script)
        self.left_buttons["New"].clicked.connect(self._new_script)
        self.left_buttons["SaveAs"].clicked.connect(self._save_as_script)
        self.left_buttons["Delete"].clicked.connect(self._delete_script)
        self.left_buttons["Save"].clicked.connect(self._save_script)

        # 绑定右侧按钮事件
        self.right_buttons["Add"].clicked.connect(self.add_step)
        self.right_buttons["Up"].clicked.connect(self.move_up_step)
        self.right_buttons["Down"].clicked.connect(self.move_down_step)
        self.right_buttons["Copy"].clicked.connect(self.copy_step)
        self.right_buttons["Paste"].clicked.connect(self.paste_step)
        self.right_buttons["Delete"].clicked.connect(self.del_step)

        # 绑定表格双击事件，弹出子序列编辑窗口
        self.table.cellDoubleClicked.connect(self.open_subsequence_editor)
        #endregion

        # 初始化剪贴板
        self.copied_row = None

    def open_subsequence_editor(self, row, col):
        # 只在点击“测试流程名称”那一列时弹窗（可根据需要调整）
        if col == 0:
            try:
                from gui.sequence_editor.subsequence_editor_dialog import SubSequenceEditorDialog
            except ImportError:
                from .subsequence_editor_dialog import SubSequenceEditorDialog
            dlg = SubSequenceEditorDialog(self)
            dlg.exec()

    def _start_timer(self):
        timer = QTimer(self)
        timer.timeout.connect(self._update_time)
        timer.start(1000)
        self._update_time()

    def _update_time(self):
        now = QDateTime.currentDateTime()
        self.time_label.setText(now.toString("yyyy-MM-dd  HH:mm:ss"))

    # 可根据需要补充表格操作等方法

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(f"流程{row+1}"))
        self.table.setItem(row, 1, QTableWidgetItem("描述"))
        self.table.setItem(row, 2, QTableWidgetItem("是"))

    def _show_not_implemented(self, btn_name):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "提示", f"[{btn_name}] 功能暂未实现。")

    #region 左侧按钮功能
    def _select_script(self):
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择脚本文件", "", "JSON Files (*.json);;All Files (*.*)"
        )
        if file_path:
            self.path_label.setText(f"脚本路径: {file_path}")
            QMessageBox.information(self, "提示", "脚本加载成功！")

    def _new_script(self):
        from PySide6.QtWidgets import QMessageBox
        # 清空所有内容
        self.table.setRowCount(0)
        for input_name in self.inputs:
            if isinstance(self.inputs[input_name], QLineEdit):
                self.inputs[input_name].clear()
            else:
                self.inputs[input_name].clear()
        self.path_label.setText("脚本路径: ")
        QMessageBox.information(self, "提示", "已创建新脚本！")

    def _save_as_script(self):
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存脚本文件", "", "JSON Files (*.json)"
        )
        if file_path:
            if not file_path.endswith(".json"):
                file_path += ".json"
            self.path_label.setText(f"脚本路径: {file_path}")
            QMessageBox.information(self, "提示", "脚本另存成功！")

    def _delete_script(self):
        from PySide6.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, "确认删除", "确定要删除当前脚本吗？",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self._new_script()

    def _save_script(self):
        from PySide6.QtWidgets import QMessageBox
        path = self.path_label.text().replace("脚本路径: ", "")
        if not path:
            self._save_as_script()
        else:
            QMessageBox.information(self, "提示", "脚本保存成功！")
    #endregion

    #region 右侧按钮功能
    def del_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self.table.removeRow(row)

    def move_up_step(self):
        row = self.table.currentRow()
        if row > 0:
            # 获取当前行数据
            name = self.table.item(row, 0).text()
            desc = self.table.item(row, 1).text()
            enabled = self.table.item(row, 2).text()
            # 删除当前行
            self.table.removeRow(row)
            # 在上方插入
            self.table.insertRow(row - 1)
            self.table.setItem(row - 1, 0, QTableWidgetItem(name))
            self.table.setItem(row - 1, 1, QTableWidgetItem(desc))
            self.table.setItem(row - 1, 2, QTableWidgetItem(enabled))
            # 选中新位置
            self.table.selectRow(row - 1)

    def move_down_step(self):
        row = self.table.currentRow()
        if row >= 0 and row < self.table.rowCount() - 1:
            # 获取当前行数据
            name = self.table.item(row, 0).text()
            desc = self.table.item(row, 1).text()
            enabled = self.table.item(row, 2).text()
            # 删除当前行
            self.table.removeRow(row)
            # 在下方插入
            self.table.insertRow(row + 1)
            self.table.setItem(row + 1, 0, QTableWidgetItem(name))
            self.table.setItem(row + 1, 1, QTableWidgetItem(desc))
            self.table.setItem(row + 1, 2, QTableWidgetItem(enabled))
            # 选中新位置
            self.table.selectRow(row + 1)

    def copy_step(self):
        row = self.table.currentRow()
        if row >= 0:
            # 保存复制的行数据
            self.copied_row = {
                "name": self.table.item(row, 0).text(),
                "desc": self.table.item(row, 1).text(),
                "enabled": self.table.item(row, 2).text()
            }
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.information(self, "提示", "已复制当前行！")

    def paste_step(self):
        if self.copied_row:
            row = self.table.currentRow()
            if row < 0:
                row = self.table.rowCount()
            else:
                row += 1
            # 插入新行
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(self.copied_row["name"]))
            self.table.setItem(row, 1, QTableWidgetItem(self.copied_row["desc"]))
            self.table.setItem(row, 2, QTableWidgetItem(self.copied_row["enabled"]))
            # 选中新插入的行
            self.table.selectRow(row)
        else:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "提示", "请先复制一行数据！")
    #endregion
# 正确的主程序入口应在类定义外部
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = SequenceEditorDialog()
    win.show()
    sys.exit(app.exec())