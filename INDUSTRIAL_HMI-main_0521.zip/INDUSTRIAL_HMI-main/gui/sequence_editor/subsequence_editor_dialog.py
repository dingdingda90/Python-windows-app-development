
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QWidget, QTreeWidget, QTreeWidgetItem, QTextEdit, QSizePolicy, QFrame
)
from PySide6.QtCore import Qt, QTimer, QDateTime
from core.style import BG, SIDEBAR, GREEN
import os
from gui.sequence_editor.module_tree import ModuleTreeWidget

class SubSequenceEditorDialog(QDialog):
    def __init__(self, parent=None, module_config_path=None):
        super().__init__(parent)
        self.setWindowTitle("测试子序列编辑界面")
        self.setStyleSheet(f"background-color: {BG};")
        self.resize(1200, 700)

        main_layout = QVBoxLayout(self)
        # 顶部标题和时间
        top_layout = QHBoxLayout()
        self.title_label = QLabel("测试子序列编辑界面")
        self.title_label.setStyleSheet("font-size:32px; font-weight:bold; color:#1565C0;")
        self.title_label.setAlignment(Qt.AlignCenter)
        top_layout.addWidget(self.title_label, 1)
        self.time_label = QLabel()
        self.time_label.setStyleSheet("font-size:16px; color:black;")
        self.time_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        top_layout.addWidget(self.time_label, 0)
        main_layout.addLayout(top_layout)
        self._start_timer()

        # 主体区（左-中-右）
        body_layout = QHBoxLayout()
        # 左侧树状功能模块
        left_layout = QVBoxLayout()
        module_tree_path = module_config_path or os.path.join(os.path.dirname(__file__), "..", "..", "config", "modules.yaml")
        self.module_tree = ModuleTreeWidget(module_tree_path)
        self.module_tree.setMinimumWidth(220)
        left_layout.addWidget(self.module_tree)
        left_widget = QWidget(); left_widget.setLayout(left_layout)
        left_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(left_widget)

        # 中间详细步骤表格
        self.table = QTableWidget(0, 17)
        self.table.setHorizontalHeaderLabels([
            "步骤名称", "功能名称", "功能参数", "下限", "上限", "单位", "格式", "比较模式", "变量名", "记录名称", "迟时", "超时", "循环次数", "描述", "显示?", "记录?", "错误代码"
        ])
        self.table.setStyleSheet("font-size:14px;")
        body_layout.addWidget(self.table, 1)

        # 右侧脚本操作按钮区（带信号和功能）
        right_btns = QVBoxLayout()
        right_btns.setSpacing(10)
        self.btn_add = QPushButton("Add")
        self.btn_up = QPushButton("Up")
        self.btn_down = QPushButton("Down")
        self.btn_copy = QPushButton("Copy")
        self.btn_paste = QPushButton("Paste")
        self.btn_delete = QPushButton("Delete")
        self.btn_exit = QPushButton("Exit")
        for btn in [self.btn_add, self.btn_up, self.btn_down, self.btn_copy, self.btn_paste, self.btn_delete, self.btn_exit]:
            btn.setFixedWidth(90)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            right_btns.addWidget(btn)
        right_btns.addStretch(1)
        right_widget = QWidget(); right_widget.setLayout(right_btns)
        right_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(right_widget)

        # 连接信号与功能
        self.btn_add.clicked.connect(self.add_step)
        self.btn_delete.clicked.connect(self.delete_step)
        self.btn_up.clicked.connect(self.move_step_up)
        self.btn_down.clicked.connect(self.move_step_down)
        self.btn_copy.clicked.connect(self.copy_step)
        self.btn_paste.clicked.connect(self.paste_step)
        self.btn_exit.clicked.connect(self.close)

        self._copied_row = None  # 用于复制粘贴


        # 正确：将主体区添加到主布局
        main_layout.addLayout(body_layout, 1)

        # 底部脚本路径和状态显示
        bottom_layout = QHBoxLayout()
        self.path_label = QLabel("脚本路径: ")
        self.path_label.setStyleSheet("font-size:14px; color:#333;")
        bottom_layout.addWidget(self.path_label)
        bottom_layout.addStretch(1)
        self.status_label = QLabel("子序列启用状态")
        self.status_label.setStyleSheet(f"font-size:14px; color:white; background:{GREEN}; border-radius:6px; padding:2px 10px;")
        bottom_layout.addWidget(self.status_label)
        main_layout.addLayout(bottom_layout)

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        for c in range(self.table.columnCount()):
            self.table.setItem(row, c, QTableWidgetItem(""))
        self.table.setItem(row, 0, QTableWidgetItem(str(row+1)))
        self.status_label.setText(f"Step {row+1} added.")

    def delete_step(self):
        rows = set(idx.row() for idx in self.table.selectedIndexes())
        for r in sorted(rows, reverse=True):
            self.table.removeRow(r)
        self.status_label.setText(f"Deleted {len(rows)} step(s).")

    def move_step_up(self):
        row = self.table.currentRow()
        if row > 0:
            for c in range(self.table.columnCount()):
                above = self.table.item(row-1, c).text() if self.table.item(row-1, c) else ""
                curr = self.table.item(row, c).text() if self.table.item(row, c) else ""
                self.table.setItem(row-1, c, QTableWidgetItem(curr))
                self.table.setItem(row, c, QTableWidgetItem(above))
            self.table.selectRow(row-1)
            self.status_label.setText("Step moved up.")

    def move_step_down(self):
        row = self.table.currentRow()
        if row < self.table.rowCount()-1 and row >= 0:
            for c in range(self.table.columnCount()):
                below = self.table.item(row+1, c).text() if self.table.item(row+1, c) else ""
                curr = self.table.item(row, c).text() if self.table.item(row, c) else ""
                self.table.setItem(row+1, c, QTableWidgetItem(curr))
                self.table.setItem(row, c, QTableWidgetItem(below))
            self.table.selectRow(row+1)
            self.status_label.setText("Step moved down.")

    def copy_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self._copied_row = [self.table.item(row, c).text() if self.table.item(row, c) else "" for c in range(self.table.columnCount())]
            self.status_label.setText("Step copied.")

    def paste_step(self):
        row = self.table.currentRow()
        if self._copied_row is not None and row >= 0:
            self.table.insertRow(row+1)
            for c, v in enumerate(self._copied_row):
                self.table.setItem(row+1, c, QTableWidgetItem(v))
            self.status_label.setText("Step pasted.")

        # 底部脚本路径和状态显示
        bottom_layout = QHBoxLayout()
        self.path_label = QLabel("脚本路径: ")
        self.path_label.setStyleSheet("font-size:14px; color:#333;")
        bottom_layout.addWidget(self.path_label)
        bottom_layout.addStretch(1)
        self.status_label = QLabel("子序列启用状态")
        self.status_label.setStyleSheet(f"font-size:14px; color:white; background:{GREEN}; border-radius:6px; padding:2px 10px;")
        bottom_layout.addWidget(self.status_label)
        # 此处已移至__init__方法

    def _start_timer(self):
        timer = QTimer(self)
        timer.timeout.connect(self._update_time)
        timer.start(1000)
        self._update_time()

    def _update_time(self):
        now = QDateTime.currentDateTime()
        self.time_label.setText(now.toString("yyyy-MM-dd  HH:mm:ss"))

    # 可根据需要补充表格操作等方法
# 正确的主程序入口应在类定义外部
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = SubSequenceEditorDialog()
    win.show()
    sys.exit(app.exec())