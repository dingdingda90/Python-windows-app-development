import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QLineEdit, QTextEdit, QWidget, QSizePolicy, QFrame
)
from PySide6.QtCore import Qt, QTimer, QDateTime
from core.style import BG, HEADER, SIDEBAR, BTN_SEL, GREEN, RED, GREY, GLOBAL_STYLE


class SequenceEditorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("测试主序列编辑界面")
        self.setStyleSheet(GLOBAL_STYLE)
        self.resize(1000, 700)

        main_layout = QVBoxLayout(self)
        # 顶部Header
        header = QFrame()
        header.setFixedHeight(60)
        header.setStyleSheet(f"background:{HEADER}; border: none;")
        
        # 使用水平布局，左右各加弹性空间实现标题居中
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 0)
        
        # 左侧弹性空间
        header_layout.addStretch()
        
        # 标题（居中）
        self.title_label = QLabel("测试主序列编辑界面")
        self.title_label.setObjectName("ScreenTitle")
        self.title_label.setStyleSheet("font-size:28px; font-weight:bold; color:white; border:none;")
        self.title_label.setAlignment(Qt.AlignCenter)
        header_layout.addWidget(self.title_label)
        
        # 右侧弹性空间
        header_layout.addStretch()
        
        # 时间标签（在右侧）
        self.time_label = QLabel()
        self.time_label.setObjectName("TimeLabel")
        self.time_label.setStyleSheet(f"font-size:16px; color:white;")
        self.time_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        header_layout.addWidget(self.time_label)
        
        main_layout.addWidget(header)
        self._start_timer()

        # 输入区
        input_frame = QFrame()
        input_layout = QGridLayout(input_frame)
        input_frame.setStyleSheet("background:white; border:1px solid #B0BEC5; border-radius:4px;")
        input_frame.setObjectName("MainPanel")
        labels = ["测试名称", "版本号", "描述", "修改者", "产品型号"]
        self.inputs = {}
        for i, label in enumerate(labels):
            l = QLabel(label)
            l.setStyleSheet("font-size:16px; font-weight:bold;")
            l.setObjectName("InputLabel")
            input_layout.addWidget(l, i//3, (i%3)*2)
            if label == "描述":
                w = QTextEdit()
                w.setFixedHeight(40)
            else:
                w = QLineEdit()
            w.setStyleSheet("font-size:14px; padding: 5px;")
            self.inputs[label] = w
            input_layout.addWidget(w, i//3, (i%3)*2+1)
        main_layout.addWidget(input_frame)

        # 主体区（左-中-右）
        body_layout = QHBoxLayout()

        btn_style = (
            "QPushButton {"
            " background:white; color:black; font-size:16px; font-weight:bold;"
            " border:1px solid #CFD8DC; border-radius:4px; min-height:48px;"
            " }"
            "QPushButton:hover { background:#F5F7FA; }"
            "QPushButton:pressed { background:#0D47A1; color:white; }"
        )

        # 左侧脚本操作按钮区
        left_btns = QVBoxLayout()
        left_btns.setSpacing(10)
        # 左侧按钮及事件
        self.left_buttons = {}
        for text in ["Select", "New", "SaveAs", "Delete", "Save", "Exit"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(110)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            left_btns.addWidget(btn)
            self.left_buttons[text] = btn
        # 绑定左侧按钮事件
        self.left_buttons["Exit"].clicked.connect(self.close)
        for k in ["Select", "New", "SaveAs", "Delete", "Save"]:
            self.left_buttons[k].clicked.connect(lambda _, t=k: self._show_not_implemented(t))
        left_btns.addStretch(1)
        left_widget = QWidget(); left_widget.setLayout(left_btns)
        left_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(left_widget)

        # 中间主序列表格
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["测试流程名称", "描述", "是否启用"])
        self.table.setStyleSheet(f"font-size:15px; background:white; alternate-background-color:{BG};")
        body_layout.addWidget(self.table, 1)

        # 连接表格双击信号，弹出子序列编辑窗口
        self.table.cellDoubleClicked.connect(self.open_subsequence_editor)

        # 右侧序列操作按钮区
        right_btns = QVBoxLayout()
        right_btns.setSpacing(10)
        self.right_buttons = {}
        for text in ["Add", "Up", "Down", "Copy", "Paste", "Delete"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(110)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            right_btns.addWidget(btn)
            self.right_buttons[text] = btn
        right_btns.addStretch(1)
        right_widget = QWidget(); right_widget.setLayout(right_btns)
        right_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(right_widget)
        # 绑定右侧按钮事件
        self.right_buttons["Add"].clicked.connect(self.add_step)
        for k in ["Up", "Down", "Copy", "Paste", "Delete"]:
            self.right_buttons[k].clicked.connect(lambda _, t=k: self._show_not_implemented(t))

        main_layout.addLayout(body_layout, 1)

        # 底部脚本路径显示
        self.path_label = QLabel("脚本路径: ")
        self.path_label.setStyleSheet("font-size:14px; color:#333;")
        main_layout.addWidget(self.path_label)

    def open_subsequence_editor(self, row, col):
        # 只在点击“测试流程名称”那一列时弹窗（可根据需要调整）
        if col == 0:
            try:
                from gui.sequence_editor.subsequence_editor_dialog import SubSequenceEditorDialog
            except ImportError:
                from .subsequence_editor_dialog import SubSequenceEditorDialog
            dlg = SubSequenceEditorDialog(self)
            dlg.exec()

    def _start_timer(self):
        timer = QTimer(self)
        timer.timeout.connect(self._update_time)
        timer.start(1000)
        self._update_time()

    def _update_time(self):
        now = QDateTime.currentDateTime()
        self.time_label.setText(now.toString("yyyy-MM-dd  HH:mm:ss"))

    # 可根据需要补充表格操作等方法

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(f"流程{row+1}"))
        self.table.setItem(row, 1, QTableWidgetItem("描述"))
        self.table.setItem(row, 2, QTableWidgetItem("是"))

    def _show_not_implemented(self, btn_name):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "提示", f"[{btn_name}] 功能暂未实现。")

    def del_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self.table.removeRow(row)
# 正确的主程序入口应在类定义外部
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = SequenceEditorDialog()
    win.show()
    sys.exit(app.exec())