import os


def scan_files_by_extension(target_directory, extension):
    """
    扫描指定目录下具有特定扩展名的文件
    
    Args:
        target_directory (str): 目标文件夹路径
        extension (str): 文件扩展名（例如 'json', '.json', 'ini' 等）
    
    Returns:
        tuple: 包含两个列表的元组
               - 第一个列表：文件名（不含后缀）
               - 第二个列表：对应的完整文件路径
    """
    # 确保扩展名以点开头
    if not extension.startswith('.'):
        extension = '.' + extension
    
    # 存储结果
    filenames_without_ext = []
    file_paths = []
    
    # 遍历目标目录
    if os.path.exists(target_directory):
        for filename in os.listdir(target_directory):
            # 检查文件扩展名
            if filename.lower().endswith(extension.lower()):
                # 获取不带扩展名的文件名
                name_without_ext = os.path.splitext(filename)[0]
                # 获取完整路径
                full_path = os.path.join(target_directory, filename)
                
                filenames_without_ext.append(name_without_ext)
                file_paths.append(full_path)
    
    return filenames_without_ext, file_paths


def scan_all_files_in_directory(target_directory):
    """
    扫描指定目录下的所有文件
    
    Args:
        target_directory (str): 目标文件夹路径
    
    Returns:
        tuple: 包含两个列表的元组
               - 第一个列表：文件名（不含后缀）
               - 第二个列表：对应的完整文件路径
    """
    filenames_without_ext = []
    file_paths = []
    
    if os.path.exists(target_directory):
        for filename in os.listdir(target_directory):
            if os.path.isfile(os.path.join(target_directory, filename)):  # 确保是文件而不是子目录
                # 获取不带扩展名的文件名
                name_without_ext = os.path.splitext(filename)[0]
                # 获取完整路径
                full_path = os.path.join(target_directory, filename)
                
                filenames_without_ext.append(name_without_ext)
                file_paths.append(full_path)
    
    return filenames_without_ext, file_paths


if __name__ == "__main__":
    # 示例用法
    target_dir = r"c:\Users\xin.zhang\Desktop\INDUSTRIAL_HMI-main\config\Recipe"
    
    print("JSON文件扫描结果:")
    names, paths = scan_files_by_extension(target_dir, ".json")
    for name, path in zip(names, paths):
        print(f"文件名: {name}")
        print(f"路径: {path}")
        print("---")
    
    print("\nINI文件扫描结果:")
    names, paths = scan_files_by_extension(target_dir, "ini")
    for name, path in zip(names, paths):
        print(f"文件名: {name}")
        print(f"路径: {path}")
        print("---")