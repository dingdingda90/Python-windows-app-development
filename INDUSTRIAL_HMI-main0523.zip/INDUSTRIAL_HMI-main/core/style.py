BG = "#F2F4F7"
HEADER = "#0D47A1"
SIDEBAR = "#E0E0E0"
BTN_SEL = "#0D47A1"
GREEN = "#4CAF50"
RED = "#D32F2F"
GREY = "#BDBDBD"
DISABLED_GREY = (200, 200, 200)
FORCE_PASS_GREEN = (144, 238, 144)
FORCE_FAIL_RED = (255, 182, 193)

GLOBAL_STYLE = """
    * { font-family: 'Arial'; color: black; }
    QLabel#ScreenTitle { font-size: 28px; font-weight: bold; color: white; border: none; }
    QLabel#SectionHeading { font-size: 20px; font-weight: bold; color: #1A237E; }
    QLabel#InputLabel { font-size: 20px; font-weight: bold; color: black; border: none; }
    QFrame#MainPanel { background: white; border: 2px solid #CFD8DC; border-radius: 5px; }
    QPushButton#ControlBox {
        background-color: white; color: black; font-size: 16px; font-weight: bold;
        border: 2px solid #90A4AE; border-radius: 4px; min-height: 60px; 
    }
    QPushButton#ControlBox:hover { background-color: #D1D9DB; }
    QPushButton#ControlBox:pressed { background-color: #4CAF50; border: 2px solid #2E7D32; color: black; }
    QPushButton#MenuBtn {
        background-color: transparent; border: none; color: white; font-size: 24px; font-weight: bold;
    }
    QPushButton#MenuBtn:hover { background-color: #1565C0; border-radius: 4px; }
    QComboBox { background-color: white; color: black; border: 1px solid #90A4AE; padding: 5px; }
    QComboBox QAbstractItemView { background-color: white; color: black; selection-background-color: #0D47A1; selection-color: white; }
    QDateEdit { background-color: white; color: black; border: 1px solid #90A4AE; }
    QCalendarWidget QWidget { background-color: white; color: black; alternate-background-color: #E0E0E0; }
    QCalendarWidget QToolButton { color: black; background-color: white; }
    QCalendarWidget QMenu { background-color: white; color: black; }
    QMessageBox { background-color: white; color: black; }
    QDialog { background-color: white; color: black; }
    QLineEdit { color: black; background-color: white; }
"""