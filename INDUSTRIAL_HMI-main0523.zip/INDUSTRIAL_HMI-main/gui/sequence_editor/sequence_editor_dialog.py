import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QLineEdit, QTextEdit, QWidget, QSizePolicy, QFrame, QHeaderView, QFileDialog, QMessageBox,
    QMenu, QComboBox
)
from PySide6.QtCore import Qt, QTimer, QDateTime
from PySide6.QtGui import QColor
from core.style import BG, HEADER, SIDEBAR, BTN_SEL, GREEN, RED, GREY, GLOBAL_STYLE, DISABLED_GREY
from gui.sequence_editor.edit_sequence_dialog import EditSequenceDialog
from gui.sequence_editor.subsequence_editor_dialog import SubSequenceEditorDialog
from gui.sequence_editor.product_select_dialog import ProductSelectDialog
from gui.sequence_editor.product_select_dialog import ProductSelectDialog
from gui.sequence_editor.product_select_dialog import ProductSelectDialog


class SequenceEditorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("测试主序列编辑界面")
        self.setStyleSheet(GLOBAL_STYLE)
        self.resize(1280, 800)

        main_layout = QVBoxLayout(self)
        # 顶部 Header
        header = QFrame()
        header.setFixedHeight(60)
        header.setStyleSheet(f"background:{HEADER}; border: none;")

        # 最核心：用 QGridLayout 让 标题 和 时间 重叠布局！
        header_layout = QGridLayout(header)
        header_layout.setContentsMargins(10, 2, 10, 2)
        header_layout.setSpacing(0)

        # ======================
        # 标题：真正 100% 正中心（不受时间影响）
        # ======================
        self.title_label = QLabel("测试主序列编辑界面")
        self.title_label.setObjectName("ScreenTitle")
        self.title_label.setStyleSheet("font-size:28px; font-weight:bold; color:white; border:none;")
        self.title_label.setAlignment(Qt.AlignCenter)

        # 放在 0行0列，占满整个网格 → 绝对居中
        header_layout.addWidget(self.title_label, 0, 0, Qt.AlignCenter)

        # ======================
        # 时间：纯右下角，不占位置、不影响居中
        # ======================
        self.time_label = QLabel()
        self.time_label.setObjectName("TimeLabel")
        self.time_label.setStyleSheet("font-size:14px; color:white;")

        # 同样放在 0行0列，但是靠右下对齐 → 叠在标题上面！
        header_layout.addWidget(self.time_label, 0, 0, Qt.AlignRight | Qt.AlignBottom)

        main_layout.addWidget(header)
        self._start_timer()

        #region 脚本信息输入区
        input_frame = QFrame()
        input_layout = QGridLayout(input_frame)
        input_frame.setStyleSheet("background:white; border:1px solid #B0BEC5; border-radius:4px;")
        input_frame.setObjectName("MainPanel")
        
        # 初始化inputs字典
        self.inputs = {}
        
        # 定义字段配置
        fields_config = [
            ("测试名称", 0, 0, 0, 1),
            ("版本号", 0, 2, 0, 3),
            ("修改者", 1, 0, 1, 1),
            ("产品型号", 1, 2, 1, 3)
        ]
        
        # 批量创建普通字段
        for label_text, row_l, col_l, row_w, col_w in fields_config:
            label = QLabel(label_text)
            label.setStyleSheet("font-size:16px; font-weight:bold; border: none;")
            label.setObjectName("InputLabel")
            input_layout.addWidget(label, row_l, col_l)
            
            widget = QLineEdit()
            # 对测试名称特殊处理，设置文本左对齐
            if label_text == "测试名称":
                widget.setStyleSheet("font-size:14px; padding: 5px;background: transparent;text-align: left;")
                widget.setAlignment(Qt.AlignLeft)
            else:
                widget.setStyleSheet("font-size:14px; padding: 5px;background: transparent;")
            widget.setMinimumWidth(200)  # 设置最小宽度
            # 为产品型号输入框添加双击事件以打开选择对话框
            if label_text == "产品型号":
                widget.mouseDoubleClickEvent = lambda event: self._open_product_select_dialog()
                widget.setCursor(Qt.PointingHandCursor)
            self.inputs[label_text] = widget
            input_layout.addWidget(widget, row_w, col_w)
        
        # 特殊处理描述字段，跨越两行
        desc_label = QLabel("描述")
        desc_label.setStyleSheet("font-size:16px; font-weight:bold; border: none;")
        desc_label.setObjectName("InputLabel")
        input_layout.addWidget(desc_label, 0, 4, 2, 1)  # 跨越两行
        
        desc_input = QTextEdit()
        desc_input.setMaximumHeight(80)  # 增加高度以占据两行空间
        desc_input.setMinimumHeight(60)
        desc_input.setFixedWidth(500)
        desc_input.setStyleSheet("font-size:16px; padding: 5px;background: transparent;")
        self.inputs["描述"] = desc_input
        input_layout.addWidget(desc_input, 0, 5, 2, 1)  # 跨越两行
        main_layout.addWidget(input_frame)
        #endregion

        #region 主体区（左-中-右）
        body_layout = QHBoxLayout()

        btn_style = (
            "QPushButton {"
            " background:white; color:black; font-size:16px; font-weight:bold;"
            " border:1px solid #CFD8DC; border-radius:4px; min-height:48px;"
            " }"
            "QPushButton:hover { background:#F5F7FA; }"
            "QPushButton:pressed { background:#0D47A1; color:white; }"
        )

        #region 左侧脚本操作按钮区    
        left_btns = QVBoxLayout()
        left_btns.setSpacing(10)

        self.left_buttons = {}
        for text in ["Select", "New", "SaveAs", "Delete", "Save", "Exit"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(110)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            left_btns.addWidget(btn)
            self.left_buttons[text] = btn
        left_btns.addStretch(1)
        left_widget = QWidget(); left_widget.setLayout(left_btns)
        left_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(left_widget)
        #endregion

        #region 中间主序列表格
        self.table = QTableWidget(0, 4)  # 修改为4列，增加序号列
        self.table.setHorizontalHeaderLabels(["", "测试流程名称", "描述", "是否启用"])
        table_style = (
            "QTableWidget::item { selection-background-color: #0D47A1; selection-color: white; border-right: 0.1px solid #d0d0d0; border-bottom: 0.1px solid #d0d0d0; } " +
            "QTableWidget::item:selected { background-color: #0D47A1; color: white; } " +
            "QTableWidget::item:focus { background-color: #0D47A1; color: white; } " +
            "QTableWidget { gridline-color: #d0d0d0; font-size: 14px; outline: none; border: 2px solid #a0a0a0; border-radius: 6px; } " +
            "QHeaderView::section { font-size: 14px; font-weight: bold; background-color: #f0f0f0; border: 1px solid #d0d0d0; border-top-left-radius: 0px; border-top-right-radius: 0px; padding: 1px; } " +
            "QTableCornerButton::section { background-color: #f0f0f0; border: 1px solid #d0d0d0; border-top-left-radius: 0px; }"
        )
        self.table.setStyleSheet(table_style)

        # 设置列宽
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Fixed)  # 序号列固定宽度
        self.table.setColumnWidth(0, 20)  # 序号列宽度设为20
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)  # 测试流程名称列拉伸
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)  # 描述列拉伸
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Fixed)  # 是否启用列固定宽度
        self.table.setColumnWidth(3, 80)
        # 设置默认行高
        self.table.verticalHeader().setDefaultSectionSize(20)  # 设置每行高度为20像素

        # 禁止水平滚动
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 设置只能单行选中
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        # 设置表格为只读模式，不允许编辑
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        # 禁止选中表头
        self.table.horizontalHeader().setSectionsClickable(False)
        self.table.verticalHeader().setVisible(False)
        # 启用右键菜单
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._show_context_menu)
        body_layout.addWidget(self.table, 1)
        #endregion

        #region 右侧序列操作按钮区
        right_btns = QVBoxLayout()
        right_btns.setSpacing(10)
        self.right_buttons = {}
        for text in ["Add", "Up", "Down", "Copy", "Paste", "Delete"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(110)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            right_btns.addWidget(btn)
            self.right_buttons[text] = btn
        right_btns.addStretch(1)
        right_widget = QWidget(); right_widget.setLayout(right_btns)
        right_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(right_widget)
        main_layout.addLayout(body_layout, 1)
        #endregion

        #region 底部脚本路径显示
        self.path_label = QLabel("脚本路径: ")
        self.path_label.setStyleSheet("font-size:14px; color:#333;")
        main_layout.addWidget(self.path_label)
        #endregion

        #region 事件绑定
        # 绑定左侧按钮事件
        self.left_buttons["Exit"].clicked.connect(self.close)
        self.left_buttons["Select"].clicked.connect(self._select_script)
        self.left_buttons["New"].clicked.connect(self._new_script)
        self.left_buttons["SaveAs"].clicked.connect(self._save_as_script)
        self.left_buttons["Delete"].clicked.connect(self._delete_script)
        self.left_buttons["Save"].clicked.connect(self._save_script)

        # 绑定右侧按钮事件
        self.right_buttons["Add"].clicked.connect(self.add_step)
        self.right_buttons["Up"].clicked.connect(self.move_up_step)
        self.right_buttons["Down"].clicked.connect(self.move_down_step)
        self.right_buttons["Copy"].clicked.connect(self.copy_step)
        self.right_buttons["Paste"].clicked.connect(self.paste_step)
        self.right_buttons["Delete"].clicked.connect(self.del_step)

        # 绑定表格双击事件，弹出子序列编辑窗口
        self.table.cellDoubleClicked.connect(self.open_subsequence_editor)
        #endregion

        # 初始化剪贴板
        self.copied_row = None

    def open_subsequence_editor(self, row, col):
        # 只在点击“测试流程名称”那一列时弹窗（第1列）
        if col != 1:  # 只响应第1列（测试流程名称）的双击
            return
        
        # 构造完整的子序列数据结构
        name_item = self.table.item(row, 1)  # 子序列名称（第1列）
        content_item = self.table.item(row, 2)  # 子序列内容（第2列）
        enable_item = self.table.item(row, 3)  # 启用状态（第3列）
        
        # 提取数据
        subseq_name = name_item.text() if name_item else f"子序列{row+1}"
        subseq_content = content_item.text() if content_item else ""
        enable_status = enable_item.text() if enable_item else "TRUE"
        
        # 获取当前主序列的路径信息
        current_path = self.path_label.text().replace("脚本路径: ", "") if self.path_label.text() != "脚本路径: " else None
        
        # 构造完整的子序列数据，尝试从原始JSON文件中加载步骤数据
        subsequence_data = {
            "SubSequenceName": subseq_name,
            "SubSequenceContent": subseq_content,
            "Enable": enable_status,
            "Steps": []
        }
        
        # 如果有原始路径，尝试从文件中加载完整数据
        if current_path and os.path.exists(current_path):
            try:
                import json
                with open(current_path, 'r', encoding='utf-8') as f:
                    full_data = json.load(f)
                
                # 从主序列中查找对应的子序列数据
                main_sequence = full_data.get("Sequence", {}).get("MainSequence", [])
                for seq_item in main_sequence:
                    if seq_item.get("SubSequenceName") == subseq_name:
                        # 找到匹配的子序列，提取其步骤数据
                        subsequence_data["Steps"] = seq_item.get("Steps", [])
                        subsequence_data["SubSequenceContent"] = seq_item.get("SubSequenceContent", subseq_content)
                        break
            except Exception as e:
                print(f"加载子序列步骤数据失败: {e}")
        
        # 创建子序列编辑器并传递完整数据
        dlg = SubSequenceEditorDialog(self, subsequence_data=subsequence_data, recipe_file_path=current_path)
        dlg.setWindowTitle(f"编辑子序列 - {subseq_name}")
        
        # 显示对话框
        if dlg.exec() == QDialog.Accepted:
            # 获取更新后的数据
            updated_data = dlg.get_updated_data()
            
            # 更新主序列表格中的数据
            if updated_data:
                # 更新所有可能被修改的字段
                name_item = QTableWidgetItem(updated_data["SubSequenceName"])
                content_item = QTableWidgetItem(updated_data["SubSequenceContent"])
                enable_item = QTableWidgetItem(updated_data["Enable"])
                
                # 根据Enable状态设置整行颜色
                enable_value = updated_data.get("Enable", "TRUE")
                enable_status = str(enable_value).strip().upper()
                if enable_status in ["FALSE", "DISABLE", "DISABLED", "0", "NO"]:
                    grey_color = QColor(*DISABLED_GREY)  # 灰色
                    name_item.setBackground(grey_color)
                    content_item.setBackground(grey_color)
                    enable_item.setBackground(grey_color)
                
                self.table.setItem(row, 1, name_item)
                self.table.setItem(row, 2, content_item)
                self.table.setItem(row, 3, enable_item)
                
                # 强制刷新行显示以确保颜色生效
                self.table.viewport().update()

    def _start_timer(self):
        timer = QTimer(self)
        timer.timeout.connect(self._update_time)
        timer.start(1000)
        self._update_time()

    def _update_time(self):
        now = QDateTime.currentDateTime()
        self.time_label.setText(now.toString("yyyy-MM-dd  HH:mm:ss"))

    # 可根据需要补充表格操作等方法

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        # 创建表格项并设置为非编辑状态
        index_item = QTableWidgetItem(str(row + 1))  # 序号从1开始
        name_item = QTableWidgetItem(f"流程{row+1}")
        desc_item = QTableWidgetItem("")
        enable_item = QTableWidgetItem("TRUE")
        
        # 设置项目标志，使其不可编辑
        index_item.setFlags(index_item.flags() & ~Qt.ItemIsEditable)
        name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
        desc_item.setFlags(desc_item.flags() & ~Qt.ItemIsEditable)
        enable_item.setFlags(enable_item.flags() & ~Qt.ItemIsEditable)
        
        self.table.setItem(row, 0, index_item)  # 序号列
        self.table.setItem(row, 1, name_item)   # 测试流程名称列
        self.table.setItem(row, 2, desc_item)   # 描述列
        self.table.setItem(row, 3, enable_item) # 是否启用列

    def _open_product_select_dialog(self):
        # 打开产品型号选择对话框
        dialog = ProductSelectDialog(self)
        if dialog.exec() == QDialog.Accepted:
            selected_data = dialog.get_selected_data()
            product_model = selected_data["product_model"]
            script_path = selected_data["script_path"]
            
            # 更新产品型号输入框
            self.inputs["产品型号"].setText(product_model)
            
            # 更新脚本路径显示
            self.path_label.setText(f"脚本路径: {script_path}")
            
    def _open_product_select_dialog(self):
        # 打开产品型号选择对话框
        dialog = ProductSelectDialog(self)
        if dialog.exec() == QDialog.Accepted:
            selected_data = dialog.get_selected_data()
            product_model = selected_data["product_model"]
            script_path = selected_data["script_path"]
            
            # 更新产品型号输入框
            self.inputs["产品型号"].setText(product_model)
            
            # 更新脚本路径显示
            self.path_label.setText(f"脚本路径: {script_path}")
            
    def _handle_product_double_click(self, event):
        # 处理产品型号输入框的双击事件
        self._open_product_select_dialog()
        
    def _open_product_select_dialog(self):
        # 打开产品型号选择对话框
        from gui.sequence_editor.product_select_dialog import ProductSelectDialog
        dialog = ProductSelectDialog(self)
        if dialog.exec() == QDialog.Accepted:
            selected_data = dialog.get_selected_data()
            product_model = selected_data["product_model"]
            script_path = selected_data["script_path"]
            
            # 更新产品型号输入框
            self.inputs["产品型号"].setText(product_model)
            
            # 更新脚本路径显示
            self.path_label.setText(f"脚本路径: {script_path}")
            
    def _show_not_implemented(self, btn_name):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "提示", f"[{btn_name}] 功能暂未实现。")

    #region 左侧按钮功能
    def _select_script(self):
        # 打开产品型号选择对话框
        dialog = ProductSelectDialog(self)
        if dialog.exec() == QDialog.Accepted:
            selected_data = dialog.get_selected_data()
            product_model = selected_data["product_model"]
            script_path = selected_data["script_path"]
            
            # 更新产品型号输入框
            self.inputs["产品型号"].setText(product_model)
            
            # 更新脚本路径显示
            self.path_label.setText(f"脚本路径: {script_path}")
            
            # 加载JSON文件中的完整信息
            if script_path and script_path.endswith('.json'):
                try:
                    import json
                    with open(script_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        
                    # 加载通用信息
                    general_info = data.get("GeneralInfo", {})
                    self.inputs["测试名称"].setText(general_info.get("TestName", ""))
                    self.inputs["版本号"].setText(general_info.get("Version", ""))
                    self.inputs["描述"].setPlainText(general_info.get("TestContent", ""))
                    self.inputs["修改者"].setText(general_info.get("Author", ""))
                    
                    # 加载序列信息
                    sequence_data = data.get("Sequence", {})
                    main_sequence = sequence_data.get("MainSequence", [])
                    
                    # 清空现有表格
                    self.table.setRowCount(0)
                    
                    # 添加序列项到表格
                    for item in main_sequence:
                        row = self.table.rowCount()
                        self.table.insertRow(row)
                        # 添加序号
                        self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
                        
                        # 创建并设置表格项
                        name_item = QTableWidgetItem(item.get("SubSequenceName", ""))
                        content_item = QTableWidgetItem(item.get("SubSequenceContent", ""))
                        enable_item = QTableWidgetItem(item.get("Enable", ""))
                        
                        # 根据Enable状态设置整行颜色
                        enable_value = item.get("Enable", "TRUE")
                        enable_status = str(enable_value).strip().upper()
                        if enable_status in ["FALSE", "DISABLE", "DISABLED", "0", "NO"]:
                            grey_color = QColor(*DISABLED_GREY)  # 灰色
                            name_item.setBackground(grey_color)
                            content_item.setBackground(grey_color)
                            enable_item.setBackground(grey_color)
                        
                        self.table.setItem(row, 1, name_item)
                        self.table.setItem(row, 2, content_item)
                        self.table.setItem(row, 3, enable_item)
                        
                        # 强制刷新行显示以确保颜色生效
                        self.table.viewport().update()
                    
                    from PySide6.QtWidgets import QMessageBox
                    QMessageBox.information(self, "提示", "产品信息加载成功！")
                except Exception as e:
                    from PySide6.QtWidgets import QMessageBox
                    QMessageBox.critical(self, "错误", f"加载产品信息失败: {str(e)}")
            else:
                from PySide6.QtWidgets import QMessageBox
                QMessageBox.warning(self, "警告", "所选文件不是有效的JSON格式")

    def _new_script(self):
        from PySide6.QtWidgets import QMessageBox
        # 清空所有内容
        self.table.setRowCount(0)
        for input_name in self.inputs:
            if isinstance(self.inputs[input_name], QLineEdit):
                self.inputs[input_name].clear()
            else:
                self.inputs[input_name].clear()
        self.path_label.setText("脚本路径: ")
        QMessageBox.information(self, "提示", "已创建新脚本！")

    def _save_as_script(self):
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        import json
        import os
        # 设置默认路径为Config/recipe文件夹
        config_recipe_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "config", "Recipe")
        if not os.path.exists(config_recipe_path):
            config_recipe_path = ""  # 如果路径不存在，使用当前目录
        
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存脚本文件", config_recipe_path, "JSON Files (*.json)", options=QFileDialog.DontUseNativeDialog | QFileDialog.DontConfirmOverwrite
        )
        if file_path:
            if not file_path.endswith(".json"):
                file_path += ".json"
            
            # 构建JSON数据结构
            data = {
                "GeneralInfo": {
                    "TestName": self.inputs["测试名称"].text(),
                    "Author": self.inputs["修改者"].text(),
                    "Version": self.inputs["版本号"].text(),
                    "TestContent": self.inputs["描述"].toPlainText(),
                    "ID": self.inputs["产品型号"].text()
                },
                "Sequence": {
                    "MainSequenceCount": self.table.rowCount(),
                    "MainSequence": []
                }
            }
            
            # 添加表格中的序列数据
            for row in range(self.table.rowCount()):
                sub_seq_item = {
                    "SubSequenceName": self.table.item(row, 1).text() if self.table.item(row, 1) else "",
                    "SubSequenceContent": self.table.item(row, 2).text() if self.table.item(row, 2) else "",
                    "Enable": self.table.item(row, 3).text() if self.table.item(row, 3) else "FALSE"
                }
                data["Sequence"]["MainSequence"].append(sub_seq_item)
            
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                self.path_label.setText(f"脚本路径: {file_path}")
                QMessageBox.information(self, "提示", "脚本另存成功！")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"保存脚本失败: {str(e)}")

    def _delete_script(self):
        from PySide6.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, "确认删除", "确定要删除当前脚本吗？",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self._new_script()

    def _save_script(self):
        from PySide6.QtWidgets import QMessageBox
        import json
        path = self.path_label.text().replace("脚本路径: ", "")
        if not path:
            self._save_as_script()
        else:
            # 构建JSON数据结构
            data = {
                "GeneralInfo": {
                    "TestName": self.inputs["测试名称"].text(),
                    "Author": self.inputs["修改者"].text(),
                    "Version": self.inputs["版本号"].text(),
                    "TestContent": self.inputs["描述"].toPlainText(),
                    "ID": self.inputs["产品型号"].text()
                },
                "Sequence": {
                    "MainSequenceCount": self.table.rowCount(),
                    "MainSequence": []
                }
            }
            
            # 添加表格中的序列数据
            for row in range(self.table.rowCount()):
                sub_seq_item = {
                    "SubSequenceName": self.table.item(row, 1).text() if self.table.item(row, 1) else "",
                    "SubSequenceContent": self.table.item(row, 2).text() if self.table.item(row, 2) else "",
                    "Enable": self.table.item(row, 3).text() if self.table.item(row, 3) else "FALSE"
                }
                data["Sequence"]["MainSequence"].append(sub_seq_item)
            
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                QMessageBox.information(self, "提示", "脚本保存成功！")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"保存脚本失败: {str(e)}")
    #endregion

    #region 右侧按钮功能
    def del_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self.table.removeRow(row)
            # 更新序号
            self._update_row_numbers()

    def move_up_step(self):
        row = self.table.currentRow()
        if row > 0:
            # 获取当前行数据
            name = self.table.item(row, 1).text()
            desc = self.table.item(row, 2).text()
            enabled = self.table.item(row, 3).text()
            # 删除当前行
            self.table.removeRow(row)
            # 在上方插入
            self.table.insertRow(row - 1)
            self.table.setItem(row - 1, 1, QTableWidgetItem(name))
            self.table.setItem(row - 1, 2, QTableWidgetItem(desc))
            self.table.setItem(row - 1, 3, QTableWidgetItem(enabled))
            # 选中新位置
            self.table.selectRow(row - 1)
            # 更新序号
            self._update_row_numbers()

    def move_down_step(self):
        row = self.table.currentRow()
        if row >= 0 and row < self.table.rowCount() - 1:
            # 获取当前行数据
            name = self.table.item(row, 1).text()
            desc = self.table.item(row, 2).text()
            enabled = self.table.item(row, 3).text()
            # 删除当前行
            self.table.removeRow(row)
            # 在下方插入
            self.table.insertRow(row + 1)
            self.table.setItem(row + 1, 1, QTableWidgetItem(name))
            self.table.setItem(row + 1, 2, QTableWidgetItem(desc))
            self.table.setItem(row + 1, 3, QTableWidgetItem(enabled))
            # 选中新位置
            self.table.selectRow(row + 1)
            # 更新序号
            self._update_row_numbers()

    def _update_row_numbers(self):
        # 更新表格中的序号列
        for row in range(self.table.rowCount()):
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))

    def copy_step(self):
        row = self.table.currentRow()
        if row >= 0:
            # 保存复制的行数据（跳过序号列）
            self.copied_row = {
                "name": self.table.item(row, 1).text(),
                "desc": self.table.item(row, 2).text(),
                "enabled": self.table.item(row, 3).text()
            }
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.information(self, "提示", "已复制当前行！")

    def paste_step(self):
        if self.copied_row:
            row = self.table.currentRow()
            if row < 0:
                row = self.table.rowCount()
            else:
                row += 1
            # 插入新行
            self.table.insertRow(row)
            # 添加序号
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(self.copied_row["name"]))
            self.table.setItem(row, 2, QTableWidgetItem(self.copied_row["desc"]))
            self.table.setItem(row, 3, QTableWidgetItem(self.copied_row["enabled"]))
            # 选中新插入的行
            self.table.selectRow(row)
            # 更新序号
            self._update_row_numbers()
        else:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "提示", "请先复制一行数据！")
    #endregion

    def _show_context_menu(self, position):
        """显示右键菜单"""
        row = self.table.rowAt(position.y())
        if row == -1:  # 如果没有点击在行上，则不显示菜单
            return
        
        menu = QMenu(self)
        
        # 编辑选项
        edit_action = menu.addAction("编辑")
        edit_action.triggered.connect(lambda: self._edit_row(row))
        
        # 分隔线
        menu.addSeparator()
        
        # 删除选项
        delete_action = menu.addAction("删除")
        delete_action.triggered.connect(lambda: self._delete_row(row))
        
        # 显示菜单
        menu.exec(self.table.viewport().mapToGlobal(position))

    def _edit_row(self, row):
        """编辑指定行"""
        # 获取当前值
        current_name = self.table.item(row, 1).text() if self.table.item(row, 1) else ""
        current_desc = self.table.item(row, 2).text() if self.table.item(row, 2) else ""
        current_enable = (self.table.item(row, 3).text() == "TRUE") if self.table.item(row, 3) else False
        
        # 创建编辑对话框
        dialog = EditSequenceDialog(current_name, current_desc, current_enable, self)
        
        # 显示对话框并更新数据
        if dialog.exec():
            name, desc, enabled = dialog.get_values()
            self.table.setItem(row, 1, QTableWidgetItem(name))
            self.table.setItem(row, 2, QTableWidgetItem(desc))
            self.table.setItem(row, 3, QTableWidgetItem("TRUE" if enabled else "FALSE"))
    def _delete_row(self, row):
        """删除指定行"""
        from PySide6.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, "确认删除", f"确定要删除 '{self.table.item(row, 1).text()}' 吗？",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.table.removeRow(row)
# 正确的主程序入口应在类定义外部
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = SequenceEditorDialog()
    win.show()
    sys.exit(app.exec())