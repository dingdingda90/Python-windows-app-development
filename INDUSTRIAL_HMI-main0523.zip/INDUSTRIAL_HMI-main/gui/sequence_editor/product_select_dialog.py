import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QTextEdit, QPushButton,
    QFrame, QSizePolicy
)
from PySide6.QtCore import Qt
from core.style import BG, HEADER, SIDEBAR, BTN_SEL, GREEN, RED, GREY, GLOBAL_STYLE
from utils.file_scanner import scan_files_by_extension


class ProductSelectDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("请选择产品型号")
        self.setStyleSheet(GLOBAL_STYLE)
        self.resize(700, 300)
        
        # 存储选中的产品型号和脚本路径
        self.selected_product = ""
        self.selected_script_path = ""
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)
        
        # 统一的产品型号和路径区域
        info_group = QFrame()
        info_group.setStyleSheet("background:#f0f0f0; border-radius:6px; padding:10px;")
        info_layout = QVBoxLayout(info_group)
        
        # 产品型号标签
        product_label = QLabel("产品型号")
        product_label.setStyleSheet("font-size:16px; font-weight:bold; color:#333;")
        info_layout.addWidget(product_label)
        
        # 产品型号下拉框
        self.product_combo = QComboBox()
        self.product_combo.setStyleSheet(
            "font-size:18px; font-weight:bold; color:black; "
            "background:white; border:1px solid #CFD8DC; border-radius:4px; padding:5px;"
        )
        self.product_combo.setMinimumHeight(40)
        self.product_combo.currentTextChanged.connect(self._on_product_changed)
        info_layout.addWidget(self.product_combo)
        
        # 测试脚本路径标签
        path_label = QLabel("测试脚本路径")
        path_label.setStyleSheet("font-size:16px; font-weight:bold; color:#333; margin-top:10px;")
        info_layout.addWidget(path_label)
        
        # 测试脚本路径显示区域
        self.path_text = QTextEdit()
        self.path_text.setStyleSheet(
            "font-size:14px; font-weight:bold; color:black; "
            "background:white; border:1px solid #CFD8DC; border-radius:4px;"
        )
        self.path_text.setMinimumHeight(60)
        self.path_text.setMaximumHeight(80)
        self.path_text.setReadOnly(True)
        info_layout.addWidget(self.path_text)
        
        main_layout.addWidget(info_group)
        
        # 按钮区域
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        
        # OK按钮
        self.ok_btn = QPushButton("OK")
        self.ok_btn.setStyleSheet(
            "QPushButton {"
            " background:#d0d0d0; color:black; font-size:16px; font-weight:bold;"
            " border:1px solid #CFD8DC; border-radius:4px; min-width:120px; min-height:40px;"
            " }"
            "QPushButton:hover { background:#e0e0e0; }"
            "QPushButton:pressed { background:#0D47A1; color:white; }"
        )
        self.ok_btn.clicked.connect(self.accept)
        button_layout.addWidget(self.ok_btn)
        
        button_layout.addStretch(2)
        
        # CANCEL按钮
        self.cancel_btn = QPushButton("CANCEL")
        self.cancel_btn.setStyleSheet(
            "QPushButton {"
            " background:#d0d0d0; color:black; font-size:16px; font-weight:bold;"
            " border:1px solid #CFD8DC; border-radius:4px; min-width:120px; min-height:40px;"
            " }"
            "QPushButton:hover { background:#e0e0e0; }"
            "QPushButton:pressed { background:#0D47A1; color:white; }"
        )
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)
        
        button_layout.addStretch(1)
        
        main_layout.addLayout(button_layout)
        
        # 加载产品型号列表
        self._load_product_models()
        
    def _load_product_models(self):
        """加载产品型号列表"""
        # 从config/Recipe目录读取产品型号
        config_recipe_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 
            "config", "Recipe"
        )
        
        if os.path.exists(config_recipe_path):
            # 使用通用工具扫描JSON文件，直接使用文件名
            product_models, _ = scan_files_by_extension(config_recipe_path, ".json")
            
            # 添加到下拉框
            self.product_combo.addItems(product_models)
            
            # 默认选择第一个
            if product_models:
                self.product_combo.setCurrentIndex(0)
        else:
            # 如果目录不存在，添加示例数据
            sample_products = ["产品型号A", "产品型号B", "产品型号C", "产品型号D"]
            self.product_combo.addItems(sample_products)
            if sample_products:
                self.product_combo.setCurrentIndex(0)
                
    def _on_product_changed(self, product_name):
        """当产品型号改变时更新脚本路径显示"""
        self.selected_product = product_name
        
        # 构建脚本路径
        config_recipe_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 
            "config", "Recipe"
        )
        
        if os.path.exists(config_recipe_path):
            # 显示完整路径（只显示一次）
            json_path = os.path.join(config_recipe_path, f"{product_name}.json")
            full_path = os.path.abspath(json_path)
            
            # 只显示绝对路径
            self.path_text.setPlainText(full_path)
            self.selected_script_path = full_path
        else:
            self.path_text.setPlainText("")
            self.selected_script_path = ""
            
    def get_selected_data(self):
        """获取选中的数据"""
        return {
            "product_model": self.selected_product,
            "script_path": self.selected_script_path
        }


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    dlg = ProductSelectDialog()
    if dlg.exec() == QDialog.Accepted:
        print(dlg.get_selected_data())