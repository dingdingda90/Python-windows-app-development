
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QWidget, QTreeWidget, QTreeWidgetItem, QTextEdit, QSizePolicy, QFrame,
    QFileDialog, QMessageBox, QLineEdit, QHeaderView
)
from PySide6.QtGui import QColor
from PySide6.QtCore import Qt, QTimer, QDateTime, QEvent
from core.style import BG, HEADER, SIDEBAR, BTN_SEL, GREEN, RED, GREY, GLOBAL_STYLE, DISABLED_GREY, FORCE_PASS_GREEN, FORCE_FAIL_RED
import json
import os
from gui.sequence_editor.module_tree import ModuleTreeWidget

from PySide6.QtCore import Signal

class StatusLabel(QLabel):
    clicked = Signal()  # 定义点击信号
    
    def __init__(self, text=""):
        super().__init__(text)
        self.setCursor(Qt.PointingHandCursor)  # 设置手型光标
        
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()  # 发射点击信号
        super().mousePressEvent(event)
        
    def update_status_color(self, enabled):
        """根据状态更新标签颜色"""
        from core.style import GREEN, RED  # 导入颜色常量
        if enabled:
            # 启用状态 - 绿色
            self.setStyleSheet(f"font-size:14px; color:white; background:{GREEN}; border-radius:8px; padding:5px 20px;")
            self.setText("子序列启用状态")
        else:
            # 禁用状态 - 红色
            self.setStyleSheet(f"font-size:14px; color:white; background:{RED}; border-radius:8px; padding:5px 20px;")
            self.setText("子序列禁用状态")


class DoubleClickButton(QPushButton):
    doubleClicked = Signal()  # 自定义双击信号
    
    def __init__(self, text=""):
        super().__init__(text)
        self.setMouseTracking(True)  # 启用鼠标跟踪
        
    def event(self, event):
        if event.type() == QEvent.MouseButtonDblClick:
            self.doubleClicked.emit()  # 发射双击信号
            return True
        return super().event(event)

class SubSequenceEditorDialog(QDialog):
    def __init__(self, parent=None, module_config_path=None, subsequence_data=None, recipe_file_path=None):
        super().__init__(parent)
        self.setWindowTitle("测试子序列编辑界面")
        self.setStyleSheet(GLOBAL_STYLE)
        self.resize(1400, 900)
        
        # 存储完整的子序列数据
        if subsequence_data is None:
            subsequence_data = {
                "SubSequenceName": "",
                "SubSequenceContent": "",
                "Enable": "TRUE",
                "Steps": []
            }
        
        self.subsequence_data = subsequence_data
        
        # 提取启用状态
        enable_value = subsequence_data.get("Enable", "TRUE")
        self.is_enabled = str(enable_value).upper() in ["TRUE", "YES", "ENABLED", "1"]
        
        # 提取步骤数据
        self.steps_data = subsequence_data.get("Steps", [])
        
        # 提取子序列名称
        self.subsequence_name = subsequence_data.get("SubSequenceName", "")
        
        # 提取子序列内容
        self.subsequence_content = subsequence_data.get("SubSequenceContent", "")
        
        # 保留模块配置路径
        self.module_config_path = module_config_path
        
        # 保存配方文件路径
        self.recipe_file_path = recipe_file_path
        
        main_layout = QVBoxLayout(self)
        # 顶部 Header
        header = QFrame()
        header.setFixedHeight(60)
        header.setStyleSheet(f"background:{HEADER}; border: none;")

        # 最核心：用 QGridLayout 让 标题 和 时间 重叠布局！
        header_layout = QGridLayout(header)
        header_layout.setContentsMargins(10, 2, 10, 2)
        header_layout.setSpacing(0)

        # ======================
        # 标题：真正 100% 正中心（不受时间影响）
        # ======================
        self.title_label = QLabel("测试子序列编辑界面")
        self.title_label.setObjectName("ScreenTitle")
        self.title_label.setStyleSheet("font-size:28px; font-weight:bold; color:white; border:none;")
        self.title_label.setAlignment(Qt.AlignCenter)

        # 放在 0行0列，占满整个网格 → 绝对居中
        header_layout.addWidget(self.title_label, 0, 0, Qt.AlignCenter)

        # ======================
        # 时间：纯右下角，不占位置、不影响居中
        # ======================\        
        self.time_label = QLabel()
        self.time_label.setObjectName("TimeLabel")
        self.time_label.setStyleSheet("font-size:14px; color:white;")

        # 同样放在 0行0列，但是靠右下对齐 → 叠在标题上面！
        header_layout.addWidget(self.time_label, 0, 0, Qt.AlignRight | Qt.AlignBottom)

        main_layout.addWidget(header)
        self._start_timer()

        # 主体区（左-中-右）
        body_layout = QHBoxLayout()
        # 左侧树状功能模块
        left_layout = QVBoxLayout()
        module_tree_path = module_config_path or os.path.join(os.path.dirname(__file__), "..", "..", "config", "modules.yaml")
        self.module_tree = ModuleTreeWidget(module_tree_path)
        self.module_tree.setMinimumWidth(120)
        self.module_tree.setMaximumWidth(150)
        # Connect the module selection signal
        self.module_tree.module_selected.connect(self._on_module_selected)
        left_layout.addWidget(self.module_tree)
        left_widget = QWidget(); left_widget.setLayout(left_layout)
        left_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(left_widget)

        # 中间详细步骤表格
        self.table = QTableWidget(0, 21)  # 20个字段 + 1个序号列
        self.table.setHorizontalHeaderLabels([
            "序号", "步骤名称", "执行函数", "功能参数", "下限", "上限", "单位", "格式", "比较模式", "变量名", "记录名称", "延时", "超时", "循环次数", "描述", "偏移", "备注", "步骤类型", "显示?", "记录?", "错误代码"
        ])
        table_style = (
            "QTableWidget::item { selection-background-color: #0D47A1; selection-color: black; border-right: 0.1px solid #d0d0d0; border-bottom: 0.1px solid #d0d0d0; } " +
            "QTableWidget::item:selected { background-color: #0D47A1; color: black; } " +
            "QTableWidget::item:focus { background-color: #0D47A1; color: black; } " +
            "QTableWidget { gridline-color: #d0d0d0; font-size: 14px; outline: none; border: 2px solid #a0a0a0; border-radius: 6px; } " +
            "QHeaderView::section { font-size: 14px; font-weight: bold; background-color: #f0f0f0; border: 1px solid #d0d0d0; border-top-left-radius: 0px; border-top-right-radius: 0px; padding: 1px; } " +
            "QTableCornerButton::section { background-color: #f0f0f0; border: 1px solid #d0d0d0; border-top-left-radius: 0px; }"
        )
        self.table.setStyleSheet(table_style)
        
        # 设置默认行高
        self.table.verticalHeader().setDefaultSectionSize(25)  # 设置每行高度为25像素
        
        # 允许水平滚动以查看完整数据
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        # 设置只能单行选中
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        # 设置表格为只读模式，不允许编辑
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        # 禁止选中表头
        self.table.horizontalHeader().setSectionsClickable(False)
        self.table.verticalHeader().setVisible(False)
        # 设置表格尺寸
        self.table.setMinimumHeight(600)
        self.table.setMinimumWidth(1000)  # 增加最小宽度以容纳更多内容
        
        # 设置列宽策略，使用户可以查看完整数据
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)  # 允许用户拖拽调整列宽
        
        body_layout.addWidget(self.table, 1)

        #region 右侧序列操作按钮区
        right_btns = QVBoxLayout()
        right_btns.setSpacing(2)
        
        btn_style = (
            "QPushButton {"
            " background:white; color:black; font-size:16px; font-weight:bold;"
            " border:1px solid #CFD8DC; border-radius:4px; min-height:30px;"
            " }"
            "QPushButton:hover { background:#F5F7FA; }"
            "QPushButton:pressed { background:#0D47A1; color:white; }"
        )
        
        self.right_buttons = {}
        for text in ["Add", "Up", "Down", "Copy", "Paste", "Delete", "Save", "Load", "Exit"]:
            btn = QPushButton(text)
            btn.setMinimumWidth(110)
            btn.setMaximumWidth(150)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setObjectName("ControlBox")
            btn.setStyleSheet(btn_style)
            right_btns.addWidget(btn)
            # 将按钮存储到字典中
            if text == "Add":
                self.btn_add = btn
            elif text == "Up":
                self.btn_up = btn
            elif text == "Down":
                self.btn_down = btn
            elif text == "Copy":
                self.btn_copy = btn
            elif text == "Paste":
                self.btn_paste = btn
            elif text == "Delete":
                self.btn_delete = btn
            elif text == "Save":
                self.btn_save = btn
            elif text == "Load":
                self.btn_load = btn
            elif text == "Exit":
                self.btn_exit = btn
            self.right_buttons[text] = btn
        
        # 连接信号与功能
        self.btn_add.clicked.connect(self.add_step)
        self.btn_delete.clicked.connect(self.delete_step)
        self.btn_up.clicked.connect(self.move_step_up)
        self.btn_down.clicked.connect(self.move_step_down)
        self.btn_copy.clicked.connect(self.copy_step)
        self.btn_paste.clicked.connect(self.paste_step)
        self.btn_save.clicked.connect(self.save_recipe)
        self.btn_load.clicked.connect(self.load_recipe)
        self.btn_exit.clicked.connect(self.close)

        # 在Exit按钮后添加测试名称和描述文本框
        # 测试名称文本框
        # 测试描述文本框
        test_name_label = QLabel("测试名称:")
        test_name_label.setStyleSheet("font-size:14px; font-weight:bold; color:black;")
        self.test_name_edit = QTextEdit(self.subsequence_name)
        self.test_name_edit.setStyleSheet(
            "font-size:16px; font-weight:bold; color:black; "
            "background:white; border:1px solid #CFD8DC; border-radius:4px; min-height:30px;"
        )
        self.test_name_edit.setMinimumHeight(200)
        self.test_name_edit.setMaximumHeight(400)
        self.test_name_edit.setMinimumWidth(110)
        self.test_name_edit.setMaximumWidth(150)
        right_btns.addWidget(test_name_label)
        right_btns.addWidget(self.test_name_edit)
        
        # 测试描述文本框
        test_desc_label = QLabel("测试描述:")
        test_desc_label.setStyleSheet("font-size:14px; font-weight:bold; color:black;")
        self.test_desc_edit = QTextEdit(self.subsequence_content)
        self.test_desc_edit.setStyleSheet(
            "font-size:16px; font-weight:bold; color:black; "
            "background:white; border:1px solid #CFD8DC; border-radius:4px; min-height:30px;"
        )
        self.test_desc_edit.setMinimumHeight(200)
        self.test_desc_edit.setMaximumHeight(400)
        self.test_desc_edit.setMinimumWidth(110)
        self.test_desc_edit.setMaximumWidth(150)
        right_btns.addWidget(test_desc_label)
        right_btns.addWidget(self.test_desc_edit)
        
        #right_btns.addStretch(1)
        right_widget = QWidget(); right_widget.setLayout(right_btns)
        right_widget.setMinimumWidth(150)  # 设置与左侧树形控件相同的最小宽度
        right_widget.setStyleSheet(f"background:{SIDEBAR}; border-radius:6px;")
        body_layout.addWidget(right_widget)
        #endregion

        self._copied_row = None  # 用于复制粘贴

        # 正确：将主体区添加到主布局
        main_layout.addLayout(body_layout, 1)

        # 底部脚本路径和状态显示
        bottom_layout = QHBoxLayout()
        self.path_label = QLabel("脚本路径: ")
        self.path_label.setStyleSheet("font-size:14px; color:#333;")
        bottom_layout.addWidget(self.path_label)
        bottom_layout.addStretch(1)
        self.status_label = StatusLabel("子序列启用状态")  # 使用自定义StatusLabel代替QLabel
        # 初始设置为对应的状态
        self.status_label.update_status_color(self.is_enabled)  # 使用传入的启用状态
        # 连接点击信号
        self.status_label.clicked.connect(self.toggle_subsequence_status)
        bottom_layout.addWidget(self.status_label)
        main_layout.addLayout(bottom_layout)
        
        # 使用传入的步骤数据填充表格
        self.populate_table_with_steps()
        
        # 如果提供了配方文件路径，则显示它
        if self.recipe_file_path:
            self.path_label.setText(f"脚本路径: {self.recipe_file_path}")
        
    def populate_table_with_steps(self):
        """使用传入的步骤数据填充表格"""
        # 清空现有数据
        self.table.setRowCount(0)
        
        # 定义中文表头与JSON字段的映射关系
        header_mapping = {
            "序号": "Index",  # 特殊处理，用于显示行号
            "执行函数": "Execute",
            "功能参数": "Paramters",  # 注意：JSON中是Paramters（参数的缩写）
            "下限": "Mini",  # 或者 "Min"
            "上限": "Max",
            "单位": "Unit",
            "格式": "Format",
            "比较模式": "ComparisonType",
            "变量名": "Variable",
            "记录名称": "RecordName",
            "延时": "LatencyTime",
            "超时": "Timeout",
            "循环次数": "Looping",
            "描述": "Content",
            "偏移": "Offset",
            "备注": "Remark",
            "步骤类型": "StepType",
            "显示?": "Display",
            "记录?": "Record",
            "错误代码": "ErrorCode",
            "步骤名称": "Function"  # 使用Function字段作为步骤名称
        }
        
        # 填充步骤数据
        for row_index, step_data in enumerate(self.steps_data):
            row = self.table.rowCount()
            self.table.insertRow(row)
            
            # 按照表头顺序填充数据
            headers = ["序号", "步骤名称", "执行函数", "功能参数", "下限", "上限", "单位", "格式", "比较模式", "变量名", "记录名称", "延时", "超时", "循环次数", "描述", "偏移", "备注", "步骤类型", "显示?", "记录?", "错误代码"]
            
            for col, header in enumerate(headers):
                if header == "序号":
                    # 序号列特殊处理，显示行号
                    self.table.setItem(row, col, QTableWidgetItem(str(row_index + 1)))
                else:
                    json_key = header_mapping.get(header, header)  # 如果没有映射，则使用原header
                    value = step_data.get(json_key, "")
                    item = QTableWidgetItem(str(value))
                    
                    # 如果是步骤名称列，尝试根据RunMode设置背景色
                    if header == "步骤名称" and "RunMode" in step_data:
                        run_mode = step_data.get("RunMode", "Normal").lower()
                        if run_mode == "disabled":
                            item.setBackground(QColor(*DISABLED_GREY))  # 灰色
                        elif run_mode == "forcepass":
                            item.setBackground(QColor(*FORCE_PASS_GREEN))  # 浅绿色
                        elif run_mode == "forcefail":
                            item.setBackground(QColor(*FORCE_FAIL_RED))  # 浅红色
                        # Normal模式保持默认颜色
                    
                    self.table.setItem(row, col, item)
        
        # 设置序号列的宽度
        self.table.setColumnWidth(0, 40)  # 序号列固定宽度为40像素
        
    def toggle_subsequence_status(self):
        """切换子序列状态"""
        # 获取当前状态并切换
        current_text = self.status_label.text()
        self.is_enabled = "禁用" not in current_text  # 当前如果是启用状态则变为禁用，反之亦然
        new_state = not self.is_enabled
        self.status_label.update_status_color(new_state)
        self.is_enabled = new_state
        
    def update_status_color(self, enabled):
        """根据子序列状态更新状态标签颜色"""
        # 调用StatusLabel的方法来更新状态
        self.status_label.update_status_color(enabled)
        self.is_enabled = enabled
        
    def set_subsequence_status(self, enabled):
        """外部接口：设置子序列状态"""
        self.update_status_color(enabled)
        
    def get_updated_data(self):
        """获取更新后的完整子序列数据"""
        # 从表格中收集步骤数据
        steps = []
        for row in range(self.table.rowCount()):
            step_data = {}
            headers = ["步骤名称", "功能名称", "功能参数", "下限", "上限", "单位", "格式", "比较模式", "变量名", "记录名称", "延时", "超时", "循环次数", "描述", "显示?", "记录?", "错误代码"]
            for col, header in enumerate(headers):
                item = self.table.item(row, col)
                step_data[header] = item.text() if item else ""
            steps.append(step_data)
        
        # 返回更新后的完整数据结构
        updated_data = {
            "SubSequenceName": self.subsequence_name,
            "SubSequenceContent": self.subsequence_content,
            "Enable": "TRUE" if self.is_enabled else "FALSE",
            "Steps": steps
        }
        
        return updated_data
        
    def get_subsequence_status(self):
        """获取子序列当前状态"""
        return self.is_enabled

    def _on_module_selected(self, category, module_name):
        """Handle when a module is selected from the tree widget"""
        row = self.table.rowCount()
        self.table.insertRow(row)
        
        # Set the basic structure for the new step
        for c in range(self.table.columnCount()):
            self.table.setItem(row, c, QTableWidgetItem(""))
        
        # Fill in the step name and function name based on the selected module
        self.table.setItem(row, 0, QTableWidgetItem(f"{category}_{module_name}"))  # 步骤名称
        self.table.setItem(row, 1, QTableWidgetItem(f"{category}.{module_name}"))  # 功能名称
        
        # Set default values for common fields
        self.table.setItem(row, 10, QTableWidgetItem("0"))  # 延时
        self.table.setItem(row, 11, QTableWidgetItem("30"))  # 超时
        self.table.setItem(row, 12, QTableWidgetItem("1"))  # 循环次数
        self.table.setItem(row, 14, QTableWidgetItem("TRUE"))  # 显示?
        self.table.setItem(row, 15, QTableWidgetItem("TRUE"))  # 记录?
        
        self.status_label.setText(f"Module {category}.{module_name} added to step {row+1}.")

    def _on_module_selected(self, category, module_name):
        """Handle when a module is selected from the tree widget"""
        row = self.table.rowCount()
        self.table.insertRow(row)
        
        # Set the basic structure for the new step
        for c in range(self.table.columnCount()):
            self.table.setItem(row, c, QTableWidgetItem(""))
        
        # Fill in the step name and function name based on the selected module
        self.table.setItem(row, 0, QTableWidgetItem(f"{category}_{module_name}"))  # 步骤名称
        self.table.setItem(row, 1, QTableWidgetItem(f"{category}.{module_name}"))  # 功能名称
        
        # Set default values for common fields
        self.table.setItem(row, 10, QTableWidgetItem("0"))  # 延时
        self.table.setItem(row, 11, QTableWidgetItem("30"))  # 超时
        self.table.setItem(row, 12, QTableWidgetItem("1"))  # 循环次数
        self.table.setItem(row, 14, QTableWidgetItem("TRUE"))  # 显示?
        self.table.setItem(row, 15, QTableWidgetItem("TRUE"))  # 记录?
        
        self.status_label.setText(f"Module {category}.{module_name} added to step {row+1}.")

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        for c in range(self.table.columnCount()):
            self.table.setItem(row, c, QTableWidgetItem(""))
        self.table.setItem(row, 0, QTableWidgetItem(str(row+1)))
        self.status_label.setText(f"Step {row+1} added.")
        
    def load_recipe_from_path(self, filepath):
        """从指定路径加载配方文件"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 根据新数据结构处理数据
            if 'SubSequenceName' in data:  # 新格式
                self.subsequence_name = data.get('SubSequenceName', '')
                self.subsequence_content = data.get('SubSequenceContent', '')
                enable_value = data.get('Enable', 'TRUE')
                self.is_enabled = str(enable_value).upper() in ['TRUE', 'YES', 'ENABLED', '1']
                self.steps_data = data.get('Steps', [])
            else:  # 兼容旧格式
                general_info = data.get('GeneralInfo', {})
                self.subsequence_name = general_info.get('TestName', '')
                self.subsequence_content = general_info.get('TestContent', '')
                self.steps_data = data.get('Steps', [])
                # 对于旧格式，默认启用
                self.is_enabled = True
            
            # 更新状态标签
            self.status_label.update_status_color(self.is_enabled)
            
            # 使用新数据填充表格
            self.populate_table_with_steps()
            
            # 显示加载状态
            self.path_label.setText(f"脚本路径: {filepath}")
            self.status_label.setText("配方加载成功")
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"无法加载配方文件: {str(e)}")

    def delete_step(self):
        rows = set(idx.row() for idx in self.table.selectedIndexes())
        for r in sorted(rows, reverse=True):
            self.table.removeRow(r)
        self.status_label.setText(f"Deleted {len(rows)} step(s).")

    def move_step_up(self):
        row = self.table.currentRow()
        if row > 0:
            for c in range(self.table.columnCount()):
                above = self.table.item(row-1, c).text() if self.table.item(row-1, c) else ""
                curr = self.table.item(row, c).text() if self.table.item(row, c) else ""
                self.table.setItem(row-1, c, QTableWidgetItem(curr))
                self.table.setItem(row, c, QTableWidgetItem(above))
            self.table.selectRow(row-1)
            self.status_label.setText("Step moved up.")

    def move_step_down(self):
        row = self.table.currentRow()
        if row < self.table.rowCount()-1 and row >= 0:
            for c in range(self.table.columnCount()):
                below = self.table.item(row+1, c).text() if self.table.item(row+1, c) else ""
                curr = self.table.item(row, c).text() if self.table.item(row, c) else ""
                self.table.setItem(row+1, c, QTableWidgetItem(curr))
                self.table.setItem(row, c, QTableWidgetItem(below))
            self.table.selectRow(row+1)
            self.status_label.setText("Step moved down.")

    def copy_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self._copied_row = [self.table.item(row, c).text() if self.table.item(row, c) else "" for c in range(self.table.columnCount())]
            self.status_label.setText("Step copied.")

    def paste_step(self):
        row = self.table.currentRow()
        if self._copied_row is not None and row >= 0:
            self.table.insertRow(row+1)
            for c, v in enumerate(self._copied_row):
                self.table.setItem(row+1, c, QTableWidgetItem(v))
            self.status_label.setText("Step pasted.")

    def _start_timer(self):
        timer = QTimer(self)
        timer.timeout.connect(self._update_time)
        timer.start(1000)
        self._update_time()

    def _update_time(self):
        now = QDateTime.currentDateTime()
        self.time_label.setText(now.toString("yyyy-MM-dd  HH:mm:ss"))

    def save_recipe(self):
        """保存配方文件到指定路径"""
        # 优先使用传递过来的路径的目录作为默认路径
        if self.recipe_file_path:
            default_dir = os.path.dirname(self.recipe_file_path)
        else:
            # 备选：使用默认路径为Config/recipe文件夹
            config_recipe_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "config", "Recipe")
            default_dir = config_recipe_path if os.path.exists(config_recipe_path) else ""
        
        # 获取保存文件路径
        if not self.recipe_file_path:
            self.recipe_file_path, _ = QFileDialog.getSaveFileName(
                self, "保存配方文件", default_dir, "JSON Files (*.json);;All Files (*)"
            )
            
        if self.recipe_file_path:
            try:
                # 构建要保存的数据 - 使用新的数据结构
                data = {
                    "SubSequenceName": self.subsequence_name,
                    "SubSequenceContent": self.subsequence_content,
                    "Enable": "TRUE" if self.is_enabled else "FALSE",
                    "Steps": []
                }
                
                # 添加表格中的所有步骤
                for row in range(self.table.rowCount()):
                    step_data = {}
                    for col in range(self.table.columnCount()):
                        header = self.table.horizontalHeaderItem(col).text()
                        item = self.table.item(row, col)
                        step_data[header] = item.text() if item else ""
                    data["Steps"].append(step_data)
                
                # 写入文件
                with open(self.recipe_file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                self.path_label.setText(f"脚本路径: {self.recipe_file_path}")
                self.status_label.setText("配方保存成功")
                
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法保存配方文件: {str(e)}")
        
    def load_recipe(self):
        """打开并加载配方文件"""
        # 优先使用传递过来的路径的目录作为默认路径
        if self.recipe_file_path:
            default_dir = os.path.dirname(self.recipe_file_path)
        else:
            # 备选：使用默认路径为Config/recipe文件夹
            config_recipe_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "config", "Recipe")
            default_dir = config_recipe_path if os.path.exists(config_recipe_path) else ""
        
        filepath, _ = QFileDialog.getOpenFileName(
            self, "打开配方文件", default_dir, "JSON Files (*.json);;All Files (*)"
        )
        
        if filepath:
            self.load_recipe_from_path(filepath)
            self.recipe_file_path = filepath

    def save_recipe(self):
        """保存配方文件到指定路径"""
        # 获取保存文件路径
        if not self.recipe_file_path:
            self.recipe_file_path, _ = QFileDialog.getSaveFileName(
                self, "保存配方文件", "", "JSON Files (*.json);;All Files (*)"
            )
            
        if self.recipe_file_path:
            try:
                # 构建要保存的数据 - 使用新的数据结构
                data = {
                    "SubSequenceName": self.subsequence_name,
                    "SubSequenceContent": self.subsequence_content,
                    "Enable": "TRUE" if self.is_enabled else "FALSE",
                    "Steps": []
                }
                
                # 添加表格中的所有步骤
                for row in range(self.table.rowCount()):
                    step_data = {}
                    for col in range(self.table.columnCount()):
                        header = self.table.horizontalHeaderItem(col).text()
                        item = self.table.item(row, col)
                        step_data[header] = item.text() if item else ""
                    data["Steps"].append(step_data)
                
                # 写入文件
                with open(self.recipe_file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                self.path_label.setText(f"脚本路径: {self.recipe_file_path}")
                self.status_label.setText("配方保存成功")
                
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法保存配方文件: {str(e)}")
        
    def load_recipe(self):
        """打开并加载配方文件"""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "打开配方文件", "", "JSON Files (*.json);;All Files (*)"
        )
        
        if filepath:
            self.load_recipe_from_path(filepath)
            self.recipe_file_path = filepath

    # 可根据需要补充表格操作等方法
# 正确的主程序入口应在类定义外部
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = SubSequenceEditorDialog()
    win.show()
    sys.exit(app.exec())