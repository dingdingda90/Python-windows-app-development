import yaml
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItem
from PySide6.QtCore import Signal, Qt, Qt

class ModuleTreeWidget(QTreeWidget):
    # Signal emitted when a module item is double-clicked
    module_selected = Signal(str, str)  # (category, module_name)
    
    def __init__(self, config_path, parent=None):
        super().__init__(parent)
        self.setHeaderLabel("Available Modules")
        # 设置统一的字体和字号
        font = self.font()
        font.setPointSize(12)  # 设置字体大小为12
        self.setFont(font)
        # 设置很小的缩进，使第三级更靠左
        self.setIndentation(10)  # 减小缩进到5像素
        self.load_modules(config_path)
        # Enable double-click to select items
        self.itemDoubleClicked.connect(self._on_item_double_clicked)

    def load_modules(self, config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            modules = yaml.safe_load(f)
        self.clear()
        self._add_items(self, modules)

    def _add_items(self, parent, data):
        if isinstance(data, dict):
            for key, value in data.items():
                # Create the instrument category as a parent item
                item = QTreeWidgetItem([key.strip() if isinstance(key, str) else str(key)])
                # 设置统一的字体
                font = item.font(0)
                font.setPointSize(12)
                item.setFont(0, font)
                parent.addTopLevelItem(item) if parent is self else parent.addChild(item)
                if parent is self:
                    item.setData(0, 0, key)  # Store category
                
                # Add children appropriately
                if isinstance(value, list):
                    # If value is a list, add each item as a direct child of the key
                    for v in value:
                        child_item = QTreeWidgetItem([str(v).strip() if isinstance(v, str) else str(v)])
                        # 设置统一的字体
                        child_font = child_item.font(0)
                        child_font.setPointSize(12)
                        child_item.setFont(0, child_font)
                        child_item.setData(0, 1, f"{key}.{v}")  # Store full module.operation
                        # 设置第三级项目文字左对齐
                        child_item.setTextAlignment(0, Qt.AlignLeft)
                        item.addChild(child_item)
                else:
                    # If value is not a list, continue with recursion
                    self._add_items(item, value)
        elif isinstance(data, list):
            for v in data:
                item = QTreeWidgetItem([str(v).strip() if isinstance(v, str) else str(v)])
                # 设置统一的字体
                font = item.font(0)
                font.setPointSize(12)
                item.setFont(0, font)
                item.setData(0, 1, v)  # Store module name
                parent.addChild(item)
                
    def _on_item_double_clicked(self, item, column):
        # Get the module name and category
        module_name = item.data(0, 1)  # Full module.operation name stored in user data
        if module_name is not None:
            # Extract category from the module name
            if '.' in str(module_name):
                category = str(module_name).split('.')[0]
            else:
                # Fallback to stored category data
                parent = item.parent()
                category = parent.text(0) if parent else item.data(0, 0)
            if category and module_name:
                self.module_selected.emit(category, str(module_name))