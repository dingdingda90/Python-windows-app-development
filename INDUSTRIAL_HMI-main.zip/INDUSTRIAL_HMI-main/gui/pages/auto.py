
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QFrame, QGridLayout, QPushButton, QSizePolicy
from PySide6.QtCore import Qt
from core.style import BG

class AutoPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"background-color: {BG};")
        root = QVBoxLayout(self)
        title = QLabel("AUTO PAGE")
        title.setStyleSheet("font-size:28px; font-weight:bold; color:black;")
        title.setAlignment(Qt.AlignCenter)
        root.addWidget(title)
        # 可继续添加自动页面的详细布局
