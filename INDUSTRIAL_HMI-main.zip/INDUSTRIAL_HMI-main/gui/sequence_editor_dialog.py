from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QHBoxLayout
from PySide6.QtCore import Qt
from core.style import BG

class SequenceEditorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Test Sequence Editor")
        self.setStyleSheet(f"background-color: {BG};")
        self.resize(600, 400)
        layout = QVBoxLayout(self)
        title = QLabel("Test Sequence Editor")
        title.setStyleSheet("font-size:24px; font-weight:bold; color:black;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Step", "Action Type", "Parameter", "Comment"])
        layout.addWidget(self.table)

        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Step")
        del_btn = QPushButton("Delete Step")
        save_btn = QPushButton("Save Sequence")
        load_btn = QPushButton("Load Sequence")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(del_btn)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(load_btn)
        layout.addLayout(btn_layout)

        add_btn.clicked.connect(self.add_step)
        del_btn.clicked.connect(self.del_step)

    def add_step(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(str(row+1)))
        self.table.setItem(row, 1, QTableWidgetItem("Action"))
        self.table.setItem(row, 2, QTableWidgetItem("Parameter"))
        self.table.setItem(row, 3, QTableWidgetItem("Comment"))

    def del_step(self):
        row = self.table.currentRow()
        if row >= 0:
            self.table.removeRow(row)
