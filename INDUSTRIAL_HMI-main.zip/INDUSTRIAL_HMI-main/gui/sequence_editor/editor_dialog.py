
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QToolBar, QFileDialog, QMessageBox, QSplitter, QWidget
)
from PySide6.QtCore import Qt
import csv
import os
from .module_tree import ModuleTreeWidget
from .sequence_tabs import SequenceTabsWidget


class SequenceEditorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Test Sequence Editor")
        self.resize(1000, 600)
        layout = QVBoxLayout(self)

        # 工具栏
        toolbar = QToolBar()
        btn_new = QPushButton("New Subsequence")
        btn_open = QPushButton("Open")
        btn_save = QPushButton("Save")
        btn_add = QPushButton("Add Step")
        btn_delete = QPushButton("Delete Step")
        btn_run = QPushButton("Run")
        toolbar.addWidget(btn_new)
        toolbar.addWidget(btn_open)
        toolbar.addWidget(btn_save)
        toolbar.addSeparator()
        toolbar.addWidget(btn_add)
        toolbar.addWidget(btn_delete)
        toolbar.addSeparator()
        toolbar.addWidget(btn_run)
        layout.addWidget(toolbar)

        # 主体分割区
        splitter = QSplitter(Qt.Horizontal)
        # 模块树（左侧）
        # 修正路径，确保从项目根目录查找 config/modules.yaml
        # 用工程根目录下的 config/modules.yaml
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        config_path = os.path.join(project_root, 'config', 'modules.yaml')
        self.module_tree = ModuleTreeWidget(config_path)
        self.module_tree.setMinimumWidth(220)
        splitter.addWidget(self.module_tree)

        # 序列Tabs（右侧）
        self.tabs = SequenceTabsWidget()
        splitter.addWidget(self.tabs)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter)

        # 状态栏
        self.status = QLabel()
        layout.addWidget(self.status)

        # 连接信号
        btn_new.clicked.connect(self.add_subsequence)
        btn_open.clicked.connect(self.open_sequence)
        btn_save.clicked.connect(self.save_sequence)
        btn_add.clicked.connect(self.add_step)
        btn_delete.clicked.connect(self.delete_step)
        btn_run.clicked.connect(self.run_sequence)
        self.tabs.currentChanged.connect(self.on_tab_changed)

        self.add_subsequence()  # 默认加一个子序列
        self.on_tab_changed(0)

    def add_subsequence(self):
        self.tabs.add_subsequence()
        self.tabs.setCurrentIndex(self.tabs.count()-1)
        self.status.setText("New subsequence added.")

    def on_tab_changed(self, idx):
        # 只有子序列显示模块树（主序列idx==0不显示）
        self.module_tree.setVisible(idx > 0)

    def open_sequence(self):
        # 省略实现，可参考原有open_sequence
        self.status.setText("Open sequence not implemented.")

    def save_sequence(self):
        # 省略实现，可参考原有save_sequence
        self.status.setText("Save sequence not implemented.")

    def add_step(self):
        tab = self.tabs.currentWidget()
        if tab:
            row = tab.rowCount()
            tab.insertRow(row)
            for c in range(tab.columnCount()):
                tab.setItem(row, c, QTableWidgetItem(""))
            tab.setItem(row, 0, QTableWidgetItem(str(row+1)))
            self.status.setText(f"Step {row+1} added.")

    def delete_step(self):
        tab = self.tabs.currentWidget()
        if tab:
            rows = set(idx.row() for idx in tab.selectedIndexes())
            for r in sorted(rows, reverse=True):
                tab.removeRow(r)
            self.status.setText(f"Deleted {len(rows)} step(s).")

    def run_sequence(self):
        tab = self.tabs.currentWidget()
        if tab:
            steps = []
            for r in range(tab.rowCount()):
                row = [tab.item(r, c).text() if tab.item(r, c) else '' for c in range(tab.columnCount())]
                steps.append(row)
            QMessageBox.information(self, "Run", f"Running {len(steps)} steps in current sequence. (Demo)")
            self.status.setText("Sequence run (demo).")

    def new_sequence(self):
        self.table.setRowCount(0)
        self.status.setText("New sequence created.")

    def open_sequence(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open Sequence", "", "CSV Files (*.csv)")
        if path:
            with open(path, newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                self.table.setRowCount(0)
                for row in reader:
                    self.add_step(row)
            self.status.setText(f"Loaded: {path}")

    def save_sequence(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save Sequence", "", "CSV Files (*.csv)")
        if path:
            with open(path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                for r in range(self.table.rowCount()):
                    row = [self.table.item(r, c).text() if self.table.item(r, c) else '' for c in range(self.table.columnCount())]
                    writer.writerow(row)
            self.status.setText(f"Saved: {path}")

    def add_step(self, values=None):
        row = self.table.rowCount()
        self.table.insertRow(row)
        if values:
            for c, v in enumerate(values):
                self.table.setItem(row, c, QTableWidgetItem(v))
        else:
            self.table.setItem(row, 0, QTableWidgetItem(str(row+1)))
            self.table.setItem(row, 1, QTableWidgetItem("Action"))
            self.table.setItem(row, 2, QTableWidgetItem("Param"))
            self.table.setItem(row, 3, QTableWidgetItem("0"))
            self.table.setItem(row, 4, QTableWidgetItem(""))
        self.status.setText(f"Step {row+1} added.")

    def delete_step(self):
        rows = set(idx.row() for idx in self.table.selectedIndexes())
        for r in sorted(rows, reverse=True):
            self.table.removeRow(r)
        self.status.setText(f"Deleted {len(rows)} step(s).")

    def run_sequence(self):
        steps = []
        for r in range(self.table.rowCount()):
            step = [self.table.item(r, c).text() if self.table.item(r, c) else '' for c in range(self.table.columnCount())]
            steps.append(step)
        QMessageBox.information(self, "Run", f"Running {len(steps)} steps. (Demo)")
        self.status.setText("Sequence run (demo).")
