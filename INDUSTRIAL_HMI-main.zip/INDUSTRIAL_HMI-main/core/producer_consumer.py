# 生产者-消费者队列
import queue

class ProducerConsumerQueue:
    def __init__(self):
        self.queue = queue.Queue()
    def produce(self, item):
        self.queue.put(item)
    def consume(self):
        return self.queue.get()
