# EntryViewer (上位机 模板)

这是一个用于上位机开发的模版工程，基于 PySide6（Qt）构建。项目包括：
- UI 组件：`ui/`（节点编辑器、主窗口示例）
- 业务窗口：`entryviewer/app.py`（现有主程序逻辑）
- 设备抽象与 Mock：`entryviewer/devices/`（演示信号/槽与生产者-消费者）
- 架构文档：`docs/ARCHITECTURE.md`

快速开始（Windows）

1. 建议使用虚拟环境：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r .\config\requirements.txt
```

2. 运行演示 UI（带 Mock 设备）：

```powershell
python .\main.py
# 或者
.\run.ps1
```

3. 开发依赖（lint/test）：

```powershell
python -m pip install -r requirements-dev.txt
pytest
flake8
```

重要文件与编辑入口
- `main.py`：应用入口（优先运行 `entryviewer.ui.demo_app`，回退到 `entryviewer.MainWindow`）
- `entryviewer/app.py`：原始主窗口与业务逻辑
- `entryviewer/ui/main_window.py`：节点编辑器主窗口（PySide6）
- `entryviewer/devices/`：设备抽象与 Mock 实现（供离线开发）
- `docs/ARCHITECTURE.md`：架构说明与开发建议

Mock 开发说明
- Mock 驱动（`entryviewer/devices/mock_device.py`）用于离线开发与测试，模拟设备行为、延迟与错误，避免依赖真机进行 UI 与逻辑开发。

下一步建议
- 固化 `requirements.txt` 到仓库根（目前在 `config/requirements.txt`）
- 添加单元测试和 CI（GitHub Actions）
- 实现 `entryviewer/services`（灯控、打印队列、日志）和 `entryviewer/comms`（MES/CAN skeleton）
