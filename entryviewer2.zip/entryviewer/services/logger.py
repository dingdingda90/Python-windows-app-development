import logging
from PySide6.QtCore import QObject, Signal
from typing import Optional


class QtLogHandler(logging.Handler):
    def __init__(self, emitter: QObject, signal_name: str = 'log_emitted'):
        super().__init__()
        self._emitter = emitter
        self._signal_name = signal_name

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            # emit level name and message
            getattr(self._emitter, self._signal_name).emit(record.levelname, msg)
        except Exception:
            pass


class LoggerService(QObject):
    """Logger service that exposes a Qt signal for log lines and wraps
    Python logging so other modules can call logger.info(...) etc.
    """

    log_emitted = Signal(str, str)  # level, message

    def __init__(self, name: str = 'entryviewer', parent: Optional[QObject] = None):
        super().__init__(parent)
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        handler = QtLogHandler(self, 'log_emitted')
        formatter = logging.Formatter('%(asctime)s %(name)s [%(levelname)s] %(message)s')
        handler.setFormatter(formatter)
        # avoid adding multiple handlers when instantiated multiple times
        if not any(isinstance(h, QtLogHandler) for h in self.logger.handlers):
            self.logger.addHandler(handler)

    def debug(self, msg: str, *args, **kwargs) -> None:
        self.logger.debug(msg, *args, **kwargs)

    def info(self, msg: str, *args, **kwargs) -> None:
        self.logger.info(msg, *args, **kwargs)

    def warning(self, msg: str, *args, **kwargs) -> None:
        self.logger.warning(msg, *args, **kwargs)

    def error(self, msg: str, *args, **kwargs) -> None:
        self.logger.error(msg, *args, **kwargs)
