from PySide6.QtCore import QObject, Signal
from typing import Dict


class IndicatorsService(QObject):
    """Centralized LEDs/indicator service.

    Emits `indicator_changed` with (name, state) when an indicator updates.
    """

    indicator_changed = Signal(str, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._states: Dict[str, object] = {}

    def set_state(self, name: str, state: object) -> None:
        """Set indicator state (e.g., 'green', True/False, dict of values)."""
        self._states[name] = state
        self.indicator_changed.emit(name, state)

    def get_state(self, name: str, default=None):
        return self._states.get(name, default)

    def all_states(self):
        return dict(self._states)
