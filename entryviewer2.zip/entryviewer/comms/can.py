import threading
from PySide6.QtCore import QObject, Signal
from typing import Any


class CANBus(QObject):
    """Skeleton CAN bus interface. Real implementations should wrap python-can
    or OS-specific drivers. Provides signals for received frames and errors.
    """

    frame_received = Signal(object)
    error = Signal(str)
    connected = Signal()
    disconnected = Signal()

    def __init__(self, channel: str = 'can0', bitrate: int = 500000, parent=None):
        super().__init__(parent)
        self.channel = channel
        self.bitrate = bitrate
        self._running = False
        self._thread = None

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._reader, daemon=True)
        self._thread.start()
        self.connected.emit()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=0.5)
        self.disconnected.emit()

    def _reader(self):
        # Placeholder reader: real impl would block on CAN frames and emit them
        import time
        while self._running:
            time.sleep(0.5)
            # emit dummy frame for demo
            self.frame_received.emit({"id": 0x123, "data": b"\x01\x02"})

    def send_frame(self, can_id: int, data: bytes) -> bool:
        # Implement send using real CAN API; return True if accepted
        return True
