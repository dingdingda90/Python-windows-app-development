"""Simple service registry for storing global services by name.

Use `register_service(name, obj)` at startup and `get_service(name)` to access.
"""
from typing import Any, Dict

_SERVICES: Dict[str, Any] = {}


def register_service(name: str, obj: Any) -> None:
    _SERVICES[name] = obj


def get_service(name: str, default: Any = None) -> Any:
    return _SERVICES.get(name, default)


def clear_services() -> None:
    _SERVICES.clear()
