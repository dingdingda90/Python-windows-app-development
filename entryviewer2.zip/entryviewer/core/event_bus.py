from PySide6.QtCore import QObject, Signal
from typing import Any, Callable


class EventBus(QObject):
    """Lightweight Qt-based event bus. Publish with `publish(topic, payload)`
    and subscribe with `subscribe(topic, slot)`.
    """

    _signal = Signal(str, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        # topic -> list of slots is not required because Qt signal can carry topic

    def publish(self, topic: str, payload: Any) -> None:
        # deliver topic+payload to all connected slots
        self._signal.emit(topic, payload)

    def subscribe(self, slot: Callable[[str, Any], None]) -> None:
        self._signal.connect(slot)

    def unsubscribe(self, slot: Callable[[str, Any], None]) -> None:
        try:
            self._signal.disconnect(slot)
        except Exception:
            pass
