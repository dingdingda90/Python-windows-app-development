import os
import json
import configparser
from typing import Any, Dict, Optional


class ConfigManager:
    """Simple config manager supporting INI and JSON persistence.

    Usage:
        cfg = ConfigManager()
        cfg.load_ini('TPEntryManView.ini')
        cfg.get('Section', 'key', fallback='')
        cfg.save_json('config.json')
    """

    def __init__(self):
        self._parser = configparser.ConfigParser()

    def _resolve_path(self, path: str) -> Optional[str]:
        """Resolve a path relative to package, cwd or frozen exe."""
        if os.path.isabs(path) and os.path.exists(path):
            return path
        # try relative to cwd
        p = os.path.join(os.getcwd(), path)
        if os.path.exists(p):
            return p
        # try relative to this file
        base = os.path.dirname(os.path.abspath(__file__))
        p = os.path.join(base, path)
        if os.path.exists(p):
            return p
        # when frozen, try executable dir
        if getattr(sys, 'frozen', False) and hasattr(sys, 'executable'):
            exe_dir = os.path.dirname(os.path.abspath(sys.executable))
            p = os.path.join(exe_dir, path)
            if os.path.exists(p):
                return p
        return None

    def load_ini(self, filename: str) -> None:
        path = filename
        if not os.path.exists(path):
            # try resolution heuristics
            resolved = self._resolve_path(filename)
            if resolved:
                path = resolved
        self._parser.read(path, encoding='utf-8')

    def get(self, section: str, option: str, fallback: Any = None) -> Any:
        try:
            return self._parser.get(section, option)
        except Exception:
            return fallback

    def set(self, section: str, option: str, value: Any) -> None:
        if section not in self._parser:
            self._parser[section] = {}
        self._parser[section][option] = str(value)

    def save_ini(self, filename: str) -> None:
        with open(filename, 'w', encoding='utf-8') as f:
            self._parser.write(f)

    def to_dict(self) -> Dict[str, Dict[str, str]]:
        return {s: dict(self._parser[s]) for s in self._parser.sections()}

    def save_json(self, filename: str) -> None:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
