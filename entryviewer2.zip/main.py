import sys
from PySide6.QtWidgets import QApplication


def _make_fallback_runner():
    try:
        from entryviewer import MainWindow

        def run():
            app = QApplication(sys.argv)
            window = MainWindow()
            window.show()
            return app.exec()

        return run
    except Exception as _:
        def run():
            print("No GUI entrypoint available in package 'entryviewer'.")
            return 1


def _choose_entry():
    """Try to prefer the demo app if present, otherwise fallback to package MainWindow."""
    try:
        from entryviewer.ui.demo_app import run as demo_run
        return demo_run
    except Exception:
        return _make_fallback_runner()


if __name__ == "__main__":
    runner = _choose_entry()
    sys.exit(runner())