from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QPushButton,
    QListWidget,
    QLabel,
    QHBoxLayout,
)
from PySide6.QtCore import Slot, QTimer
import sys
import queue
import threading
import time

from entryviewer.devices.mock_device import MockDevice
from entryviewer.core.event_bus import EventBus
from entryviewer.services.indicators import IndicatorsService
from entryviewer.comms.mes import MESClient
from entryviewer.comms.can import CANBus
from entryviewer.core.service_registry import register_service
from entryviewer.services.logger import LoggerService


class CommandWorker(threading.Thread):
    """Background consumer thread that takes commands from a queue and sends
    them to a device. Demonstrates producer-consumer where UI pushes commands
    and a worker performs blocking I/O.
    """

    def __init__(self, device, cmd_queue):
        super().__init__(daemon=True)
        self.device = device
        self.q = cmd_queue
        self._running = True

    def run(self):
        while self._running:
            try:
                cmd = self.q.get(timeout=0.5)
            except queue.Empty:
                continue
            # send may be blocking in real drivers
            try:
                self.device.send(cmd)
            except Exception:
                pass

    def stop(self):
        self._running = False


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('EntryViewer Demo')
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        self.status_label = QLabel('Status: stopped')
        layout.addWidget(self.status_label)

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)

        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton('Start Device')
        self.stop_btn = QPushButton('Stop Device')
        self.send_btn = QPushButton('Send Command')
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addWidget(self.send_btn)

        layout.addLayout(btn_layout)

        # core services
        self.event_bus = EventBus()
        self.indicators = IndicatorsService()
        self.mes = MESClient()
        self.can = CANBus()
        self.logger = LoggerService()
        register_service('logger', self.logger)

        # connect logger to UI list
        self.logger.log_emitted.connect(lambda level, msg: self.list_widget.insertItem(0, f"LOG {level}: {msg}"))

        # demo device
        self.device = MockDevice('demo-device', interval=1.0)
        self.device.data_ready.connect(self.on_data_ready)
        self.device.connected.connect(lambda: self.status_label.setText('Status: connected'))
        self.device.disconnected.connect(lambda: self.status_label.setText('Status: disconnected'))
        self.device.error.connect(self.on_error)

        # wire core signals to UI
        self.event_bus.subscribe(self.on_bus_event)
        self.indicators.indicator_changed.connect(self.on_indicator_changed)
        self.mes.message_received.connect(lambda msg: self.list_widget.insertItem(0, f"MES: {msg}"))
        self.can.frame_received.connect(lambda f: self.list_widget.insertItem(0, f"CAN frame: {f}"))

        self.cmd_queue = queue.Queue()
        self.cmd_worker = CommandWorker(self.device, self.cmd_queue)
        self.cmd_worker.start()

        self.start_btn.clicked.connect(self.device.connect)
        self.stop_btn.clicked.connect(self.device.disconnect)
        self.send_btn.clicked.connect(self.send_command)

        # additional controls for services
        self.mes_start_btn = QPushButton('Start MES')
        self.mes_stop_btn = QPushButton('Stop MES')
        self.can_start_btn = QPushButton('Start CAN')
        self.can_stop_btn = QPushButton('Stop CAN')
        self.toggle_indicator_btn = QPushButton('Toggle Green Light')
        btn_layout.addWidget(self.mes_start_btn)
        btn_layout.addWidget(self.mes_stop_btn)
        btn_layout.addWidget(self.can_start_btn)
        btn_layout.addWidget(self.can_stop_btn)
        btn_layout.addWidget(self.toggle_indicator_btn)

        self.mes_start_btn.clicked.connect(self.mes.start)
        self.mes_stop_btn.clicked.connect(self.mes.stop)
        self.can_start_btn.clicked.connect(self.can.start)
        self.can_stop_btn.clicked.connect(self.can.stop)
        self.toggle_indicator_btn.clicked.connect(self.toggle_indicator)

        # health/status label
        self.health_label = QLabel('Queue: 0')
        layout.addWidget(self.health_label)

        # periodic health update
        self._health_timer = QTimer(self)
        self._health_timer.timeout.connect(self._update_health)
        self._health_timer.start(500)

        # log startup
        self.logger.info('Demo app started')

    @Slot(object)
    def on_data_ready(self, payload):
        self.list_widget.insertItem(0, f"{payload['device']} {payload['value']:.3f} @{payload['ts']:.1f}")

    @Slot(str)
    def on_error(self, txt):
        self.list_widget.insertItem(0, f"ERROR: {txt}")

    def send_command(self):
        self.cmd_queue.put({'cmd': 'ping', 'ts': time.time()})
        self.logger.info('Enqueued command ping')

    def toggle_indicator(self):
        # flip a boolean state for demo
        cur = self.indicators.get_state('green', False)
        new = not bool(cur)
        self.indicators.set_state('green', new)
        self.logger.info(f"Indicator 'green' set to {new}")

    def on_bus_event(self, topic, payload):
        self.list_widget.insertItem(0, f"BUS {topic}: {payload}")
        self.logger.debug(f"Bus event {topic}: {payload}")

    @Slot(str, object)
    def on_indicator_changed(self, name, state):
        self.list_widget.insertItem(0, f"INDICATOR {name} -> {state}")

    def closeEvent(self, event):
        # ensure background threads are stopped
        try:
            self.device.disconnect()
        except Exception:
            pass
        try:
            self.cmd_worker.stop()
        except Exception:
            pass
        try:
            self.mes.stop()
        except Exception:
            pass
        try:
            self.can.stop()
        except Exception:
            pass
        self.logger.info('Demo app shutting down')
        super().closeEvent(event)

    def _update_health(self):
        try:
            qsize = self.cmd_queue.qsize()
            self.health_label.setText(f'Queue: {qsize}')
        except Exception:
            pass


def run():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    return app.exec()


if __name__ == '__main__':
    sys.exit(run())
