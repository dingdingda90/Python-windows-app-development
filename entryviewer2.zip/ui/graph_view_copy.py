from PySide6.QtCore import Qt, QPointF
from PySide6.QtWidgets import QWidget, QVBoxLayout
from NodeGraphQt import NodeGraph

class GraphView(QWidget):
    """节点图视图组件"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # 创建节点图
        self.graph = NodeGraph()
        self.graph_widget = self.graph.widget
        
        # 设置缩放限制
        self.min_zoom = 0.1
        self.max_zoom = 3.0
        
        layout.addWidget(self.graph_widget)
        
    def register_nodes(self, node_classes):
        """注册节点类"""
        for node_class in node_classes:
            self.graph.register_node(node_class)
            
    def wheel_event(self, event):
        """处理滚轮事件，实现缩放限制"""
        current_zoom = self.graph.viewer_zoom()
        
        delta = event.angleDelta().y()
        if delta > 0:
            new_zoom = current_zoom * 1.1
            if new_zoom > self.max_zoom:
                new_zoom = self.max_zoom
        else:
            new_zoom = current_zoom * 0.9
            if new_zoom < self.min_zoom:
                new_zoom = self.min_zoom
        
        self.graph.set_viewer_zoom(new_zoom)
        event.accept()
        
    def get_graph_center(self):
        """获取节点图的中心位置"""
        try:
            scene = self.graph.scene()
            views = scene.views()
            
            if not views:
                return QPointF(0, 0)
                
            view = views[0]
            view_rect = view.viewport().rect()
            
            center_x = view_rect.width() / 2
            center_y = view_rect.height() / 2
            
            scene_pos = view.mapToScene(int(center_x), int(center_y))
            return scene_pos
        except Exception as e:
            print(f"获取中心位置时出错: {e}")
            return QPointF(0, 0)