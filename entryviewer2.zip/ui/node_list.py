from PySide6.QtWidgets import QListWidget, QMenu, QListWidgetItem, QApplication
from PySide6.QtGui import QAction, QDrag, QPixmap, QPainter, QColor, QPen, QBrush, QCursor
from PySide6.QtCore import Qt, QMimeData, QPoint, QTimer

class DraggableNodeList(QListWidget):
    """可拖拽的节点列表（优化版）"""
    
    def __init__(self, parent=None, drag_drop_handler=None):
        super().__init__(parent)
        self.setDragEnabled(True)  # 启用拖拽功能
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.drag_drop_handler = drag_drop_handler
        self.customContextMenuRequested.connect(self.show_context_menu)
        self.drag_start_position = None  # 记录拖拽起始位置
        self.drag_threshold = 8  # 拖拽启动最小距离(像素)
    
    def show_context_menu(self, position):
        """显示右键菜单"""
        item = self.itemAt(position)
        if item:
            menu = QMenu(self)
            add_action = QAction("添加节点", self)
            add_action.triggered.connect(lambda: self.window().add_node_from_list(item))
            menu.addAction(add_action)
            menu.exec(self.mapToGlobal(position))
    
    def mousePressEvent(self, event):
        """处理鼠标按下事件，记录拖拽起始位置"""
        super().mousePressEvent(event)
        if event.button() == Qt.LeftButton:
            self.drag_start_position = event.position().toPoint()
            # 启动定时器防止误触
            self.drag_timer = QTimer.singleShot(200, self._reset_drag_start)
    
    def _reset_drag_start(self):
        """重置拖拽起始位置（定时器超时未移动时）"""
        if self.drag_start_position and not self.underMouse():
            self.drag_start_position = None
    
    def mouseMoveEvent(self, event):
        """处理鼠标移动事件，启动拖拽操作"""
        # 首先检查左键是否按下
        if not (event.buttons() & Qt.LeftButton):
            self.drag_start_position = None
            return
            
        # 检查是否有有效的拖拽起始位置
        if self.drag_start_position is None:
            return
            
        # 计算鼠标移动距离
        distance = (event.position().toPoint() - self.drag_start_position).manhattanLength()
        
        # 只有当移动距离超过阈值时才处理拖拽
        if distance < self.drag_threshold:
            return
            
        # 获取当前选中的项目
        item = self.currentItem()
        
        # 确保有选中的项目
        if item:
            node_type = item.text()
            self._start_drag(item, node_type, event)
            self.drag_start_position = None  # 重置拖拽起始位置
    
    def _start_drag(self, item, node_type, event):
        """启动拖拽操作（含可视化图标）"""
        if not self.drag_drop_handler:
            print("错误: drag_drop_handler 未初始化")
            return
            
        drag = QDrag(self)
        mime_data = QMimeData()
        mime_data.setText(node_type)
        drag.setMimeData(mime_data)
        
        # 创建自适应大小的拖拽图标
        visual_rect = self.visualItemRect(item)
        font_metrics = self.fontMetrics()
        text = item.text()
        text_width = font_metrics.horizontalAdvance(text)
        text_height = font_metrics.height()
        
        padding = 10
        icon_width = max(text_width + padding * 2, visual_rect.width())
        icon_height = max(text_height + padding * 2, visual_rect.height())
        
        pixmap = QPixmap(int(icon_width), int(icon_height))
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # 绘制背景
        painter.setBrush(QBrush(QColor(100, 149, 237)))
        painter.setPen(QPen(QColor(70, 130, 180), 2))
        painter.drawRoundedRect(0, 0, icon_width, icon_height, 8, 8)
        
        # 绘制文本
        painter.setPen(Qt.white)
        painter.drawText(
            0, 0, icon_width, icon_height,
            Qt.AlignCenter, text
        )
        
        painter.end()
        
        # 设置拖拽图标和热点
        drag.setPixmap(pixmap)
        
        # 计算热点位置（鼠标在项目上的相对位置）
        hotspot = event.position().toPoint() - self.mapFromGlobal(self.mapToGlobal(visual_rect.topLeft()))
        drag.setHotSpot(hotspot)
        
        # 执行拖拽（复制模式）
        drag.exec(Qt.CopyAction)