from PySide6.QtWidgets import (QWidget, QVBoxLayout, QGroupBox, QFormLayout, 
                            QLineEdit, QLabel, QPushButton)
from PySide6.QtCore import Signal

class NodePropertiesPanel(QWidget):
    node_selected = Signal(object)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_node = None
        self._ignore_name_change = False
        self.graph = None
        self.init_ui()
        
    def init_ui(self):
        # 保持原有代码不变...
        pass
        
    def _on_name_changed(self, text):
        # 保持原有代码不变...
        pass
            
    def set_current_node(self, node):
        # 保持原有代码不变...
        pass
            
    def delete_current_node(self):
        # 保持原有代码不变...
        pass
            
    def set_graph(self, graph):
        """设置关联的节点图，监听节点选择变化"""
        if self.graph:
            try:
                self.graph.node_selected.disconnect(self.set_current_node)
                # 修改：使用 nodes_deleted 信号
                self.graph.nodes_deleted.disconnect(self._on_nodes_deleted)
            except TypeError:
                pass
                
        self.graph = graph
        
        if graph:
            graph.node_selected.connect(self.set_current_node)
            # 修改：连接 nodes_deleted 信号
            graph.nodes_deleted.connect(self._on_nodes_deleted)
            
    def _on_nodes_deleted(self, node_ids):
        """处理节点删除事件，更新面板状态"""
        if self.current_node and self.current_node.id in node_ids:
            self.set_current_node(None)