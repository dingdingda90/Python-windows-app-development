import os
import json
from PySide6.QtWidgets import QFileDialog, QMessageBox

class FileOperations:
    """文件操作处理器"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        
    def save_graph(self):
        """保存节点图到文件"""
        file_path, _ = QFileDialog.getSaveFileName(
            self.main_window, "保存节点图", "", "JSON Files (*.json);;All Files (*)"
        )
        
        if not file_path:
            return
            
        try:
            graph_data = self.main_window.graph.model.to_dict()
            
            if not file_path.endswith('.json'):
                file_path += '.json'
                
            with open(file_path, 'w') as f:
                json.dump(graph_data, f, indent=4)
                
            QMessageBox.information(self.main_window, "保存成功", f"节点图已保存到:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self.main_window, "保存失败", f"保存节点图时出错:\n{str(e)}")
    
    def load_graph(self):
        """从文件加载节点图"""
        file_path, _ = QFileDialog.getOpenFileName(
            self.main_window, "加载节点图", "", "JSON Files (*.json);;All Files (*)"
        )
        
        if not file_path:
            return
            
        try:
            self.main_window.graph.clear_graph()
            
            with open(file_path, 'r') as f:
                graph_data = json.load(f)
                
            self.main_window.graph.model.from_dict(graph_data)
            
            QMessageBox.information(self.main_window, "加载成功", f"已从以下位置加载节点图:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self.main_window, "加载失败", f"加载节点图时出错:\n{str(e)}")