from PySide6.QtCore import Qt, QPoint, QMimeData, QPointF
from PySide6.QtGui import QDrag, QPixmap, QPainter, QPen, QBrush, QColor
from PySide6.QtWidgets import QGraphicsRectItem, QGraphicsTextItem

class DragDropHandler:
    """拖拽操作处理器（整合视口版）"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        self.preview_item = None
        self.viewer = main_window.graph_view._get_viewer()
        self.viewport = self.viewer.viewport()  # 获取视口
        
        # 设置视口接收拖拽事件（关键修改）
        self.viewport.setAcceptDrops(True)
        self.viewport.dragEnterEvent = self.drag_enter_event
        self.viewport.dragMoveEvent = self.drag_move_event
        self.viewport.dropEvent = self.drop_event
        self.viewport.dragLeaveEvent = self.drag_leave_event
    
    def start_drag(self, widget, node_type):
        """启动节点拖拽"""
        drag = QDrag(widget)
        mime_data = QMimeData()
        mime_data.setText(node_type)
        drag.setMimeData(mime_data)
        
        # 创建拖拽图标
        pixmap = self._create_drag_pixmap(node_type, widget)
        drag.setPixmap(pixmap)
        drag.setHotSpot(QPoint(pixmap.width()//2, pixmap.height()//2))
        drag.exec(Qt.CopyAction)
    
    def _create_drag_pixmap(self, node_type, widget):
        """创建拖拽时的可视化图标"""
        text = node_type.split(".")[-1]
        font_metrics = widget.fontMetrics()
        text_w = font_metrics.horizontalAdvance(text)
        text_h = font_metrics.height()
        
        pixmap = QPixmap(text_w + 20, text_h + 12)
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QBrush(QColor(100, 149, 237)))
        painter.setPen(QPen(QColor(70, 130, 180), 2))
        painter.drawRoundedRect(0, 0, pixmap.width(), pixmap.height(), 8, 8)
        painter.setPen(Qt.white)
        painter.drawText(pixmap.rect(), Qt.AlignCenter, text)
        painter.end()
        return pixmap
    
    def drag_enter_event(self, event):
        """处理拖拽进入事件"""
        print("DragDropHandler: dragEnterEvent (viewport)")
        if event.mimeData().hasText():
            event.acceptProposedAction()
        else:
            event.ignore()

    def drag_move_event(self, event):
        """处理拖拽移动事件"""
        print("DragDropHandler: dragMoveEvent (viewport) - pos:", event.pos())
        if event.mimeData().hasText():
            event.setAccepted(True)  # 始终接受，确保整个视口都能拖拽
            self._update_preview(event)
        else:
            event.setAccepted(False)
    
    def drop_event(self, event):
        """处理放置事件"""
        print("DragDropHandler: dropEvent (viewport)")
        if not event.mimeData().hasText():
            return
            
        node_type = event.mimeData().text()
        pos = event.pos()  # 视口坐标（关键修改）
        
        # 将视口坐标转换为场景坐标（关键修改）
        scene_pos = self.viewer.mapToScene(pos)
        
        # 创建节点（无论位置是否在场景范围内）
        self.main_window.add_node_at_position(node_type, scene_pos.x(), scene_pos.y())
        event.setAccepted(True)

    def drag_leave_event(self, event):
        """处理拖拽移出事件"""
        print("DragDropHandler: dragLeaveEvent (viewport)")
        self._clear_preview()
    
    def _update_preview(self, event):
        """更新拖拽预览项（使用视口坐标）"""
        scene = self.main_window.graph_view.scene()
        if not scene:
            return
            
        # 将视口坐标转换为场景坐标（关键修改）
        scene_pos = self.viewer.mapToScene(event.pos())
        
        # 清理旧预览
        if self.preview_item and self.preview_item.scene() == scene:
            scene.removeItem(self.preview_item)
        
        # 创建新预览（无论位置是否在场景范围内）
        self.preview_item = QGraphicsRectItem(
            scene_pos.x() - 40, scene_pos.y() - 20, 80, 40
        )
        self.preview_item.setBrush(QBrush(QColor(100, 149, 237, 100)))
        self.preview_item.setPen(QPen(QColor(70, 130, 180), 2, Qt.DashLine))
        
        text_item = QGraphicsTextItem("Preview", self.preview_item)
        text_item.setDefaultTextColor(Qt.white)
        text_item.setPos(10, 10)
        scene.addItem(self.preview_item)
    
    def _clear_preview(self):
        """清除预览项"""
        if self.preview_item and self.preview_item.scene():
            self.preview_item.scene().removeItem(self.preview_item)
            self.preview_item = None