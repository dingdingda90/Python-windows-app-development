from PySide6.QtWidgets import QMenu, QMessageBox
from PySide6.QtGui import QAction, QKeySequence

class MenuBuilder:
    """菜单栏构建器"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        self.setup_menu_bar()
    
    def setup_menu_bar(self):
        menubar = self.main_window.menuBar()
        
        # 文件菜单
        file_menu = menubar.addMenu('文件')
        self.setup_file_menu(file_menu)
        
        # 编辑菜单
        edit_menu = menubar.addMenu('编辑')
        self.setup_edit_menu(edit_menu)
        
        # 布局菜单
        layout_menu = menubar.addMenu('布局')
        self.setup_layout_menu(layout_menu)
    
    def setup_file_menu(self, menu):
        save_action = QAction('保存', self.main_window)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self.main_window.save_graph)
        menu.addAction(save_action)
        
        load_action = QAction('加载', self.main_window)
        load_action.setShortcut(QKeySequence.Open)
        load_action.triggered.connect(self.main_window.load_graph)
        menu.addAction(load_action)
        
        menu.addSeparator()
        
        exit_action = QAction('退出', self.main_window)
        exit_action.setShortcut(QKeySequence.Quit)
        exit_action.triggered.connect(self.main_window.close)
        menu.addAction(exit_action)
    
    def setup_edit_menu(self, menu):
        undo_action = QAction('撤销', self.main_window)
        undo_action.setShortcut(QKeySequence.Undo)
        undo_action.triggered.connect(self.main_window.undo)
        undo_action.setEnabled(self.main_window.can_undo())
        menu.addAction(undo_action)
        
        redo_action = QAction('重做', self.main_window)
        redo_action.setShortcut(QKeySequence.Redo)
        redo_action.triggered.connect(self.main_window.redo)
        redo_action.setEnabled(self.main_window.can_redo())
        menu.addAction(redo_action)
        
        menu.addSeparator()
        
        delete_action = QAction('删除选中节点', self.main_window)
        delete_action.setShortcut(QKeySequence.Delete)
        delete_action.triggered.connect(self.main_window.delete_selected_nodes)
        menu.addAction(delete_action)
        
        duplicate_action = QAction('复制选中节点', self.main_window)
        duplicate_action.setShortcut(QKeySequence.Copy)
        duplicate_action.triggered.connect(self.main_window.duplicate_selected_nodes)
        menu.addAction(duplicate_action)
    
    def setup_layout_menu(self, menu):
        auto_layout_action = QAction('自动整理节点', self.main_window)
        auto_layout_action.triggered.connect(self.main_window.auto_layout_nodes)
        menu.addAction(auto_layout_action)