from PySide6.QtWidgets import QMenu, QMessageBox
from PySide6.QtGui import QAction

class ContextMenuHandler:
    """右键菜单处理器"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        
    def show_context_menu(self, pos):
        """显示右键菜单"""
        selected_nodes = self.main_window.graph.selected_nodes()
        menu = QMenu(self.main_window)
        
        if selected_nodes:
            self.setup_node_context_menu(menu, selected_nodes)
        else:
            self.setup_canvas_context_menu(menu)
        
        menu.exec(self.main_window.graph_widget.mapToGlobal(pos))
    
    def setup_node_context_menu(self, menu, selected_nodes):
        """设置节点右键菜单"""
        delete_action = QAction("删除节点", self.main_window)
        delete_action.triggered.connect(self.main_window.delete_selected_nodes)
        menu.addAction(delete_action)
        
        duplicate_action = QAction("复制节点", self.main_window)
        duplicate_action.triggered.connect(self.main_window.duplicate_selected_nodes)
        menu.addAction(duplicate_action)
        
        menu.addSeparator()
        
        properties_action = QAction("节点属性", self.main_window)
        properties_action.triggered.connect(self.main_window.show_node_properties)
        menu.addAction(properties_action)
    
    def setup_canvas_context_menu(self, menu):
        """设置画布右键菜单"""
        undo_action = QAction("撤销", self.main_window)
        undo_action.triggered.connect(self.main_window.undo)
        undo_action.setEnabled(self.main_window.can_undo())
        menu.addAction(undo_action)
        
        redo_action = QAction("重做", self.main_window)
        redo_action.triggered.connect(self.main_window.redo)
        redo_action.setEnabled(self.main_window.can_redo())
        menu.addAction(redo_action)
        
        menu.addSeparator()
        
        auto_layout_action = QAction("自动整理所有节点", self.main_window)
        auto_layout_action.triggered.connect(self.main_window.auto_layout_nodes)
        menu.addAction(auto_layout_action)
        
        menu.addSeparator()
        
        clear_action = QAction("清空画布", self.main_window)
        clear_action.triggered.connect(self.main_window.clear_canvas)
        menu.addAction(clear_action)
        
        menu.addSeparator()
        
        add_my_node_action = QAction("添加 My Node", self.main_window)
        add_my_node_action.triggered.connect(lambda: self.main_window.add_node_at_center("My Node"))
        menu.addAction(add_my_node_action)
        
        add_math_node_action = QAction("添加 Math Node", self.main_window)
        add_math_node_action.triggered.connect(lambda: self.main_window.add_node_at_center("Math Node"))
        menu.addAction(add_math_node_action)