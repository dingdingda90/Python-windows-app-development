from PySide6.QtCore import QObject, QEvent
from PySide6.QtGui import QDropEvent, QDragEnterEvent, QDragMoveEvent

class DragDropEventFilter(QObject):
    def __init__(self, drag_drop_handler, parent=None):
        super().__init__(parent)
        self.drag_drop_handler = drag_drop_handler

    def eventFilter(self, obj, event):
        #print({event.type()})
        if event.type() == QEvent.Type.DragEnter:
            print("eventFilter: dragEnterEvent")
            self.drag_drop_handler.drag_enter_event(event)
            return True

        elif event.type() == QEvent.Type.DragMove:
            print("eventFilter: dragMoveEvent")
            pos = event.pos()  # 鼠标在目标控件中的局部坐标
            if obj.rect().contains(pos):
                print("鼠标在画布区域，dragMoveEvent被触发")     

            self.drag_drop_handler.drag_move_event(event)
            return True

        elif event.type() == QEvent.Type.Drop:
            print("eventFilter: dropEvent")
            self.drag_drop_handler.drop_event(event)
            return True
        
        elif event.type() == QEvent.Type.DragLeave:
            print("\n===== 拖拽离开事件 =====")
            print("QGraphicsView: dragLeaveEvent")
            self.drag_drop_handler.drag_leave_event(event)
            return True       
        return super().eventFilter(obj, event)