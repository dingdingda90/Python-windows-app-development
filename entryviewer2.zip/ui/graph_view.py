from PySide6.QtCore import Qt, QPointF, QRectF, QEvent, QTimer, Signal, QPropertyAnimation, QEasingCurve
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGraphicsView,
                              QLabel, QToolBar, QSlider, QApplication, QGraphicsRectItem)
from PySide6.QtGui import QAction, QTransform, QPen, QColor, QBrush, QPalette, QPainter
from NodeGraphQt import NodeGraph, BaseNode

class GraphView(QGraphicsView):
    """节点图视图组件，支持平滑缩放和自定义滚动条，解决拖拽问题"""
    
    zoom_changed = Signal(float)  # 缩放变化信号
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # 缩放设置
        self._min_zoom = 0.5       # 最小缩放系数(10%)
        self._max_zoom = 1.5       # 最大缩放系数(200%)
        self._current_zoom = 1.0   # 当前缩放系数(100%)
        self._zoom_step = 0.1      # 缩放步长(10%)
        
        # 动画设置
        self._is_animating = False  # 动画状态标志
        self._target_zoom = 1.0     # 目标缩放值
        self._animation_duration = 200  # 动画持续时间(毫秒)
        
        # 画布设置
        self.margin = 500          # 画布边距
        self.auto_resize_enabled = True
        self.resize_delay = 100    # 调整延迟(毫秒)
        self.aspect_ratio = 1.0    # 画布宽高比
        
        # 平移设置
        self._is_panning = False   # 是否正在平移
        self._pan_start = QPointF() # 平移起始点
        
        # 网格线设置
        self._grid_size = 20       # 网格大小
        self._grid_color = QColor(200, 200, 200)  # 网格线颜色
        self._grid_thickness = 1   # 网格线粗细
        
        # 缩放中心
        self._zoom_center = QPointF()  # 当前缩放中心
        
        self.setup_ui()
        
        # 确保视图接受拖放事件
        self.setAcceptDrops(True)
        self._setup_nodegraph_drag_drop()
        
        # 初始化画布
        self._update_canvas_size()

        self.setDragMode(QGraphicsView.NoDrag)  # 关键：禁用视图自身的拖拽模式
        
        # 确保NodeGraphQt视图获得焦点
        self.setFocusPolicy(Qt.StrongFocus)
        self.graph_widget.setFocusPolicy(Qt.StrongFocus)
    
    def setup_ui(self):
        # 主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 创建顶部工具栏
        self.create_toolbar()
        main_layout.addWidget(self.toolbar)
        
        # 创建节点图
        self.graph = NodeGraph()
        self.graph_widget = self.graph.widget
        
        # 获取底层QGraphicsView（NodeGraphQt的视图）
        self.nodegraph_viewer = self._get_viewer()
        if self.nodegraph_viewer:
            self.nodegraph_viewer.setAcceptDrops(True)
            self.nodegraph_viewer.setDragMode(QGraphicsView.NoDrag)  # 禁用NodeGraphQt的拖拽模式
            self.nodegraph_viewer.setRenderHint(QPainter.Antialiasing)  # 提高渲染质量
        
        # 初始缩放
        self.set_viewer_zoom(self._current_zoom)
        
        main_layout.addWidget(self.graph_widget)
        
        # 安装事件过滤器
        if self.parent():
            self.parent().installEventFilter(self)
        
        # 确保NodeGraphQt视图获得初始焦点
        self.graph_widget.setFocus()
    
    def _get_viewer(self):
        """安全获取NodeGraphQt的QGraphicsView实例"""
        if hasattr(self.graph, 'widget'):
            graph_widget = self.graph.widget
            for child in graph_widget.findChildren(QGraphicsView):
                if isinstance(child, QGraphicsView):
                    return child
        return None
    
    def _setup_nodegraph_drag_drop(self):
        """设置NodeGraphQt的拖放功能"""
        if self.graph_widget:
            self.graph_widget.setAcceptDrops(True)
            self.graph_widget.installEventFilter(self)  # 安装事件过滤器以转发事件
    
    def create_toolbar(self):
        """创建顶部工具栏"""
        self.toolbar = QToolBar("工具栏", self)
        self.toolbar.setMovable(False)
        
        # 缩放百分比标签
        self.zoom_label = QLabel("缩放: 100%")
        self.zoom_label.setAlignment(Qt.AlignCenter)
        self.zoom_label.setMinimumWidth(100)
        
        # 缩放控制按钮
        zoom_out_action = QAction("缩小", self)
        zoom_out_action.triggered.connect(lambda: self.change_zoom(-self._zoom_step, use_mouse_center=False))
        
        zoom_in_action = QAction("放大", self)
        zoom_in_action.triggered.connect(lambda: self.change_zoom(self._zoom_step, use_mouse_center=False))
        
        reset_zoom_action = QAction("重置", self)
        reset_zoom_action.triggered.connect(self.reset_zoom)
        
        # 添加到工具栏
        self.toolbar.addAction(zoom_out_action)
        self.toolbar.addWidget(self.zoom_label)
        self.toolbar.addAction(zoom_in_action)
        self.toolbar.addAction(reset_zoom_action)
        
        # 连接缩放信号到标签更新
        self.zoom_changed.connect(self.update_zoom_label)
        self.update_zoom_label(self._current_zoom)
    
    def update_zoom_label(self, zoom):
        """更新缩放百分比标签"""
        self.zoom_label.setText(f"缩放: {zoom*100:.0f}%")
    
    def change_zoom(self, delta, use_mouse_center=True):
        """按增量改变缩放比例"""
        if self._is_animating:
            self._stop_animation()
            
        new_zoom = self._current_zoom + delta
        
        # 确定缩放中心
        if use_mouse_center and self.nodegraph_viewer:
            mouse_pos = self.nodegraph_viewer.mapFromGlobal(self.cursor().pos())
            self._zoom_center = self.nodegraph_viewer.mapToScene(mouse_pos)
        else:
            if self.nodegraph_viewer:
                view_rect = self.nodegraph_viewer.viewport().rect()
                center_pos = QPointF(view_rect.width() / 2, view_rect.height() / 2)
                self._zoom_center = self.nodegraph_viewer.mapToScene(center_pos.toPoint())
        
        self._start_zoom_animation(new_zoom)
    
    def _start_zoom_animation(self, target_zoom):
        """开始缩放动画"""
        self._target_zoom = max(self._min_zoom, min(target_zoom, self._max_zoom))
        
        if abs(self._target_zoom - self._current_zoom) < 0.001:
            return
            
        self._is_animating = True
        self._animation_start_time = QTimer.currentMonotonicTime() 
        self._animation_timer = QTimer(self)
        self._animation_timer.timeout.connect(self._update_zoom_animation)
        self._animation_timer.start(16)
    
    def _update_zoom_animation(self):
        """更新缩放动画"""
        elapsed = QTimer.currentTime() - self._animation_start_time
        progress = min(1.0, elapsed / self._animation_duration)
        eased_progress = QEasingCurve(QEasingCurve.InOutQuad).valueForProgress(progress)
        
        current_zoom = self._current_zoom + (self._target_zoom - self._current_zoom) * eased_progress
        self._apply_zoom(current_zoom)
        
        if progress >= 1.0:
            self._stop_animation()
    
    def _stop_animation(self):
        """停止缩放动画"""
        if hasattr(self, '_animation_timer'):
            self._animation_timer.stop()
            del self._animation_timer
        
        self._apply_zoom(self._target_zoom)
        self._is_animating = False
    
    def _apply_zoom(self, zoom):
        """应用缩放值"""
        scale_factor = zoom / self._current_zoom
        
        if self.nodegraph_viewer:
            self.nodegraph_viewer.setTransform(QTransform().scale(scale_factor, scale_factor), True)
            new_center = self._zoom_center - (self._zoom_center * scale_factor) + self._zoom_center
            self.nodegraph_viewer.centerOn(new_center)
        
        self._current_zoom = zoom
        self.zoom_changed.emit(self._current_zoom)
        self._schedule_canvas_update()
    
    def _schedule_canvas_update(self):
        """延迟更新画布，提升性能"""
        QTimer.singleShot(self.resize_delay, self._update_canvas_size)
    
    def _handle_zoom(self, event, use_mouse_center=True):
        """处理缩放事件"""
        delta = event.angleDelta().y()
        if delta > 0:
            self.change_zoom(self._zoom_step, use_mouse_center)
        else:
            self.change_zoom(-self._zoom_step, use_mouse_center)
    
    def mousePressEvent(self, event):
        """处理鼠标按下事件 - 转发给NodeGraphQt"""
        # 确保NodeGraphQt视图获得焦点
        self.graph_widget.setFocus()
        
        # 转发事件给NodeGraphQt的widget
        if self.graph_widget and self.graph_widget.rect().contains(event.pos()):
            # 将事件坐标转换为NodeGraphQt视图的坐标
            pos_in_graph = event.pos() - self.graph_widget.pos()
            new_event = QMouseEvent(
                event.type(), 
                pos_in_graph, 
                event.button(), 
                event.buttons(), 
                event.modifiers()
            )
            self.graph_widget.mousePressEvent(new_event)
        
        if event.button() == Qt.MiddleButton:  # 中键开始平移
            self._is_panning = True
            self._pan_start = event.pos()
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()
        else:
            super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        """处理鼠标移动事件 - 转发给NodeGraphQt"""
        # 转发事件给NodeGraphQt的widget
        if self.graph_widget and self.graph_widget.rect().contains(event.pos()):
            # 将事件坐标转换为NodeGraphQt视图的坐标
            pos_in_graph = event.pos() - self.graph_widget.pos()
            new_event = QMouseEvent(
                event.type(), 
                pos_in_graph, 
                Qt.NoButton,  # 移动事件没有按钮状态
                event.buttons(), 
                event.modifiers()
            )
            self.graph_widget.mouseMoveEvent(new_event)
        
        if self._is_panning:
            delta = event.pos() - self._pan_start
            self._pan_start = event.pos()
            
            if self.nodegraph_viewer:
                self.nodegraph_viewer.translate(delta.x(), delta.y())
            event.accept()
        else:
            super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        """处理鼠标释放事件 - 转发给NodeGraphQt"""
        # 转发事件给NodeGraphQt的widget
        if self.graph_widget and self.graph_widget.rect().contains(event.pos()):
            # 将事件坐标转换为NodeGraphQt视图的坐标
            pos_in_graph = event.pos() - self.graph_widget.pos()
            new_event = QMouseEvent(
                event.type(), 
                pos_in_graph, 
                event.button(), 
                event.buttons(), 
                event.modifiers()
            )
            self.graph_widget.mouseReleaseEvent(new_event)
        
        if event.button() == Qt.MiddleButton and self._is_panning:
            self._is_panning = False
            self.setCursor(Qt.ArrowCursor)
            event.accept()
        else:
            super().mouseReleaseEvent(event)
    
    def wheelEvent(self, event):
        """处理滚轮事件 - 转发缩放和平移事件"""
        if event.modifiers() & Qt.ControlModifier:
            self._handle_zoom(event, use_mouse_center=True)
            event.accept()
        else:
            self._handle_pan(event)
            event.accept()
    
    def _handle_pan(self, event):
        """处理平移事件"""
        if self.nodegraph_viewer:
            self.nodegraph_viewer.verticalScrollBar().setValue(
                self.nodegraph_viewer.verticalScrollBar().value() - event.angleDelta().y() // 8
            )
    
    def set_viewer_zoom(self, zoom_factor, use_mouse_center=True):
        """直接设置视图缩放"""
        zoom_factor = max(self._min_zoom, min(zoom_factor, self._max_zoom))
        
        if self._is_animating:
            self._stop_animation()
        
        if use_mouse_center and self.nodegraph_viewer:
            mouse_pos = self.nodegraph_viewer.mapFromGlobal(self.cursor().pos())
            self._zoom_center = self.nodegraph_viewer.mapToScene(mouse_pos)
        else:
            if self.nodegraph_viewer:
                view_rect = self.nodegraph_viewer.viewport().rect()
                center_pos = QPointF(view_rect.width() / 2, view_rect.height() / 2)
                self._zoom_center = self.nodegraph_viewer.mapToScene(center_pos.toPoint())
        
        self._apply_zoom(zoom_factor)
    
    def reset_zoom(self):
        """重置缩放到1.0并居中画布"""
        if self._is_animating:
            self._stop_animation()
        
        self._current_zoom = 1.0
        self.zoom_changed.emit(self._current_zoom)
        self.update_zoom_label(self._current_zoom)
        
        self._center_view_on_scene()
        self._update_canvas_size()
    
    def _center_view_on_scene(self):
        scene = self.graph.scene()
        if not scene or not self.nodegraph_viewer:
            return
            
        scene_rect = scene.sceneRect()
        if scene_rect.isEmpty():
            self.nodegraph_viewer.centerOn(QPointF(0, 0))
        else:
            self.nodegraph_viewer.centerOn(scene_rect.center())
    
    def _update_canvas_size(self):
        """更新画布大小并保持比例"""
        if not self.auto_resize_enabled or not self.parent() or not hasattr(self.graph, 'scene'):
            return
            
        window = self.parent()
        if not window:
            return
            
        window_width = window.width() * self._current_zoom
        window_height = window_width / self.aspect_ratio
        
        new_width = window_width + self.margin * 2
        new_height = window_height + self.margin * 2
        
        scene = self.graph.scene()
        if scene:
            scene.setSceneRect(QRectF(0, 0, new_width, new_height))
            self._center_view_on_scene()
    
    def register_nodes(self, node_classes):
        """注册节点类"""
        for node_class in node_classes:
            self.graph.register_node(node_class)
    
    def eventFilter(self, watched, event):
        """事件过滤器，转发事件给NodeGraphQt"""
        # 转发拖放事件给NodeGraphQt的widget
        if watched == self.graph_widget:
            if event.type() in (QEvent.DragEnter, QEvent.DragMove, QEvent.Drop):
                self.graph_widget.event(event)
                return True
        return super().eventFilter(watched, event)