from PySide6.QtWidgets import QMessageBox
from nodes.registry import get_node_class

class NodeOperations:
    """节点操作处理器"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        # 确保main_window包含graph属性
        assert hasattr(main_window, 'graph'), "Main window must have a 'graph' attribute"
    def delete_selected_nodes(self):
        """删除选中的节点"""
        selected_nodes = self.main_window.graph.selected_nodes()
        if not selected_nodes:
            return
            
        for node in selected_nodes:
            self.main_window.graph.remove_node(node)
            
    def duplicate_selected_nodes(self):
        """复制选中的节点"""
        selected_nodes = self.main_window.graph.selected_nodes()
        if not selected_nodes:
            return
            
        for node in selected_nodes:
            node_type = node.type_
            node_name = node.name() + " (Copy)"
            
            new_node = self.create_node_by_type(node_type, node_name)
            
            if new_node:
                center_pos = self.main_window.get_graph_center()
                new_node.set_pos(center_pos.x(), center_pos.y())
                
                for prop_name in node.properties().keys():
                    if prop_name not in ['name', 'id', 'pos']:
                        new_node.set_property(prop_name, node.get_property(prop_name))
        
        self.main_window.graph.clear_selection()
        for node in selected_nodes:
            node_name = node.name() + " (Copy)"
            new_node = self.main_window.graph.get_node_by_name(node_name)
            if new_node:
                new_node.set_selected(True)
    
    def create_node_by_type(self, node_type, node_name=None):
        """根据节点类型创建节点"""
        node_class = get_node_class(node_type)
        if not node_class:
            return None
            
        node_name = node_name or node_class.NODE_NAME
        node_id = f"{node_class.__identifier__}.{node_class.NODE_NAME}"
        
        # 从main_window.graph创建节点
        new_node = self.main_window.graph.create_node(node_id, name=node_name)
        return new_node
    
    def add_node_at_position(self, node_type, x, y):
        """在指定位置添加节点"""
        node = self.create_node_by_type(node_type, None)
        
        if node:
            node.set_pos(x, y)
            self.main_window.graph.clear_selection()
            node.set_selected(True)
            
    def add_node_at_center(self, node_type):
        """在中心位置添加节点"""
        center_pos = self.main_window.get_graph_center()
        self.add_node_at_position(node_type, center_pos.x(), center_pos.y())
    
    def clear_canvas(self):
        """清空画布"""
        reply = QMessageBox.question(self.main_window, '确认', '确定要清空画布吗？',
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.main_window.graph.clear_graph()