import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QLabel, QListWidget, QFrame, QTabWidget
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QAction, QKeySequence

# 导入 UI 组件
from ui.node_list import DraggableNodeList
from ui.properties_panel import NodePropertiesPanel
from ui.menu_builder import MenuBuilder
from ui.graph_view import GraphView
from ui.drag_drop import DragDropHandler
from ui.context_menu import ContextMenuHandler
from ui.file_operations import FileOperations
from ui.node_operations import NodeOperations
from ui.dragevent_filter import DragDropEventFilter
# 导入节点注册系统
from nodes.registry import scan_and_register_nodes, get_all_node_types, get_node_class


class NodeEditorWindow(QMainWindow):
    """节点编辑器主窗口"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("节点编辑器")
        self.resize(1400, 800)  # 扩大窗口，给右侧留出空间

        # 初始化组件
        self.init_components()
        self.setup_ui()
        self.connect_signals()

    def init_components(self):
        """初始化所有组件"""
        self.graph_view = GraphView()  # 画布组件
        self.graph = self.graph_view.graph  # 暴露 graph 给主窗口

        self.drag_drop_handler = DragDropHandler(self)

        # 假设 self.drag_drop_handler 是你已有的对象实例
        # 给 graph_view.graph_widget 安装事件过滤器
        # （确认 graph_widget 是你显示的、可接收拖放的目标控件）
        self.event_filter = DragDropEventFilter(self.drag_drop_handler)
        self.graph_view.graph_widget.installEventFilter(self.event_filter)
        self.graph_view.graph_widget.setAcceptDrops(True)   


        self.node_list = DraggableNodeList(drag_drop_handler=self.drag_drop_handler)  # 左侧节点列表
        self.properties_panel = NodePropertiesPanel()  # 属性面板（可保留，也可替换）

        # 右侧组件：上部分图片框、下部分列表
        self.right_top_frame = QFrame()  # 模拟图片框，可替换为 QLabel 加载图片
        self.right_top_frame.setStyleSheet("background-color: lightgray;")  # 占位样式
        self.right_bottom_list = QListWidget()  # 右侧下部分列表

        # 初始化处理器
        self.menu_builder = MenuBuilder(self)
        self.context_menu_handler = ContextMenuHandler(self)
        self.file_operations = FileOperations(self)
        self.node_operations = NodeOperations(self)

        # 自动扫描并注册所有节点
        scan_and_register_nodes("nodes")

        # 获取所有已注册的节点类型
        node_types = get_all_node_types()

        # 注册节点到图形系统
        for node_type in node_types:
            node_class = get_node_class(node_type)
            if node_class:
                self.graph_view.register_nodes([node_class])

        # 初始化节点列表
        for node_type in node_types:
            self.node_list.addItem(node_type)

        # 测试：列出所有已注册的节点类型
        registered_types = self.graph.registered_nodes()
        print("NodeGraphQt 已注册的节点类型:")
        for node_type in registered_types:
            print(f"  - {node_type}")

        # 设置属性面板（若不需要可移除，或放到其他位置）
        self.properties_panel.set_graph(self.graph_view.graph)

        # 复制相关变量
        self.ctrl_pressed = False
        self.dragging_node = None

    def setup_ui(self):
        """设置 UI 布局：左、中、右三栏，右侧拆分为上下"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)

        # --------------------- 1. 创建主分割器（左、中、右） ---------------------
        main_splitter = QSplitter(Qt.Horizontal)

        # --------------------- 2. 左侧区域：节点库 ---------------------
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.addWidget(QLabel("节点库", alignment=Qt.AlignCenter))  # 标题
        left_layout.addWidget(self.node_list)
        main_splitter.addWidget(left_widget)

        # --------------------- 3. 中间区域：画布 ---------------------
        middle_widget = QWidget()
        middle_layout = QVBoxLayout(middle_widget)
        middle_layout.addWidget(self.graph_view)
        main_splitter.addWidget(middle_widget)

        # --------------------- 4. 右侧区域：拆分为上下 ---------------------
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)

        # 右侧上部分：图片框（示例）
        right_top_layout = QVBoxLayout()
        right_top_layout.addWidget(QLabel("图片预览", alignment=Qt.AlignCenter))  # 标题
        right_top_layout.addWidget(self.right_top_frame)
        right_widget_top = QWidget()
        right_widget_top.setLayout(right_top_layout)

        # 右侧下部分：列表（示例）
        right_bottom_layout = QVBoxLayout()
        right_bottom_layout.addWidget(QLabel("右侧列表", alignment=Qt.AlignCenter))  # 标题
        right_bottom_layout.addWidget(self.right_bottom_list)
        right_widget_bottom = QWidget()
        right_widget_bottom.setLayout(right_bottom_layout)

        # 将右侧上下部分加入垂直布局
        right_layout.addWidget(right_widget_top, stretch=1)
        right_layout.addWidget(right_widget_bottom, stretch=1)

        main_splitter.addWidget(right_widget)

        # 设置分割器初始大小（宽度比例）
        main_splitter.setSizes([200, 600, 400])

        main_layout.addWidget(main_splitter)

        # ✅ 允许 graph_widget 接受拖拽
        self.graph_view.graph_widget.setAcceptDrops(True)

        # --------------------- 5. 连接事件（保持原有逻辑） ---------------------
        # 连接拖拽事件
        self.graph_view.graph_widget.dragEnterEvent = self.drag_drop_handler.drag_enter_event
        self.graph_view.graph_widget.dragMoveEvent = self.drag_drop_handler.drag_move_event
        self.graph_view.graph_widget.dropEvent = self.drag_drop_handler.drop_event
        self.graph_view.graph_widget.dragLeaveEvent = self.drag_drop_handler.drag_leave_event
        # 连接右键菜单事件
        self.graph_view.graph_widget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.graph_view.graph_widget.customContextMenuRequested.connect(
            self.context_menu_handler.show_context_menu
        )

        # 连接键盘事件
        self.graph_view.graph_widget.keyPressEvent = self.key_press_event
        self.graph_view.graph_widget.keyReleaseEvent = self.key_release_event

        # 连接鼠标事件
        self.graph_view.graph_widget.mousePressEvent = self.mouse_press_event
        self.graph_view.graph_widget.mouseReleaseEvent = self.mouse_release_event

    def connect_signals(self):
        """连接信号和槽"""
        # 连接节点列表双击事件
        self.node_list.itemDoubleClicked.connect(self.add_node_from_list)

    # --------------------- 以下为原有事件处理逻辑 ---------------------
    def key_press_event(self, event):
        """处理键盘按下事件"""
        if event.key() == Qt.Key_Control:
            self.ctrl_pressed = True

        super(type(self.graph_view.graph_widget), self.graph_view.graph_widget).keyPressEvent(event)

    def key_release_event(self, event):
        """处理键盘释放事件"""
        if event.key() == Qt.Key_Control:
            self.ctrl_pressed = False

        super(type(self.graph_view.graph_widget), self.graph_view.graph_widget).keyReleaseEvent(event)

    def mouse_press_event(self, event):
        """处理鼠标按下事件"""
        # 调用父类实现（仅需一次）
        super().mousePressEvent(event)
        
        if event.button() == Qt.LeftButton:
            # 获取视图组件并转换坐标
            viewer = self.graph_view._get_viewer()
            if not viewer:
                return
                
            # 将视图坐标转换为场景坐标
            view_pos = event.position().toPoint()
            scene_pos = viewer.mapToScene(view_pos)

            # 获取场景中的项目
            scene = viewer.scene()
            items = scene.items(scene_pos)

            # 检查是否点击了节点
            self.dragging_node = None
            for item in items:
                if hasattr(item, 'node'):
                    self.dragging_node = item.node()
                    break
                
    def mouse_release_event(self, event):
        """处理鼠标释放事件"""
        # Ctrl+拖拽节点时，复制节点
        if self.ctrl_pressed and self.dragging_node and event.button() == Qt.LeftButton:
            node_type = self.dragging_node.type_
            node_name = self.dragging_node.name() + " (Copy)"

            new_node = self.node_operations.create_node_by_type(node_type, node_name)

            if new_node:
                center_pos = self.graph_view.get_graph_center()
                new_node.set_pos(center_pos.x(), center_pos.y())

                for prop_name in self.dragging_node.properties().keys():
                    if prop_name not in ['name', 'id', 'pos']:
                        new_node.set_property(prop_name, self.dragging_node.get_property(prop_name))

                self.graph_view.graph.clear_selection()
                new_node.set_selected(True)

        self.dragging_node = None
        super(type(self.graph_view.graph_widget), self.graph_view.graph_widget).mouseReleaseEvent(event)

    # --------------------- 以下为委托给处理器的方法 ---------------------
    def get_graph_center(self):
        """获取图形中心位置"""
        return self.graph_view.get_graph_center()

    def add_node_from_list(self, item):
        """从节点列表添加节点"""
        node_type = item.text()
        self.node_operations.add_node_at_center(node_type)

    def delete_selected_nodes(self):
        """删除选中的节点"""
        self.node_operations.delete_selected_nodes()

    def duplicate_selected_nodes(self):
        """复制选中的节点"""
        self.node_operations.duplicate_selected_nodes()

    def show_node_properties(self):
        """显示节点属性"""
        selected_nodes = self.graph_view.graph.selected_nodes()
        if selected_nodes:
            pass

    def clear_canvas(self):
        """清空画布"""
        self.node_operations.clear_canvas()

    def add_node_at_center(self, node_type):
        """在中心添加节点"""
        self.node_operations.add_node_at_center(node_type)

    def add_node_at_position(self, node_type, x, y):
        """在指定位置添加节点"""
        self.node_operations.add_node_at_position(node_type, x, y)

    def auto_layout_nodes(self):
        """自动布局节点"""
        nodes = self.graph_view.graph.all_nodes()
        if not nodes:
            return

        # 简单的网格布局算法
        node_count = len(nodes)
        cols = int(node_count ** 0.5) + 1
        spacing = 250

        for i, node in enumerate(nodes):
            row = i // cols
            col = i % cols
            node.set_pos(col * spacing, row * spacing)

    def save_graph(self):
        """保存图形"""
        self.file_operations.save_graph()

    def load_graph(self):
        """加载图形"""
        self.file_operations.load_graph()

    def can_undo(self):
        """检查是否可以撤销"""
        try:
            return self.graph_view.graph.can_undo()
        except AttributeError:
            return False

    def can_redo(self):
        """检查是否可以重做"""
        try:
            return self.graph_view.graph.can_redo()
        except AttributeError:
            return False

    def undo(self):
        """撤销操作"""
        try:
            self.graph_view.graph.undo()
        except AttributeError:
            pass

    def redo(self):
        """重做操作"""
        try:
            self.graph_view.graph.redo()
        except AttributeError:
            pass


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = NodeEditorWindow()
    window.show()
    sys.exit(app.exec())