def test_imports():
    import entryviewer
    import main

    # entryviewer should export MainWindow (existing package entry)
    assert hasattr(entryviewer, 'MainWindow')

    # main should provide a chooser for entrypoints
    assert callable(getattr(main, '_choose_entry', None))
