import time

from entryviewer.devices.mock_device import MockDevice


def test_mock_device_runs():
    d = MockDevice('unittest-mock', interval=0.05)
    d.connect()
    time.sleep(0.12)
    st = d.get_status()
    assert st.get('running') is True
    d.disconnect()
    st2 = d.get_status()
    assert st2.get('running') is False
