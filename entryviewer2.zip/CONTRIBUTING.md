# Contributing

Thank you for considering contributing to this project. The repository is
meant to be a template for upper-machine (上位机) development using PySide6.

How to contribute
- Fork the repository and open a pull request against `main`.
- Keep changes small and focused; provide a clear description of the problem
  and the proposed solution.

Code style
- Use Python 3.11+ features when helpful, keep code readable.
- Follow PEP8; run `flake8` before committing.
- Add type hints where reasonable and run `mypy` during CI.

Testing
- Add unit tests under `tests/` for new features and bug fixes.
- Use mock drivers (`entryviewer/devices/mock_device.py`) to avoid hardware
  dependency in tests.

Commits and PRs
- Write concise commit messages. Each PR should include a short description,
  testing steps, and any migration/compatibility notes.

License
- By contributing you agree your changes will be made available under the
  project's MIT License.
