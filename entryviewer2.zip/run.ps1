# Run EntryViewer (PowerShell)
# Installs runtime requirements listed in config/requirements.txt and runs main.py
python -m pip install -r .\config\requirements.txt
python .\main.py
