from NodeGraphQt import BaseNode
from .registry import register_node

@register_node("Math Node")
class MathNode(BaseNode):
    """数学运算节点"""
    
    __identifier__ = 'com.chantasticvfx.math'
    NODE_NAME = 'MathNode'
    
    def __init__(self):
        super(MathNode, self).__init__()
        self.add_input('input A')
        self.add_input('input B')
        self.add_output('output')
        
        # 创建运算选择下拉菜单
        self.add_combo_menu('operation', 
                           items=['Add', 'Subtract', 'Multiply', 'Divide'],
                           label='Operation')