from NodeGraphQt import BaseNode

class CustomNode(BaseNode):
    """自定义节点基类，所有自定义节点应继承此类"""
    
    def __init__(self):
        super().__init__()