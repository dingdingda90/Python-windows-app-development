from NodeGraphQt import BaseNode
from .registry import register_node

@register_node("My Node")
class MyNode(BaseNode):
    """自定义节点示例"""
    
    # 设置节点元数据
    __identifier__ = 'com.chantasticvfx'
    NODE_NAME = 'MyNode'
    
    def __init__(self):
        super(MyNode, self).__init__()
        self.create_property('test_prop', 'Hello World')
        self.add_input('in')
        self.add_output('out')