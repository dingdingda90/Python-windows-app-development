from .base_node import CustomNode
from .registry import register_node

@register_node("Text Node")
class TextNode(CustomNode):
    """文本节点类"""
    __identifier__ = 'com.chantasticvfx.text'
    NODE_NAME = 'TextNode'
    
    def __init__(self):
        super(TextNode, self).__init__()
        self.add_output('output')
        self.add_text_input('text', 'Text', tab='widgets')