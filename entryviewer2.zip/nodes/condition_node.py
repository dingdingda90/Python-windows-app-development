from .base_node import CustomNode
from .registry import register_node

@register_node("Condition Node")
class ConditionNode(CustomNode):
    """条件节点类"""
    __identifier__ = 'com.chantasticvfx.condition'
    NODE_NAME = 'ConditionNode'
    
    def __init__(self):
        super(ConditionNode, self).__init__()
        self.add_input('condition')
        self.add_output('true')
        self.add_output('false')
        self.add_text_input('condition_text', 'Condition', tab='widgets')