from .base_node import CustomNode
from .registry import register_node

@register_node("Image Node")
class ImageNode(CustomNode):
    """图像节点类"""
    __identifier__ = 'com.chantasticvfx.image'
    NODE_NAME = 'ImageNode'
    
    def __init__(self):
        super(ImageNode, self).__init__()
        self.add_output('output')
        self.add_text_input('image_path', 'Image Path', tab='widgets')