from .base_node import CustomNode
from .registry import register_node

@register_node("Color Node")
class ColorNode(CustomNode):
    """颜色节点类"""
    __identifier__ = 'com.chantasticvfx.color'
    NODE_NAME = 'ColorNode'
    
    def __init__(self):
        super(ColorNode, self).__init__()
        self.add_output('output')
        #self.add_color_picker('color', 'Color', tab='widgets')