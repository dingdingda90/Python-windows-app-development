from .base_node import CustomNode
from .registry import register_node

@register_node("Number Node")
class NumberNode(CustomNode):
    """数字节点类"""
    __identifier__ = 'com.chantasticvfx.number'
    NODE_NAME = 'NumberNode'
    
    def __init__(self):
        super(NumberNode, self).__init__()
        self.add_output('output')
        self.add_int_input('int_value', 'Integer', default=0, tab='widgets')
        self.add_float_input('float_value', 'Float', default=0.0, tab='widgets')