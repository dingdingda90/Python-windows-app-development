from .base_node import CustomNode
from .registry import register_node

@register_node("Function Node")
class FunctionNode(CustomNode):
    """函数节点类"""
    __identifier__ = 'com.chantasticvfx.function'
    NODE_NAME = 'FunctionNode'
    
    def __init__(self):
        super(FunctionNode, self).__init__()
        self.add_input('input')
        self.add_output('output')
        self.add_text_input('function', 'Function', tab='widgets')