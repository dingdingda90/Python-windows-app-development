from .base_node import CustomNode
from .registry import register_node

@register_node("List Node")
class ListNode(CustomNode):
    """列表节点类"""
    __identifier__ = 'com.chantasticvfx.list'
    NODE_NAME = 'ListNode'
    
    def __init__(self):
        super(ListNode, self).__init__()
        self.add_input('input')
        self.add_output('output')
        #self.add_list_widget('list', 'List', items=['item 1', 'item 2', 'item 3'], tab='widgets')