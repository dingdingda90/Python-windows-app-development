from .base_node import CustomNode
from .registry import register_node

@register_node("Logic Node")
class LogicNode(CustomNode):
    """逻辑节点类"""
    __identifier__ = 'com.chantasticvfx.logic'
    NODE_NAME = 'LogicNode'
    
    def __init__(self):
        super(LogicNode, self).__init__()
        self.add_input('input A')
        self.add_input('input B')
        self.add_output('output')
        self.add_combo_menu('logic', 'Logic', items=['AND', 'OR', 'NOT', 'XOR'])