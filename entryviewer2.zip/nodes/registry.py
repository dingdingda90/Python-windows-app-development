import os
import importlib
import inspect
from typing import Dict, Type, List, Any

# 存储节点类型与节点类的映射
NODE_REGISTRY: Dict[str, Type] = {}

def register_node(node_type: str):
    """节点注册装饰器"""
    def decorator(cls):
        # 存储节点类型作为类属性
        setattr(cls, '__node_type__', node_type)
        
        # 注册到全局注册表
        NODE_REGISTRY[node_type] = cls
        return cls
    return decorator

def get_node_class(node_type: str) -> Type:
    """根据节点类型获取节点类"""
    return NODE_REGISTRY.get(node_type)

def get_all_node_types() -> List[str]:
    """获取所有已注册的节点类型"""
    return list(NODE_REGISTRY.keys())

def scan_and_register_nodes(directory: str):
    """扫描目录并注册所有节点"""
    # 规范化目录路径
    directory = os.path.abspath(directory)
    
    # 确保目录存在
    if not os.path.exists(directory):
        print(f"警告: 节点目录不存在 - {directory}")
        return
    
    # 直接使用固定的包名 "nodes"
    package_name = "nodes"
    
    # 扫描目录下的所有Python文件
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.py') and not file.startswith('__'):
                # 构建相对于nodes目录的模块路径（关键修改点）
                rel_path = os.path.relpath(root, directory)
                
                # 处理根目录情况
                if rel_path == '.':
                    module_path = file[:-3]  # 直接使用文件名
                else:
                    module_path = os.path.join(rel_path, file[:-3]).replace(os.sep, '.')
                
                # 构建完整的模块路径
                full_module_path = f"{package_name}.{module_path}"
                
                # 打印详细信息
                print(f"导入路径: {full_module_path}")
                
                # 动态导入模块
                try:
                    print(f"尝试导入模块: {full_module_path}")
                    module = importlib.import_module(full_module_path)
                    print(f"成功导入模块: {full_module_path}")
                    
                    # 检查模块中的所有类
                    for name, obj in inspect.getmembers(module, inspect.isclass):
                        # 如果类被 @register_node 装饰器注册过，则添加到注册表
                        if hasattr(obj, '__node_type__'):
                            node_type = getattr(obj, '__node_type__')
                            NODE_REGISTRY[node_type] = obj
                            print(f"已注册节点: {node_type}")
                except Exception as e:
                    print(f"导入模块 {full_module_path} 时出错: {e}")
                    # 打印详细的错误堆栈
                    import traceback
                    print(traceback.format_exc())