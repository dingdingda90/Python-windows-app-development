# EntryViewer 打包与分发说明

## 1. 依赖安装 (首次)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## 2. 使用 spec 构建 (推荐目录模式)
```powershell
pyinstaller EntryViewer.spec
```
输出目录: `dist/EntryViewer/` 下的可执行文件 `EntryViewer.exe`。

## 3. 生成单文件 (可选)
```powershell
pyinstaller entryviewer.py --name EntryViewer --onefile --noconsole --add-data TPEntryManView.ini;. --add-data DAVIP_DB_DCNJ.CSV;.
```

## 4. 可选添加 DCQD CSV
编辑 `EntryViewer.spec` 数据部分添加：
```python
('DAVIP_DB_DCQD.CSV','.')
```
并重新执行打包。

## 5. 图标
放置图标文件 `resources/icon/app.ico` 后，把 spec 中 `icon_file = 'resources/icon/app.ico'`，然后重新打包。

## 6. 运行分发
将以下文件/目录打包给用户：
- dist/EntryViewer/** (整个目录)
- TPEntryManView.ini (已包含)
- CSV 文件 (已包含)
- MAN 数据根目录（网络盘或用户本地，确保 INI 中 MANPah 路径指向有效位置）

## 7. 常见问题
- 启动很慢：onefile 模式首次解压属于正常，可改用目录模式。
- 缺少 DLL：确认未手动删除 dist 下的 Qt* / PySide6* 目录。
- 找不到 INI：确认与 exe 同目录，或修改代码中 resource_path 函数。

## 8. 更新代码后增量打包
清理旧构建：
```powershell
Remove-Item -Recurse -Force build, dist
pyinstaller EntryViewer.spec
```

## 9. 调试模式
去掉 `console=False` (spec 里改为 True 或使用命令行不加 --noconsole) 以便查看输出。

---
该说明文件可随源码一起提交，方便他人重现构建流程。
