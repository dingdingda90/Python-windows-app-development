import sys
import os
import configparser
import csv
import time
import re
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QSplitter, QGroupBox, QCheckBox, QTabWidget, QStatusBar,
    QTextEdit,QHeaderView
)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont, QColor

import sys
import csv
import time
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QSplitter, QGroupBox, QCheckBox, QTabWidget, QStatusBar,
    QTextEdit,QHeaderView
)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont, QColor



class CsvData:
    def __init__(self):
        self.data_list = []

    def load(self, filename):
        start = time.time()
        self.data_list = []
        with open(filename, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile, delimiter=';')
            for row in reader:
                self.data_list.append(row)
        end = time.time()
        print(f"File read time: {end - start:.4f} seconds")

    def query(self, matno, revision, filename):
        self.load(filename)
        results = [row for row in self.data_list if row['matno'] == matno and row['revision'] == revision]
        if results:
            return results
        else:
            raise ValueError("No matching records found for given matno and revision.")

class DataSearchWorker(QThread):
    """后台数据搜索线程"""
    search_complete = Signal(dict)

    def __init__(self, material, reversion, location, csv_path, man_path):
        super().__init__()
        self.material = material
        self.reversion = reversion
        self.location = location
        self.csv_path = csv_path
        self.man_path = man_path

    def run(self):
        try:
            csv_data = CsvData()
            results = csv_data.query(self.material, self.reversion, self.csv_path)
            station_status = list(results)
            first = results[0] if results else {}

            # 查找 production/testsample/man 下 material_reversion_SiteNumber.man 文件
            base_path = self.man_path
            site_number = first.get("site", "") or first.get("SiteNumber", "")
            filename = f"{self.material}_{self.reversion}_{site_number}.man"
            found_path = None
            found_folder = ""
            found_mtime = None
            for folder in ["production", "testsample"]:
                man_dir = os.path.join(base_path, folder, "man")
                file_path = os.path.join(man_dir, filename)
                if os.path.isfile(file_path):
                    found_path = file_path
                    found_folder = folder
                    found_mtime = os.path.getmtime(file_path)
                    break
            if found_path:
                from datetime import datetime
                found_mtime_str = datetime.fromtimestamp(found_mtime).strftime("%Y-%m-%d %H:%M:%S")
                try:
                    found_ctime = os.path.getctime(found_path)
                    found_ctime_str = datetime.fromtimestamp(found_ctime).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    found_ctime_str = found_mtime_str
            else:
                found_mtime_str = ""
                found_ctime_str = ""

            mode_value = found_folder  # 只根据找到的文件目录

            # 读取与解析
            import re
            def read_file_safe(path):
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        return f.read()
                except UnicodeDecodeError:
                    try:
                        with open(path, 'r', encoding='latin-1') as f:
                            return f.read()
                    except Exception:
                        return "<Failed to decode file>"
                except Exception as e:
                    return f"<Error reading file: {e}>"

            man_file_content = read_file_safe(found_path) if found_path else first.get("modification_comment", "")

            def extract(key):
                m = re.search(rf'^{key}\s+"([^"]+)"', man_file_content, re.IGNORECASE | re.MULTILINE)
                if m:
                    return m.group(1).strip()
                m = re.search(rf'^{key}\s*[:=]\s*([^\r\n#;]+)', man_file_content, re.IGNORECASE | re.MULTILINE)
                if m:
                    return m.group(1).strip()
                return ""

            parsed_dci = extract("DCI") or extract("ECN")
            parsed_des = extract("DESC") or extract("DES") or extract("DESCRIPTION")

            # 动态解析 optional parameters 块，收集所有 KEY "VALUE" 形式的条目
            optional_entries = []  # list of (key, value)
            if man_file_content:
                lines = man_file_content.splitlines()
                # 找到 optional parameters 标题行（大小写不敏感，允许前后空白）
                header_idx = None
                header_regex = re.compile(r'^\s*[#;/\\-]*\s*optional parameters\b', re.IGNORECASE)
                for i, line in enumerate(lines):
                    if header_regex.match(line):
                        header_idx = i
                        break
                if header_idx is not None:
                    param_pattern = re.compile(r'^\s*([A-Za-z0-9_\-\.]+)\s+"([^"\r\n]+)"')
                    alt_pattern = re.compile(r'^\s*([A-Za-z0-9_\-\.]+)\s*[:=]\s*"?([^"\r\n#;]+)"?')
                    for raw_line in lines[header_idx + 1:]:
                        if not raw_line.strip():
                            # 空行不终止，继续允许稀疏空行
                            continue
                        # 注释行跳过
                        if raw_line.lstrip().startswith(('#', '//', ';')):
                            continue
                        m = param_pattern.match(raw_line)
                        if not m:
                            m = alt_pattern.match(raw_line)
                        if m:
                            k = m.group(1).strip()
                            v = m.group(2).strip()
                            if k and v:
                                optional_entries.append((k, v))

            # 基于扩展名的目录映射
            # 依据文件夹结构 (cfg, cmd, lbp, man, mcu, prg, syh, trigger)
            # 可按需继续扩展；key 为扩展名，value 为对应子目录(小写)
            ext_dir_map = {
                 '.prg': 'prg',        # 程序脚本
                 '.syh': 'syh',        # syh 配置
                 '.lbp': 'lbp',        # lbp 相关
                 '.cfg': 'cfg',        # 通用配置
                 '.mcu': 'mcu',        # MCU 文件
                 '.sch': 'sch',        # 独立 sch 目录已存在
                 '.cmd': 'cmd',        # 命令脚本
                 '.tgz': 'tgz',        # 新增目录 tgz
                 '.tps': 'tps',        # 新增目录 tps
                 '.trd': 'trd'         # 新增目录 trd
            }

            # 去重集合，避免重复文件
            seen_files = set()
            preview_files = []
            if found_path:
                preview_files.append({
                    "type": ".man",
                    "name": os.path.basename(found_path),
                    "path": found_path,
                    "env": found_folder,
                    "key": "MAN"
                })
                seen_files.add(found_path.lower())

            # 处理 optional entries -> 识别文件
            for key, value in optional_entries:
                # value 可能是文件名或其它参数；我们通过是否包含扩展名来判定
                name = value.strip()
                if ' ' in name:
                    # 含空格多半不是目标文件（降低误判）
                    continue
                root, ext = os.path.splitext(name)
                if not ext:
                    continue
                ext_l = ext.lower()
                folder = ext_dir_map.get(ext_l)
                if not folder:
                    # 不在预定义映射里的扩展名：使用小写扩展名（去掉点）作为目录
                    folder = ext_l[1:]
                # 必须先找到 .man 来确定环境；若未找到 .man 则不解析后续文件，直接跳过
                if not found_folder:
                    continue
                candidate_path = os.path.join(base_path, found_folder, folder, name)
                env_used = found_folder
                key_id = f"{key}:{candidate_path}".lower()
                if key_id in seen_files:
                    continue
                seen_files.add(key_id)
                preview_files.append({
                    "type": ext_l,
                    "name": name,
                    "path": candidate_path,
                    "env": env_used,
                    "key": key
                })

            # 生成内容列表
            preview_contents = []
            for f in preview_files:
                content = read_file_safe(f["path"]) if os.path.isfile(f["path"]) else f"<File not found: {f['path']}>"
                preview_contents.append({
                    "type": f.get("type", ""),
                    "name": f.get("name", ""),
                    "path": f.get("path", ""),
                    "env": f.get("env", ""),
                    "key": f.get("key", ""),
                    "content": content
                })

            result = {
                "man_info": {
                    "mode": mode_value,
                    "creat_time": found_ctime_str,
                    "modify_time": found_mtime_str
                },
                "station_status": station_status,
                "man_content": man_file_content,
                "man_file_location": found_folder,
                "man_file_mtime": found_mtime_str,
                "man_file_path": found_path or "",
                "parsed_dci": parsed_dci,
                "parsed_des": parsed_des,
                "preview_files": preview_files,
                "preview_contents": preview_contents
            }
            self.search_complete.emit(result)
        except Exception as e:
            self.search_complete.emit({"error": str(e)})


class SearchTab(QWidget):
    """搜索标签页：包含搜索条件和Station Status表格"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        # 读取INI配置
        self.config = configparser.ConfigParser()
        def get_file_path(relative_path):
            if hasattr(sys, '_MEIPASS'):
                # EXE运行时：指向EXE所在目录
                base_dir = os.path.dirname(os.path.abspath(sys.executable))
            else:
                # 源码运行时：指向脚本所在目录
                base_dir = os.path.dirname(os.path.abspath(__file__))
            return os.path.join(base_dir, relative_path)
        
        ini_path = get_file_path('TPEntryManView.ini')

        self.config.read(ini_path, encoding='utf-8')
        # 默认location
        self.current_location = 'DCNJ'
        self.update_config_by_location(self.current_location)
        self.csv_data = CsvData()
        self.csv_data.load(self.csv_path)
        self.init_ui()
        


    def update_config_by_location(self, location):
        # 根据location切换配置和csv路径
        section = f'Location_{location}'
        if section in self.config:
            site_number = self.config[section].get('SiteNumber', '')
            site_name = self.config[section].get('SiteName', '')
            man_path = self.config[section].get('MANPah', '')
            # 站点相关参数可用于界面显示或后续逻辑
            self.site_number = site_number
            self.site_name = site_name
            self.man_path = man_path
            # csv路径自动切换，使用MANPah为基路径
            self.csv_path = os.path.join(man_path, f'DAVIP_DB_{location}.csv')
        else:
            # 默认csv路径
            self.csv_path = 'DAVIP_DB_DCNJ.csv'

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        
        # SAP Entry & MAN 分组
        sap_group = QGroupBox("")
        sap_layout = QVBoxLayout(sap_group)
        sap_layout.setAlignment(Qt.AlignCenter)
        
        # 关键修改：创建水平布局，让三个部分三等分
        three_parts_layout = QHBoxLayout()
        
        # 1. Input Variant 子区域（占1/3宽度）
        input_group = QGroupBox("Input Variant")
        input_inner_layout = QVBoxLayout(input_group)

        # Material 行
        material_layout = QHBoxLayout()
        material_label = QLabel("Material")
        material_label.setFixedWidth(80)
        self.material_edit = QLineEdit("")
        # 自动补全功能：基于 CSV matno 字段
        from PySide6.QtWidgets import QCompleter
        matnos = [row.get("matno", "") for row in self.csv_data.data_list if row.get("matno", "")]
        self.material_completer = QCompleter(matnos)
        self.material_completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.material_edit.setCompleter(self.material_completer)
        material_layout.addWidget(material_label)
        material_layout.addWidget(self.material_edit)
        input_inner_layout.addLayout(material_layout)

        # Reversion 行
        reversion_layout = QHBoxLayout()
        reversion_label = QLabel("Reversion")
        reversion_label.setFixedWidth(80)
        self.reversion_edit = QLineEdit("")
        reversion_layout.addWidget(reversion_label)
        reversion_layout.addWidget(self.reversion_edit)
        input_inner_layout.addLayout(reversion_layout)

        # Location 行
        location_layout = QHBoxLayout()
        location_label = QLabel("Location")
        location_label.setFixedWidth(80)
        self.dcqd_check = QCheckBox("DCNJ/DCQD")
        location_layout.addWidget(location_label)
        location_layout.addWidget(self.dcqd_check)
        input_inner_layout.addLayout(location_layout)
        # 绑定状态改变信号，勾选/取消时加载csv
        self.dcqd_check.stateChanged.connect(self.on_location_changed)

        # 添加到三等分布局，设置拉伸因子1
        three_parts_layout.addWidget(input_group, 1)

        # 2. Variant 子区域（占1/3宽度）
        variant_group = QGroupBox("Variant")
        variant_inner_layout = QVBoxLayout(variant_group)

        # ECN NBR 行
        ecn_layout = QHBoxLayout()
        ecn_label = QLabel("ECN NBR")
        ecn_label.setFixedWidth(80)
        self.ecn_edit = QLineEdit("")
        self.ecn_edit.setReadOnly(True)
        ecn_layout.addWidget(ecn_label)
        ecn_layout.addWidget(self.ecn_edit)
        variant_inner_layout.addLayout(ecn_layout)

        # Description 行
        desc_layout = QHBoxLayout()
        desc_label = QLabel("Description")
        desc_label.setFixedWidth(80)
        self.desc_edit = QLineEdit("")
        self.desc_edit.setReadOnly(True)
        desc_layout.addWidget(desc_label)
        desc_layout.addWidget(self.desc_edit)
        variant_inner_layout.addLayout(desc_layout)

        # 添加到三等分布局，设置拉伸因子1
        three_parts_layout.addWidget(variant_group, 1)

        # 3. Man Info 子区域（占1/3宽度）
        info_group = QGroupBox("Man Info")
        info_layout = QVBoxLayout(info_group)

        # Mode 行
        mode_layout = QHBoxLayout()
        mode_label = QLabel("Mode")
        mode_label.setFixedWidth(80)
        self.mode_label = QLabel("Production")
        self.mode_label.setStyleSheet("background-color: green; color: white; padding: 3px;")
        mode_layout.addWidget(mode_label)
        mode_layout.addWidget(self.mode_label)
        info_layout.addLayout(mode_layout)

        # Creat Time 行
        creat_layout = QHBoxLayout()
        creat_label = QLabel("Creat Time")
        creat_label.setFixedWidth(80)
        self.creat_label = QLineEdit("")
        self.creat_label.setReadOnly(True)
        creat_layout.addWidget(creat_label)
        creat_layout.addWidget(self.creat_label)
        info_layout.addLayout(creat_layout)

        # Modify Time 行
        modify_layout = QHBoxLayout()
        modify_label = QLabel("Modify Time")
        modify_label.setFixedWidth(80)
        self.modify_label = QLineEdit("")
        self.modify_label.setReadOnly(True)
        modify_layout.addWidget(modify_label)
        modify_layout.addWidget(self.modify_label)
        info_layout.addLayout(modify_layout)

        # 添加到三等分布局，设置拉伸因子1
        three_parts_layout.addWidget(info_group, 1)

        # 将三等分布局添加到SAP分组
        sap_layout.addLayout(three_parts_layout)

        # 搜索按钮
        self.search_btn = QPushButton("SEARCH")
        self.search_btn.setStyleSheet("background-color: #A6CAF0;")
        self.search_btn.pressed.connect(self.on_search_pressed)
        self.search_btn.released.connect(self.on_search_released)
        self.search_btn.clicked.connect(self.search_data)
        sap_layout.addWidget(self.search_btn)
        main_layout.addWidget(sap_group)

        # Station Status 表格
        status_group = QGroupBox("Station Status")
        status_layout = QVBoxLayout(status_group)
        self.status_table = QTableWidget(0, 9)
        self.status_table.setHorizontalHeaderLabels([
            "Item", "Model", "Status", "Sequence Version", 
            "Task", "Dev", "Support", "Target Time", "Modification Date"
        ])
        self.status_table.horizontalHeader().setStretchLastSection(True)
        status_layout.addWidget(self.status_table)
        main_layout.addWidget(status_group)
        self.dcqd_check.stateChanged.connect(self.on_location_changed)

    def on_search_pressed(self):
        self.search_btn.setStyleSheet("background-color: #5B9BD5; color: white;")  # 按下变深色

    def on_search_released(self):
        self.search_btn.setStyleSheet("background-color: #A6CAF0;")  # 恢复原色

    def on_location_changed(self, state):
        # location值改变时，切换配置和csv路径
        self.current_location = 'DCQD' if self.dcqd_check.isChecked() else 'DCNJ'
        self.update_config_by_location(self.current_location)
        self.csv_data.load(self.csv_path)

    def search_data(self):
        """触发搜索并通知主窗口"""
        material = self.material_edit.text().strip()
        reversion = self.reversion_edit.text().strip()
        location = "DCQD" if self.dcqd_check.isChecked() else "DCNJ"

        # 每次点击都重新加载csv（如需优化可只加载一次）
        self.csv_data.load(self.csv_path)

        # 有效性校验
        if not (material.isdigit() and len(material) == 6):
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Input Error", "Material must be 6 digits!")
            return
        if not (reversion.isdigit() and len(reversion) == 2):
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Input Error", "Reversion must be 2 digits!")
            return

        if self.parent:
            self.parent.perform_search(material, reversion, location, self.csv_path, self.man_path)


class ManContentTab(QWidget):
    """MAN 内容预览：三列 (# / Type / Content) 左表 + 右侧全文"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.preview_entries = []  # [{key,type,name,path,env,content}]
        self.current_content = ""
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10,10,10,10)
        layout.setSpacing(4)
        # 路径标签
        self.path_label = QLabel("file")
        self.path_label.setFont(QFont("Arial", 10, QFont.Bold))
        layout.addWidget(self.path_label)
        # 下部区域
        bottom = QHBoxLayout()
        # 表格 2 列：Type / Content
        self.man_table = QTableWidget(0,2)
        self.man_table.setHorizontalHeaderLabels(["Type","Content"])
        self.man_table.setColumnWidth(0,120)
        self.man_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.man_table.setEditTriggers(QTableWidget.NoEditTriggers)
        tbl_box = QGroupBox("Preview")
        tbl_box.setLayout(QVBoxLayout())
        tbl_box.layout().addWidget(self.man_table)
        bottom.addWidget(tbl_box,1)
        # 右侧文本
        self.man_text = QTextEdit()
        self.man_text.setReadOnly(True)
        self.man_text.setFont(QFont("Consolas",10))
        text_box = QGroupBox("Full Content")
        text_box.setLayout(QVBoxLayout())
        text_box.layout().addWidget(self.man_text)
        bottom.addWidget(text_box,2)
        layout.addLayout(bottom)
        self.man_table.cellClicked.connect(self.on_row_clicked)

    def update_data(self, file_path, content, preview_entries=None):
        self.path_label.setText(file_path)
        self.current_content = content
        self.preview_entries = preview_entries or []
        self.refresh()

    def refresh(self):
        self.man_table.setRowCount(0)
        if not self.preview_entries:
            # 没有文件列表，只显示整份 .man 内容在右侧
            self.man_text.setText(self.current_content)
            return
        for entry in self.preview_entries:
            row = self.man_table.rowCount()
            self.man_table.insertRow(row)
            type_disp = entry.get('key') or entry.get('type','') or entry.get('name','')
            type_item = QTableWidgetItem(type_disp)
            name_item = QTableWidgetItem(entry.get('name',''))
            if entry.get('content','').startswith('<File not found'):
                type_item.setForeground(QColor('red'))
                name_item.setForeground(QColor('red'))
            self.man_table.setItem(row,0,type_item)
            self.man_table.setItem(row,1,name_item)
        # 默认选中第一行显示其全文
        if self.preview_entries:
            self.man_table.selectRow(0)
            self.man_text.setText(self.preview_entries[0].get('content',''))

    def on_row_clicked(self,row,col):
        if 0 <= row < len(self.preview_entries):
            entry = self.preview_entries[row]
            self.path_label.setText(entry.get('path', entry.get('name','')))
            self.man_text.setText(entry.get('content',''))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.search_worker = None
        self.init_ui()

    def init_ui(self):
        # 窗口设置
        self.setWindowTitle("Test Program Entry Man Viewer")
        self.setGeometry(500, 500, 1000, 600)
        # 固定窗口大小
        self.setMinimumSize(1000, 600)
        self.setMaximumSize(1000, 600)

        # 中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # 标题布局
        title_layout = QHBoxLayout()
        title_label = QLabel("Test Program Entry Man Viewer")
        title_label.setFont(QFont("Arial", 16, QFont.Bold))
        title_layout.addWidget(title_label)
        title_layout.setAlignment(Qt.AlignCenter)
        main_layout.addLayout(title_layout)

        # 标签页控件
        self.tabs = QTabWidget()
        
        # 初始化两个标签页
        self.search_tab = SearchTab(self)
        self.man_content_tab = ManContentTab(self)
        
        # 添加标签页
        self.tabs.addTab(self.search_tab, "SAP Entry MAN")
        self.tabs.addTab(self.man_content_tab, "MAN")
        # 两个标签平均分配宽度
        self.tabs.setStyleSheet("QTabBar::tab { width: 490; }")
        
        main_layout.addWidget(self.tabs)

        # 状态栏
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Support mcu cfg prg lbp syh sch --prg only part info")

    def perform_search(self, material, reversion, location, csv_path, man_path):
        """执行搜索操作"""
        self.search_worker = DataSearchWorker(material, reversion, location, csv_path, man_path)
        self.search_worker.search_complete.connect(self.handle_search_result)
        self.search_worker.start()
        self.statusBar.showMessage("Searching...")

    def handle_search_result(self, result):
        """处理搜索结果并更新两个标签页"""
        # 严格按照用户指定表头顺序显示
        station_status = result.get("station_status", [])
        user_headers = [
            "matno","revision","site","testsystem","task","dci","productfam","matname","ts_dev","prod_dev",
            "support","teststate","ts_givenname","path","script","param","testcondition","modification_comment",
            "modification_date","modification_responsible","c_date","target_testtime_cc"
        ]
        self.search_tab.status_table.setColumnCount(len(user_headers))
        self.search_tab.status_table.setHorizontalHeaderLabels(user_headers)
        self.search_tab.status_table.setRowCount(len(station_status))
        # 根据列头字长度自适应列宽
        metrics = self.search_tab.status_table.fontMetrics()
        padding = 24  # 额外补偿像素，防止内容被截断
        for i, header in enumerate(user_headers):
            width = metrics.horizontalAdvance(header) + padding
            self.search_tab.status_table.setColumnWidth(i, width)
        # 设置所有单元格不可选、不可编辑，双击颜色不变
        self.search_tab.status_table.setSelectionMode(QTableWidget.NoSelection)
        self.search_tab.status_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.search_tab.status_table.setStyleSheet("QTableWidget::item:selected { background: none; } QTableWidget::item:focus { background: none; }")
        for row_idx, row_data in enumerate(station_status):
            for col_idx, key in enumerate(user_headers):
                item = QTableWidgetItem(str(row_data.get(key, "")))
                item.setFlags(Qt.ItemIsEnabled)  # 只允许显示，不可选不可编辑
                # teststate 列变色
                if key == "teststate":
                    if str(row_data.get(key, "")).strip().lower() == "run":
                        item.setBackground(QColor(0, 255, 0))  # 绿色
                    else:
                        item.setBackground(QColor(192, 192, 192))  # 灰色
                self.search_tab.status_table.setItem(row_idx, col_idx, item)
        # 更新Man Info
        man_info = result.get("man_info", {})
        mode_text_raw = man_info.get("mode", "").strip()
        mode_text = mode_text_raw.lower()
        if mode_text == "production":
            self.search_tab.mode_label.setText("Production")
            self.search_tab.mode_label.setStyleSheet("background-color: green; color: white; padding: 3px;")
        elif mode_text == "testsample":
            self.search_tab.mode_label.setText("TestSample")
            self.search_tab.mode_label.setStyleSheet("background-color: red; color: white; padding: 3px;")
        elif mode_text:
            # 其它模式统一灰色
            self.search_tab.mode_label.setText(mode_text_raw)
            self.search_tab.mode_label.setStyleSheet("background-color: #888888; color: white; padding: 3px;")
        else:
            # 未找到文件时为空且灰色
            self.search_tab.mode_label.setText("")
            self.search_tab.mode_label.setStyleSheet("background-color: #666666; color: white; padding: 3px;")

        self.search_tab.creat_label.setText(man_info.get("creat_time", ""))
        self.search_tab.modify_label.setText(man_info.get("modify_time", ""))

        # 更新MAN内容标签页
        man_file_path = result.get("man_file_path", "")
        if man_file_path:
            display_path = man_file_path
            status_suffix = ""
        else:
            display_path = "MAN file not found (searched production/testsample/man)"
            status_suffix = " - MAN file not found"
            # 弹出报警提示
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "MAN File Missing", "MAN file not found in production/testsample/man.")
        # 预览文件数据
        preview_files = result.get("preview_contents", [])
        # 转换为 ManContentTab 需要的结构
        preview_entries = []
        for entry in preview_files:
            preview_entries.append({
                'type': entry.get('type', ''),
                'name': entry.get('name', ''),
                'path': entry.get('path', ''),
                'env': entry.get('env', ''),
                'key': entry.get('key', ''),
                'content': entry.get('content', '')
            })
        self.man_content_tab.update_data(display_path, result.get("man_content", ""), preview_entries=preview_entries)

        # 更新 ECN / Description（优先解析）
        parsed_dci = result.get('parsed_dci', '').strip()
        parsed_des = result.get('parsed_des', '').strip()
        if parsed_dci:
            self.search_tab.ecn_edit.setText(parsed_dci)
        elif station_status:
            self.search_tab.ecn_edit.setText(station_status[0].get('dci', ''))
        if parsed_des:
            self.search_tab.desc_edit.setText(parsed_des)
        elif station_status:
            fallback_desc = station_status[0].get('matname', '') or station_status[0].get('modification_comment', '')
            self.search_tab.desc_edit.setText(fallback_desc)

        # 保持当前TAB页面，不自动切换
        self.statusBar.showMessage("Search completed" + status_suffix)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


