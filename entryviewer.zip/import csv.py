import csv
import time

def load_csv_to_list(filename='DAVIP_DB_DCNJ.csv'):
    start = time.time()
    data_list = []
    with open(filename, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile, delimiter=';')
        for row in reader:
            data_list.append(row)
    end = time.time()
    print(f"File read time: {end - start:.4f} seconds")
    return data_list

def query_from_list(data_list, matno, revision):
    results = [row for row in data_list if row['matno'] == matno and row['revision'] == revision]
    if results:
        return results
    else:
        raise ValueError("No matching records found for given matno and revision.")

# 加载数据
data_list = load_csv_to_list('DAVIP_DB_DCNJ.csv')

# 查询
# try:
#     start = time.time()
#     results = query_from_list(data_list, '827031', '04')
#     for result in results:
#         print(result)
#     end = time.time()
#     print(f"Query time: {end - start:.4f} seconds")
# except ValueError as e:
#     print(str(e))