Param(
    [switch]$OneFile,
    [switch]$Debug,
    [switch]$AddDCQD,
    [string]$Icon = ''
)

Write-Host "== EntryViewer Build Script ==" -ForegroundColor Cyan

if (-not (Test-Path .venv)) {
    Write-Host "Creating virtual environment (.venv)" -ForegroundColor Yellow
    python -m venv .venv
    if ($LASTEXITCODE -ne 0) { Write-Error 'Failed to create venv'; exit 1 }
}

$venvPython = Join-Path (Resolve-Path .venv).Path 'Scripts/python.exe'
$venvPip = Join-Path (Resolve-Path .venv).Path 'Scripts/pip.exe'
if (-not (Test-Path $venvPython)) { Write-Error "python.exe not found in venv ($venvPython)"; exit 1 }

Write-Host "Installing dependencies with venv python" -ForegroundColor Yellow
& $venvPython -m pip install --upgrade pip > $null 2>&1
& $venvPython -m pip install -q -r requirements.txt
if ($LASTEXITCODE -ne 0) { Write-Error 'pip install failed'; exit 1 }

# Prepare add-data list
$datas = @("TPEntryManView.ini;.","DAVIP_DB_DCNJ.CSV;.")
if ($AddDCQD) { $datas += "DAVIP_DB_DCQD.CSV;." }

$pyinstallerExe = Join-Path (Resolve-Path .venv).Path 'Scripts/pyinstaller.exe'
if (-not (Test-Path $pyinstallerExe)) {
    Write-Host 'PyInstaller not yet installed explicitly, installing...' -ForegroundColor Yellow
    & $venvPython -m pip install -q pyinstaller
    if ($LASTEXITCODE -ne 0) { Write-Error 'PyInstaller install failed'; exit 1 }
}

# 构建参数数组，避免 Invoke-Expression 解析错误
$argsList = @('entryviewer.py','--name','EntryViewer','--noconsole')
if ($OneFile) { $argsList += '--onefile' }
foreach ($d in $datas) { $argsList += '--add-data'; $argsList += $d }
if ($Icon -and (Test-Path $Icon)) { $argsList += '--icon'; $argsList += $Icon }
if ($Debug) { $argsList += '--log-level=DEBUG' }

Write-Host ('Running: "{0}" {1}' -f $pyinstallerExe, ($argsList -join ' ')) -ForegroundColor Green
& $pyinstallerExe @argsList
if ($LASTEXITCODE -ne 0) { Write-Error 'PyInstaller build failed'; exit 1 }

Write-Host "Build finished. Output in dist/EntryViewer or dist/EntryViewer.exe" -ForegroundColor Cyan
